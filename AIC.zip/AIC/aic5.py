import time
import pyautogui
import pygetwindow as gw
from pywinauto import Application
import os
import sys
import io


class MyHP:

    TIMEOUT = 5

    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"
        self.baseline_folder = r"C:\Users\HPX\Desktop\A Testing\Baseline"

        if not os.path.exists(self.baseline_folder):
            os.makedirs(self.baseline_folder)

    # ---------------- Logger ----------------
    def _log_result(self, test_name, status, message=""):
        result = "PASS" if status else "FAIL"
        print(f"[{result}] {test_name} - {message}")

    # ---------------- Open HP Application ----------------
    def open_hp_application(self):
        try:
            pyautogui.press("winleft")
            time.sleep(1)
            pyautogui.write(self.app_title)
            time.sleep(1)
            pyautogui.press("enter")
            time.sleep(5)

            active_window = gw.getActiveWindow()
            if active_window and self.app_title in active_window.title:
                active_window.maximize()
                self._log_result("Open Application", True)
                return True
            else:
                self._log_result("Open Application", False, "Window not detected")
                return False

        except Exception as e:
            self._log_result("Open Application", False, str(e))
            return False

    # ---------------- Connect to HP Application ----------------
    def connect_to_application(self):
        try:
            self.application = Application(backend="uia").connect(title_re=self.app_title)
            self.main_window = self.application.window(title_re=self.app_title)
            time.sleep(3)
            self._log_result("Connect to Application", True)
            return True

        except Exception as e:
            self._log_result("Connect to Application", False, str(e))
            return False

    # ---------------- Open AIC Module ----------------
    def open_aic(self):
        if not self.main_window:
            self._log_result("Open AIC", False, "App not connected")
            return False

        try:
            time.sleep(3)

            card_button = self.main_window.child_window(
                title="hpaiassistant",
                control_type="Button"
            )

            if card_button.exists(timeout=5):
                card_button.click_input()
                time.sleep(2)
                self._log_result("Open AIC", True, "AIC button clicked")
                return True
            else:
                self._log_result("Open AIC", False, "AIC button not found")
                return False

        except Exception as e:
            self._log_result("Open AIC", False, str(e))
            return False

    # ---------------- Click AIC Input Box (TAB × 5) ----------------
    def click_aic_input_box(self):
        try:
            time.sleep(1)

            # Navigate using TAB 5 times
            for _ in range(5):
                pyautogui.press('tab')
                time.sleep(0.15)

            pyautogui.press("enter")

            self._log_result("Click AIC Input Box", True, "Reached via TAB x5")
            return True

        except Exception as e:
            self._log_result("Click AIC Input Box", False, str(e))
            return False

    # ---------------- Verify Primary Button State ----------------
    def verify_primary_button_state(self):
        if not self.main_window:
            self._log_result("Verify Primary Button", False, "App not connected")
            return False

        try:
            time.sleep(1)
            buttons = self.main_window.descendants(control_type="Button", title="Primary")
            if buttons:
                state = buttons[0].is_enabled()
                self._log_result("Primary Button State", True, "Enabled" if state else "Disabled")
                return state
            else:
                self._log_result("Primary Button State", False, "Button not found")
                return None

        except Exception as e:
            self._log_result("Primary Button State", False, str(e))
            return None

    # ---------------- Click Primary Button ----------------
    def click_primary_button(self):
        if not self.main_window:
            self._log_result("Click Primary Button", False, "App not connected")
            return False

        try:
            time.sleep(0.5)

            primary_button = self.main_window.child_window(
                auto_id="AIAgent.AIAgentRootScreen.SearchInput__primary__button",
                control_type="Button"
            )

            if primary_button.exists(timeout=5):
                if primary_button.is_enabled():
                    primary_button.click_input()
                    self._log_result("Click Primary Button", True, "Button clicked")
                    return True
                else:
                    self._log_result("Click Primary Button", False, "Button is disabled")
                    return False
            else:
                self._log_result("Click Primary Button", False, "Button not found")
                return False

        except Exception as e:
            self._log_result("Click Primary Button", False, str(e))
            return False

    # ---------------- Write Prompt in AIC ----------------
    def write_prompt_in_aic(self):
        try:
            time.sleep(0.5)
            pyautogui.write("Increase Brightness")

            # now click the 'Primary' button instead of pressing Enter
            return self.click_primary_button()

        except Exception as e:
            self._log_result("Write Prompt", False, str(e))
            return False

    # ---------------- Dump UI Tree ----------------
    def dump_ui_tree_to_file(self):
        if not self.main_window:
            self._log_result("Dump UI", False, "App not connected")
            return False

        try:
            dump_path = os.path.join(self.baseline_folder, "ui_dump.txt")
            buffer = io.StringIO()

            sys.stdout = buffer
            time.sleep(3)
            self.main_window.print_control_identifiers()
            sys.stdout = sys.__stdout__

            with open(dump_path, "w", encoding="utf-8") as f:
                f.write(buffer.getvalue())

            buffer.close()
            self._log_result("Dump UI", True, f"Saved to {dump_path}")
            return True

        except Exception as e:
            sys.stdout = sys.__stdout__
            self._log_result("Dump UI", False, str(e))
            return False


# ---------------- Main Flow ----------------
if __name__ == "__main__":
    hp = MyHP()

    if hp.open_hp_application():
        if hp.connect_to_application():
            if hp.open_aic():
                if hp.click_aic_input_box():
                    hp.verify_primary_button_state()
                if hp.write_prompt_in_aic():
                    hp.verify_primary_button_state()
                    # hp.dump_ui_tree_to_file()
                    print("Finished")
