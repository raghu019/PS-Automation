import pyautogui
import time
import pygetwindow as gw
from pywinauto.application import Application
from pywinauto.findwindows import ElementNotFoundError
import subprocess
import psutil


class HPTester:
    def __init__(self, app_title="HP"):
        self.app_title = app_title
        self.application = None
        self.main_window = None

        # ---------------- ALL MERGED SSIDs (NO DUPLICATES) ----------------
        self.allowed_ssids = {
            '8CBE','8CDD','8CDE','8CDF','8CE0','8D08','8D01','8A7F','8CCF','8DF3','8DF4',
            '8D1C','8D97','8DA0','8DA1','8DA8','8D9F','8DA7','8D9B','8D9C','8D9D','8D9E','8D84',
            '8E44','8B7C','8BBA','8BBB','8C84','8A50','8A4F','8BB2','8BC8','8BB1','8C2D',
            '8C2E','8C3F','8C40','8E3D','8DCD','8DCE','8DCF','8E5C','8E5D','8E5E','8F28',
            '8B4E','8DE0','894F','8AC3','864B','864D','864A','86C8','87FD','88E9','89BB',
            '8A1F','8E05','8E04','8C52','84B2','84B3','84B6','852E','852F','8544','8546',
            '8658','8659','868C','868D','84CE','855E','864F','864E','8651','86C9','87FE',
            '88EA','89BC','8A20','8C26','8D40','8D3F','8D2E','8D2D','8D2F','8E59','8E71',
            '8E72','8B2B','8B2D','8C60','8CD0','8B29','8DAC','8DBE','8DAD','8DB1','8DB0',
            '8E26','8E2A','8B2E','8D1A','8E2B','8E27','8949','8A98','8917','8A96','8D2C',
            '8C79','8CA0','8B27','8B28','8DC2','8DC0','8DC3','8BE9'
        }

    def _log_result(self, step_name, status, message=""):
        status_text = "PASS" if status else "FAIL"
        print(f"[{status_text}] {step_name}: {message}")

    # ---------------------------------------------------------
    #                  REQUIRED CHECKS
    # ---------------------------------------------------------

    def check_ram(self):
        try:
            ram_gb = round(psutil.virtual_memory().total / (1024 ** 3))
            if ram_gb >= 8:
                self._log_result("RAM Check", True, f"{ram_gb} GB")
                return True
            else:
                self._log_result("RAM Check", False, f"{ram_gb} GB (Need ≥ 8GB)")
                return False
        except Exception as e:
            self._log_result("RAM Check", False, str(e))
            return False

    def check_ssid(self):
        try:
            cmd = [
                "powershell",
                "-Command",
                "(Get-CimInstance Win32_BaseBoard).Product"
            ]
            output = subprocess.check_output(cmd).decode().strip()
            ssid = output.replace("\r", "").replace("\n", "").strip()

            if ssid in self.allowed_ssids:
                self._log_result("SSID Check", True, ssid)
                return True
            else:
                self._log_result("SSID Check", False, f"{ssid} - Not Allowed")
                return False
        except Exception as e:
            self._log_result("SSID Check", False, str(e))
            return False

    def check_feature_byte(self):
        try:
            cmd = [
                "powershell",
                "-Command",
                "(Get-CimInstance Win32_ComputerSystem).OEMStringArray"
            ]
            output = subprocess.check_output(cmd).decode().lower()

            if "te" in output:
                self._log_result("Feature Byte Check", True, "'te' found")
                return True
            else:
                self._log_result("Feature Byte Check", False, "'te' missing")
                return False
        except Exception as e:
            self._log_result("Feature Byte Check", False, str(e))
            return False

    def check_hsa_service(self):
        try:
            cmd = [
                "powershell",
                "-Command",
                "Get-Service -Name 'HP System Info HSA Service' -ErrorAction SilentlyContinue"
            ]
            output = subprocess.check_output(cmd).decode().lower()

            if "running" in output:
                self._log_result("HSA Service Check", True, "Running")
                return True
            else:
                self._log_result("HSA Service Check", False, "Not Running")
                return False
        except Exception as e:
            self._log_result("HSA Service Check", False, str(e))
            return False

    # ---------------------------------------------------------
    #      FORCE SET REGION → ALWAYS CHANGE TO UNITED STATES
    # ---------------------------------------------------------
    def check_and_set_region(self):
        try:

            pyautogui.hotkey('win', 'i')
            time.sleep(2)

            pyautogui.write('region')
            time.sleep(1)

            pyautogui.press('down')
            pyautogui.press('enter')
            time.sleep(3)

            for _ in range(5):
                pyautogui.press('tab')
                time.sleep(0.2)

            pyautogui.press('enter')
            time.sleep(1)

            pyautogui.write("United States", interval=0.05)
            time.sleep(1)

            pyautogui.press('enter')
            time.sleep(1)

            pyautogui.hotkey('alt', 'f4')

            self._log_result("Region Set", True, "Region forced to United States")
            return True

        except Exception as e:
            self._log_result("Region Set", False, str(e))
            return False

    # ---------------------------------------------------------
    #                  AIC CHECK FUNCTIONS
    # ---------------------------------------------------------
    def open_hp_application(self):
        try:
            pyautogui.press("winleft")
            time.sleep(1)
            pyautogui.write(self.app_title)
            time.sleep(1)
            pyautogui.press("enter")
            time.sleep(5)

            active_window = gw.getActiveWindow()
            if active_window and self.app_title in active_window.title:
                active_window.maximize()
                time.sleep(2)
                self._log_result("Open Application", True)
                return True
            else:
                self._log_result("Open Application", False, "HP Window Not Detected")
                return False

        except Exception as e:
            self._log_result("Open Application", False, str(e))
            return False

    def connect_to_application(self):
        try:
            self.application = Application(backend="uia").connect(title_re=self.app_title)
            self.main_window = self.application.window(title_re=self.app_title)
            time.sleep(4)
            self._log_result("Connect to Application", True)
            return True
        except Exception as e:
            self._log_result("Connect to Application", False, str(e))
            return False

    def check_aic_module_visibility(self):
        try:
            aic_btn = self.main_window.child_window(title="hpaiassistant", control_type="Button")

            if aic_btn.exists():
                self._log_result("AIC Module Visibility", True, "AIC Visible")

                # ---- NEW PART: CLICK AIC ----
                try:
                    aic_btn.click_input()
                    time.sleep(2)
                    self._log_result("AIC Click", True, "AIC button clicked successfully")
                except Exception as click_err:
                    self._log_result("AIC Click", False, str(click_err))

                return True
            else:
                self._log_result("AIC Module Visibility", False, "AIC NOT Visible")
                return False

        except ElementNotFoundError:
            self._log_result("AIC Module Visibility", False, "AIC Element Not Found")
            return False
        except Exception as e:
            self._log_result("AIC Module Visibility", False, str(e))
            return False


# ---------------------------------------------------------
#                     MAIN EXECUTION
# ---------------------------------------------------------
if __name__ == "__main__":
    tester = HPTester(app_title="HP")

    print("\n=============== AIC SUPPORT VALIDATION STARTED ===============\n")

    region = tester.check_and_set_region()
    ram = tester.check_ram()
    ssid = tester.check_ssid()
    feature = tester.check_feature_byte()
    hsa = tester.check_hsa_service()

    # SSID OR Feature Byte must match
    ssid_or_feature = ssid or feature

    # FINAL PRECONDITION
    preconditions_pass = all([region, ram, hsa, ssid_or_feature])

    if preconditions_pass:
        print("\nPreconditions PASSED → AIC SHOULD BE VISIBLE.\n")
    else:
        print("\nPreconditions FAILED → AIC SHOULD NOT BE VISIBLE (Still checking).\n")

    if tester.open_hp_application():
        if tester.connect_to_application():
            tester.check_aic_module_visibility()

    print("\n=============== AIC SUPPORT VALIDATION COMPLETED ===============\n")
