import time
import pyautogui
import subprocess
import psutil
import pygetwindow as gw
from pywinauto.application import Application
from pywinauto.findwindows import ElementNotFoundError


class HP_AIC_Library:

    def __init__(self, app_title="HP"):
        self.app_title = app_title
        self.application = None
        self.main_window = None

        # Allowed SSIDs
        self.allowed_ssids = {
            '8CBE','8CDD','8CDE','8CDF','8CE0','8D08','8D01','8A7F','8CCF','8DF3','8DF4',
            '8D1C','8D97','8DA0','8DA1','8DA8','8D9F','8DA7','8D9B','8D9C','8D9D','8D9E','8D84'
        }

        # Supported regions
        self.supported_regions = [
            "United States",
            "United Kingdom",
            "India",
            "Australia"
        ]

    # ---------------------------------------------------------
    # LOGGING
    # ---------------------------------------------------------
    def _log(self, step, status, msg=""):
        print(f"[{'PASS' if status else 'FAIL'}] {step}: {msg}")

    # ---------------------------------------------------------
    # DEPENDENCY CHECKS
    # ---------------------------------------------------------
    def check_ram(self):
        try:
            ram_gb = round(psutil.virtual_memory().total / (1024 ** 3))
            if ram_gb >= 8:
                self._log("RAM Check", True, f"{ram_gb} GB")
                return True
            self._log("RAM Check", False, f"{ram_gb} GB (Need ≥ 8GB)")
            return False
        except Exception as e:
            self._log("RAM Check", False, str(e))
            return False

    def check_ssid(self):
        try:
            cmd = [
                "powershell",
                "-Command",
                "(Get-CimInstance Win32_BaseBoard).Product"
            ]
            output = subprocess.check_output(cmd).decode().strip()

            if output in self.allowed_ssids:
                self._log("SSID Check", True, output)
                return True

            self._log("SSID Check", False, f"{output} - Not Allowed")
            return False

        except Exception as e:
            self._log("SSID Check", False, str(e))
            return False

    def check_feature_byte(self):
        try:
            cmd = [
                "powershell",
                "-Command",
                "(Get-CimInstance Win32_ComputerSystem).OEMStringArray"
            ]
            output = subprocess.check_output(cmd).decode().lower()

            if "te" in output:
                self._log("Feature Byte Check", True, "'te' found")
                return True

            self._log("Feature Byte Check", False, "'te' NOT found")
            return False

        except Exception as e:
            self._log("Feature Byte Check", False, str(e))
            return False

    def check_hsa_service(self):
        try:
            cmd = [
                "powershell",
                "-Command",
                "Get-Service -Name 'HP System Info HSA Service' -ErrorAction SilentlyContinue"
            ]
            output = subprocess.check_output(cmd).decode().lower()

            if "running" in output:
                self._log("HSA Service Check", True, "Running")
                return True

            self._log("HSA Service Check", False, "Not running")
            return False

        except Exception as e:
            self._log("HSA Service Check", False, str(e))
            return False

    # ---------------------------------------------------------
    # REGION CHECKS
    # ---------------------------------------------------------
    def get_current_region(self):
        try:
            cmd = [
                "powershell",
                "-Command",
                "(Get-ItemProperty 'HKCU:\\Control Panel\\International').sCountry"
            ]
            output = subprocess.check_output(cmd).decode().strip()
            return output
        except:
            return "Unknown"

    def set_region(self, region_name):
        try:
            pyautogui.hotkey("win", "i")
            time.sleep(2)

            pyautogui.write("region")
            time.sleep(1)

            pyautogui.press("down")
            pyautogui.press("enter")
            time.sleep(3)

            # Navigate to dropdown
            for _ in range(5):
                pyautogui.press("tab")
                time.sleep(0.2)

            pyautogui.press("enter")
            pyautogui.write(region_name, interval=0.05)
            pyautogui.press("enter")
            time.sleep(1)

            pyautogui.hotkey("alt", "f4")

            self._log("Set Region", True, f"{region_name}")
            return True

        except Exception as e:
            self._log("Set Region", False, str(e))
            return False

    # ---------------------------------------------------------
    # APPLICATION CONTROL
    # ---------------------------------------------------------
    def open_hp_application(self):
        try:
            pyautogui.press("win")
            time.sleep(1)
            pyautogui.write(self.app_title)
            pyautogui.press("enter")
            time.sleep(5)

            active_window = gw.getActiveWindow()
            if active_window and self.app_title in active_window.title:
                active_window.maximize()
                time.sleep(1)
                self._log("Open Application", True)
                return True

            self._log("Open Application", False, "Wrong window focused")
            return False

        except Exception as e:
            self._log("Open Application", False, str(e))
            return False

    def connect_to_application(self):
        try:
            self.application = Application(backend="uia").connect(title_re=self.app_title)
            self.main_window = self.application.window(title_re=self.app_title)
            time.sleep(5)
            self._log("Connect to Application", True)
            return True
        except Exception as e:
            self._log("Connect to Application", False, str(e))
            return False

    def check_aic_module_visibility(self):
        try:
            aic_btn = self.main_window.child_window(title="hpaiassistant", control_type="Button")
            if aic_btn.exists():
                self._log("AIC Module Visibility", True)
                return True

            self._log("AIC Module Visibility", False)
            return False

        except Exception as e:
            self._log("AIC Module Visibility", False, str(e))
            return False

    def close_hp_application(self):
        try:
            close_btn = self.main_window.child_window(auto_id="Close", control_type="Button")
            close_btn.click_input()
            self._log("Close Application", True)
            return True
        except:
            pyautogui.hotkey("alt", "f4")
            self._log("Close Application", True, "Closed via ALT+F4 fallback")
            return True

    # ---------------------------------------------------------
    # COMBINED TESTS (ROBOT KEYWORDS)
    # ---------------------------------------------------------
    def validate_aic_with_dependencies(self):
        reg = self.set_region("United States")
        ram = self.check_ram()
        ssid = self.check_ssid()
        feature = self.check_feature_byte()
        hsa = self.check_hsa_service()

        return all([reg, ram, ssid, feature, hsa])

    def test_aic_visibility_for_region(self, region):
        print(f"\n--- Testing Region: {region} ---")
        self.set_region(region)
        self.open_hp_application()
        self.connect_to_application()

        # ------------------------------
        # Run visibility check silently
        # ------------------------------
        try:
            aic_btn = self.main_window.child_window(title="hpaiassistant", control_type="Button")
            visible = aic_btn.exists()
        except:
            visible = False

        self.close_hp_application()

        # ------------------------------
        # China Exception Rule
        # ------------------------------
        if region.lower() == "china":
            if not visible:
                self._log("AIC Module Visibility", True, "Not Visible")
                return True
            else:
                self._log("AIC Module Visibility", False, "Visible")
                return False

        # ------------------------------
        # Normal regions → visible required
        # ------------------------------
        if visible:
            self._log("AIC Module Visibility", True, "Visible")
        else:
            self._log("AIC Module Visibility", False, "Not Visible")

        return visible


# =====================================================================
#                 STANDALONE PYTHON SCRIPT MODE
# =====================================================================
if __name__ == "__main__":
    tester = HP_AIC_Library(app_title="HP")

    print("\n============== AIC FULL VALIDATION STARTED ==============\n")

    # ----- PRE-CONDITION TEST -----
    deps = tester.validate_aic_with_dependencies()

    if deps:
        print("\nAll dependencies PASSED. Checking AIC Visibility...\n")
        tester.open_hp_application()
        tester.connect_to_application()
        tester.check_aic_module_visibility()
        tester.close_hp_application()
    else:
        print("\nAIC should NOT be visible because some dependencies FAILED.\n")

    # ----- REGION SERIES TEST -----
    print("\n============== REGION TEST STARTED ==============\n")
    regions = ["United States", "United Kingdom", "India", "Australia", "China"]

    for region in regions:
        tester.test_aic_visibility_for_region(region)

    print("\n============== ALL TESTS COMPLETED ==============\n")
