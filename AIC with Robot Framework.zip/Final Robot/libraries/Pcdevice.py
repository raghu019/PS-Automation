import psutil
import time
import pyautogui
import pygetwindow as gw
from pywinauto import Application
import re
import io
import sys


class Pcdevice:
    TIMEOUT = 5

    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"

    def connect_to_window(self):
        try:
            if not self.application or not self.application.is_process_running():
                self.application = Application(backend="uia").connect(title_re=self.app_title)
                self.main_window = self.application.window(title_re=self.app_title)
            return True
        except Exception:
            return False

    def open_hp_application(self):
        try:
            pyautogui.press('winleft')
            time.sleep(1)
            pyautogui.write(self.app_title)
            time.sleep(1)
            pyautogui.press('enter')
            time.sleep(2)

            active_window = gw.getActiveWindow()
            if active_window and self.app_title in active_window.title:
                active_window.maximize()
                time.sleep(2)
                print("Hp application is open")
                return True
            else:
                return False
        except Exception:
             raise Exception("Unable to Open HP")


    def connect_to_application(self):
        if not self.connect_to_window():
            return False

        try:
            time.sleep(2)
            return True
        except Exception:
            return False

    def finding_identifier(self):
        if not self.connect_to_application():
            return False
        try:
            time.sleep(5)
            self.main_window.print_control_identifiers()
            return True
        except Exception:
            return False

    def navigate_to_Pcdevice(self):
    
        if not self.connect_to_application():
            return False

        try:
            pc_device = self.main_window.child_window(
                auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname",
                control_type="Text"
            )
            if pc_device.wait("exists", timeout=15):
                pc_device.click_input()
                print("Navigated to PC Device.")
                time.sleep(3)
                return True
            else:
                print("PC Device element not found.")
                return False
        except Exception as e:
            print(f"Error navigating to PC Device: {e}")
            return False

        
    def device_page_backbutton(self):
        if not self.connect_to_application():
            return False
       
        try:
            back_button = self.main_window.child_window(auto_id="NavBar.NavBarView.BackButton",
                                                        control_type="Button").wait('enabled', timeout=2)
           
            if back_button:
                print("Back button is present and clickable")
 
            else:
                print("Back button is not clickable")
 
        except Exception as e:
            print(f"Back button not found: {e}")
            return  None
        
        
    def get_device_name(self):
        if not self.connect_to_application():
            raise Exception("Application not connected")

        try:
        # fetch all text controls
            elements = self.main_window.descendants(control_type="Text")

            for el in elements:
                auto_id = el.automation_id()  
                if auto_id and "__device-name" in auto_id:
                    text = el.window_text().strip()
                    print(f"Found device name: {text}")
                    # print(f"Found device name: {text} (auto_id={auto_id})")
                    return text

            raise Exception("Device name not found")

        except Exception as e:
            print(f"Error while fetching device name: {e}")
            raise

    def get_device_modelname(self):
        if not self.connect_to_application():
            raise("Application not connected")

        try:
            elements = self.main_window.descendants(control_type="Text")
            
            for el in elements:
                auto_id = el.automation_id()
                if auto_id and "__device-nickname" in auto_id:
                    text = el.window_text().strip()
                    print(f"Found model name: {text}")
                    return text
                
            raise Exception("Device model name not found")
        
        except Exception as e:
            print(f"Error while fetching device model name: {e}")
            raise

    def verify_image_present(self):
        if not self.connect_to_application():
            return False

        try:
            image_check = self.main_window.descendants(control_type="Image")

            for image in image_check:
                prop = image.get_properties()
                auto_id = prop.get('automation_id', '')

            # Check for PC Image OR Round Image
                if (re.match(r"clientos-ui-toolkit-device-details-page-.*__large-image", auto_id) or
                    re.match(r"pcdevicedetails__large-image", auto_id)):
                    print(f"Image found")
                    return True

            print("No matching image found")
            return False

        except Exception as e:
            print(f"Error in finding the image: {e}")
            return False

    
 
    def verify_battery_badge(self):
        if not self.connect_to_application():
            return False
        # time.sleep(3)
 
        try:
            battery_badge = self.main_window.child_window(auto_id="undefined__status-label",
                                                          control_type="Group").wait('exists', timeout=1)
           
            battery_text = battery_badge.window_text().strip()
 
            if battery_text:
                print("Battery badge found and its status is : "+ battery_text)
                return battery_text
            else:
                print("Battery Badge found but status is empty")
                return None
            
        except Exception as e:
            print(f"Error while verifying battery status : {e}")
            return None
        
 

    def verify_module_presence(self, title=None, auto_id=None, control_type=None):
        if not self.connect_to_application():
            return False
        

        try:
            search_args = {}
            if title:
                search_args["title"] = title
            if auto_id:
                search_args["auto_id"] = auto_id
            if control_type:
                search_args["control_type"] = control_type

            element = self.main_window.child_window(**search_args).wait('enabled', timeout=1)
            element_text = element.window_text().strip()

            if not element_text:
                try:
                    element_text = element.legacy_properties().get("Name", "").strip()
                except Exception:
                    element_text = ""

            if element_text:
                print(f"Module available and is is clickable : {element_text}")
                return element_text
            else:
                print("Module available but no label text")
                return "Module available"

        except Exception:
            print(f"Module not supported: {title if title else auto_id}")
            return "Module not supported"
        

    def check_required_service(self):
        print("\n Checking Required Service:")
        try:
            service = psutil.win_service_get("HPSysInfoCap")
            status = service.status()
            print(f" - HPSysInfoCap: {status.upper()}")
            if status != "running":
                raise Exception("HPSysInfoCap service is not running.")
        except Exception as e:
            raise Exception(f"Cannot continue: {e}")

    def verify_all_modules(self):
        self.check_required_service()

        self.main_window.type_keys('{PGDN}')

        modules = [
            {"title": "Audio", "auto_id": "PcDeviceCards.PcDeviceActionCards.PcaudioXCoreCard__header", "control_type": "Text"},
            {"title": "Programmable key", "auto_id": "PcDeviceCards.PcDeviceActionCards.ProgkeyXSettingsCard__header", "control_type": "Text"},
            {"title": "Battery manager", "auto_id": "PcDeviceCards.PcDeviceActionCards.PcbatterymanagerXSettingsCard__header", "control_type": "Text"},
            {"title": "System control", "auto_id": "PcDeviceCards.PcDeviceActionCards.PcsystemcontrolXSettingsCard__header", "control_type": "Text"},
            {"title": "Presence detection", "auto_id": "PcDeviceCards.PcDeviceActionCards.SmartexperiencesXCoreCard__header", "control_type": "Text"},
            {"title": "Energy consumption", "auto_id": "PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard__header", "control_type": "Text"},
        ]

        results = {}

        print("\n Verifying modules:")
        for module in modules:
            result = self.verify_module_presence(
                title=module["title"],
                auto_id=module["auto_id"],
                control_type=module["control_type"]
            )
            results[module["title"]] = result

        print("\n Module verification results:")
        for title, status in results.items():
            print(f" - {title}: {status}")

        return results
       
    def verify_productinfo(self):
        if not self.connect_to_application():
            return False
 
        try:
            results = {}
            # Scroll to find Product_info
 
            for _ in range(5):
 
                try:
                    product_info = self.main_window.child_window(auto_id="ProductInformation_CopySerialNumberButton",
                                                                 control_type="Group")
 
                    product_info.wait("visible", timeout=2)
                    break  # element found, stop scrolling
 
                except Exception:
                    self.main_window.type_keys("{PGDN}")
                    time.sleep(1)
 
            else:
                print("Product Information not found after scrolling")
 
 
            # 1. Product information (title)
 
            try:
                product_info =self.main_window.child_window(title="Product information",
                                                            auto_id="ProductInformation_ProductInformation__title",
                                                            control_type="Text")
                text = product_info.window_text().strip()
                print(f"Product information: {text if text else 'No text found'}")
                results["Product information"] = text
            except Exception:
                print("Product information: Not found")
                results["Product information"] = None
 
            # 2. Product number label
 
            try:
                product_number = self.main_window.child_window(title="Product number",
                                                            auto_id="ProductInformation_ProductNumberLabel__label-text",
                                                            control_type="Group")
                text = product_number.window_text().strip()
                print(f"Product number: {text if text else 'No text found'}")
                results["Product number"] = text
            except Exception:
                print("Product number: Not found")
                results["Product number"] = None
 
            # 3. Product number value
 
            try:
                product_num_val = self.main_window.child_window(auto_id="ProductInformation_CopyProductNumberButton",
                                                                control_type="Group")
                text = product_num_val.window_text().strip()
                print(f"Product number value: {text if text else 'No text found'}")
                results["Product number value"] = text
            except Exception:
                print("Product number value: Not found")
                results["Product number value"] = None
 
            # 4. Serial number label
 
            try:
                serial_label = self.main_window.child_window(auto_id="ProductInformation_SerialNumberLabel__label-text",
                                                             control_type="Group")
                text = serial_label.window_text().strip()
                print(f"Serial number: {text if text else 'No text found'}")
                results["Serial number"] = text
            except Exception:
                print("Serial number: Not found")
                results["Serial number"] = None
 
            # 5. Serial number value
 
            try:
                serial_val = self.main_window.child_window(
                    auto_id="ProductInformation_CopySerialNumberButton",
                    control_type="Group"
                )
                text = serial_val.window_text().strip()
                print(f"Serial number value: {text if text else 'No text found'}")
                results["Serial number value"] = text
            except Exception:
                print("Serial number value: Not found")
                results["Serial number value"] = None
 
            return results
       
        except Exception as e:
            print(f"Error while verifying product info : {e}")
            return None
 
    
    # Device Details Card
    def verify_device_details_alignment(self):
        try:
            elements = self.main_window.descendants(control_type="Text")
            container = self.main_window.child_window(auto_id="container-layout", control_type="Group")

            if not container.exists(timeout=5):
                raise Exception("Container layout not found")

            crect = container.rectangle()
            left_gaps = []

            # Device Name
            for el in elements:
                auto_id = el.automation_id()
                if auto_id and "__device-name" in auto_id:
                    gap = el.rectangle().left - crect.left
                    print(f"Device Name Left Gap: {gap}px")
                    left_gaps.append(gap)
                    break

            # Device Nickname
            for el in elements:
                auto_id = el.automation_id()
                if auto_id and "__device-nickname" in auto_id:
                    gap = el.rectangle().left - crect.left
                    print(f"Device Nickname Left Gap: {gap}px")
                    left_gaps.append(gap)
                    break

            # Battery Details
            for el in elements:
                auto_id = el.automation_id()
                if auto_id and "undefined__list-item" in auto_id:
                    gap = el.rectangle().left - crect.left
                    print(f"Battery Details Left Gap: {gap}px")
                    left_gaps.append(gap)
                    break

            if not left_gaps:
                raise Exception("No device detail elements found")

            if not all(g == left_gaps[0] for g in left_gaps):
                raise Exception("Device detail elements are not aligned")

            print("Device detail elements are aligned")
            print("***************")
            return True

        except Exception as e:
            raise Exception(f"Error verifying device details: {e}")

    def verify_image_fixed(self):
        try:
            container = self.main_window.child_window(auto_id="container-layout", control_type="Group")
            if not container.exists(timeout=5):
                raise Exception("Container layout not found")

        # Find all image elements
            images = self.main_window.descendants(control_type="Image")

            image = None
            for img in images:
                auto_id = img.automation_id()
                if re.match(r"clientos-ui-toolkit-device-details-page-.*__large-image", auto_id) or \
                re.match(r"pcdevicedetails__large-image", auto_id):
                    image = img
                    print(f"Image found with auto_id: {auto_id}")
                    break

            if not image:
                raise Exception("No matching image found")

            # Record position before scroll
            y1 = image.rectangle().top

            # Scroll
            container.set_focus()
            for _ in range(5):
                self.main_window.type_keys("{PGDN}")
                time.sleep(0.5)

            # Record position after scroll
            y2 = image.rectangle().top

            if y1 != y2:
                raise Exception("Image is not fixed (it scrolls)")

            print("Image is fixed")
            print("***************")
            return True

        except Exception as e:
            raise Exception(f"Error verifying image fixed: {e}")

    def verify_ads_cards_alignment(self):
        try:
            cards = [
                {"title": "First Ads Card", "auto_id": "blt3fd183c9b8f0c0fb"},
                {"title": "Second Ads Card", "auto_id": "blta47e3ab186944c47"},
                {"title": "Get Help Card", "auto_id": "Support.SupportCard.GetHelp"},
            ]

            container = self.main_window.child_window(auto_id="container-layout", control_type="Group")
            if not container.exists(timeout=5):
                raise Exception("Container layout not found")

            crect = container.rectangle()
            supported_cards = []

            for c in cards:
                try:
                    ctrl = self.main_window.child_window(auto_id=c["auto_id"])
                    if ctrl.exists(timeout=5):
                        rect = ctrl.rectangle()
                        supported_cards.append({
                            "title": c["title"],
                            "id": c["auto_id"],
                            "width": rect.width(),
                            "x": rect.left,
                            "y": rect.top,
                            "right": rect.right
                        })
                    else:
                        print(f"{c['title']} not supported on this system")
                except Exception as e:
                    print(f"Error checking {c['title']}: {e}")

            if not supported_cards:
                raise Exception("No ads cards found on this system")

            print(f"\nSupported Ads Cards Found: {len(supported_cards)}")
            print(f"Container width: {crect.width()}px")

            left_gaps, right_gaps, widths = [], [], []
            for idx, card in enumerate(supported_cards, 1):
                left_gap = card["x"] - crect.left
                right_gap = crect.right - card["right"]
                left_gaps.append(left_gap)
                right_gaps.append(right_gap)
                widths.append(card["width"])

                print(f"\n{idx}. {card['title']}")
                print(f"   Width: {card['width']}px")
                print(f"   Left Gap: {left_gap}px")
                print(f"   Right Gap: {right_gap}px")

            tolerance = 2
            all_left_same = all(abs(g - left_gaps[0]) <= tolerance for g in left_gaps)
            all_right_same = all(abs(g - right_gaps[0]) <= tolerance for g in right_gaps)
            all_widths_same = all(abs(w - widths[0]) <= tolerance for w in widths)

            print("\nAlignment Check:")
            if all_left_same and all_right_same and all_widths_same:
                print("Ads cards are perfectly aligned")
                print("***************")
                return True
            else:
                raise Exception("Ads cards are not aligned properly")

        except Exception as e:
            raise Exception(f"Error verifying ads cards: {e}")


    def verify_module_cards_alignment(self):
        try:
            cards = [
                {"title": "Audio Card", "auto_id": "PcDeviceCards.PcDeviceActionCards.PcaudioXCoreCard"},
                {"title": "Video Card", "auto_id": "PcDeviceCards.PcDeviceActionCards.VideoXControlCard"},
                {"title": "Presence Sensing Card", "auto_id": "PcDeviceCards.PcDeviceActionCards.PcXActionsPresenceCard"},
                {"title": "System Control Card", "auto_id": "PcDeviceCards.PcDeviceActionCards.PcsystemcontrolXSettingsCard"},
                {"title": "Energy Consumption Card", "auto_id": "PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard"},
                {"title": "Battery Manager Card", "auto_id": "PcDeviceCards.PcDeviceActionCards.PcbatterymanagerXSettingsCard"},
                {"title": "Programmable Key Card", "auto_id": "PcDeviceCards.PcDeviceActionCards.ProgkeyXSettingsCard"},
                {"title": "Presence Detection Card", "auto_id": "PcDeviceCards.PcDeviceActionCards.SmartexperiencesXCoreCard"},
                {"title": "Well-being", "auto_id": "PcDeviceCards.PcDeviceActionCards.PcwellbeingXCoreCard"},
                {"title": "Display", "auto_id": "PcDeviceCards.PcDeviceActionCards.PcdisplayXControlCard"},
            ]

            container = self.main_window.child_window(auto_id="container-layout", control_type="Group")
            if not container.exists(timeout=5):
                raise Exception("Container layout not found")

            crect = container.rectangle()
            supported_cards = []

            for c in cards:
                try:
                    card = self.main_window.child_window(auto_id=c["auto_id"])
                    if card.exists(timeout=5):
                        rect = card.rectangle()
                        supported_cards.append({
                            "title": c["title"],
                            "id": c["auto_id"],
                            "width": rect.width(),
                            "height": rect.height(),
                            "x": rect.left,
                            "y": rect.top
                        })
                    else:
                        print(f"\n{c['title']} not supported on this system")
                except Exception as e:
                    print(f"\nError checking {c['title']}: {e}")

            if not supported_cards:
                raise Exception("No module cards supported on this system")

            supported_cards.sort(key=lambda c: (c["y"], c["x"]))
            rows = {}
            for card in supported_cards:
                rows.setdefault(card["y"], []).append(card)

            print(f"\nSupported Module Cards Found: {len(supported_cards)}")
            print(f"Container width: {crect.width()}px")

            for idx, card in enumerate(supported_cards, 1):
                print(f"{idx}. {card['title']}")
                print(f"   Width: {card['width']}px")

            row_left_gaps = []
            row_right_gaps = []
            horizontal_gaps_per_row = []
            vertical_gaps = []

            sorted_row_keys = sorted(rows.keys())
            for idx, row_y in enumerate(sorted_row_keys, 1):
                row_cards = rows[row_y]
                row_cards.sort(key=lambda c: c["x"])

                left_gap = row_cards[0]["x"] - crect.left
                row_left_gaps.append(left_gap)

                right_gap = crect.right - (row_cards[-1]["x"] + row_cards[-1]["width"])
                row_right_gaps.append(right_gap)

                print(f"\nRow {idx}:")
                print(f"Left Gap: {left_gap}px")
                print(f"Right Gap: {right_gap}px")

                gaps = []
                if len(row_cards) > 1:
                    for i in range(len(row_cards) - 1):
                        gap = row_cards[i + 1]["x"] - (row_cards[i]["x"] + row_cards[i]["width"])
                        gaps.append(gap)
                        print(f"{row_cards[i]['title']} → {row_cards[i + 1]['title']} = {gap}px")
                horizontal_gaps_per_row.append(gaps)

                if idx > 1:
                    prev_row_y = sorted_row_keys[idx - 2]
                    prev_row_height = max(c["height"] for c in rows[prev_row_y])
                    vertical_gap = row_y - (prev_row_y + prev_row_height)
                    vertical_gaps.append(vertical_gap)
                    print(f"Vertical gap from Row {idx-1} → Row {idx} = {vertical_gap}px")

            tolerance = 2
            all_left_same = all(abs(g - row_left_gaps[0]) <= tolerance for g in row_left_gaps)

            # Modified: Ignore right gap mismatch in the last row if it has fewer cards
            full_rows = [row for row in rows.values() if len(row) > 1]
            if len(full_rows) > 1:
                all_right_same = all(
                    abs(row_right_gaps[i] - row_right_gaps[0]) <= tolerance
                    for i in range(len(full_rows) - 1)
                )
            else:
                all_right_same = True

            all_horizontal_same = all(
                all(abs(gap - row[0]) <= tolerance for gap in row) if row else True
                for row in horizontal_gaps_per_row
            )
            all_vertical_same = all(abs(g - vertical_gaps[0]) <= tolerance for g in vertical_gaps) if vertical_gaps else True

            print("\nAlignment Check:")
            if all_left_same and all_horizontal_same and all_vertical_same:
                print("Cards are aligned (last row may be center-aligned with fewer cards)")
                print("***************")
                return True
            else:
                raise Exception("Cards are NOT perfectly aligned")

        except Exception as e:
            raise Exception(f"Error in verify_module_cards_alignment: {e}")


    def dump_ui_tree_to_file(self, filename="ui_dump.txt"):
        
        try:
            with open(filename, "w", encoding="utf-8") as f:
                buffer = io.StringIO()
                sys.stdout = buffer
                self.main_window.print_control_identifiers()
                sys.stdout = sys.__stdout__  # Reset stdout
                f.write(buffer.getvalue())
                buffer.close()
            print(f"UI tree dumped successfully to {filename}")
        except Exception as e:
            sys.stdout = sys.__stdout__  # Ensure stdout is reset on exception
            print(f"Failed to dump UI tree: {e}")
 
    def close_hp(self):
        try:
            close_btn = self.main_window.child_window(
                auto_id="Close",
                control_type="Button").wait('exists', timeout=3)
           
            close_btn.click_input()
 
            return True
       
        except Exception as e:
            return False
     


if __name__ == "__main__":
    obj = Pcdevice()
    try:

        if obj.open_hp_application():
            if obj.connect_to_application():
                if obj.navigate_to_Pcdevice():
                    if obj.get_device_name():
                        if obj.get_device_modelname():
                            if obj.verify_image_present():
                                if obj.verify_battery_badge():
                                    # if obj.finding_identifier():
                                        if obj.verify_all_modules():
                                            if obj.verify_productinfo():
                                                if obj.verify_device_details_alignment():
                                                    if obj.verify_image_fixed():
                                                        if obj.verify_ads_cards_alignment():
                                                            if obj.verify_module_cards_alignment():
                                                                obj.close_hp

    except Exception as e:
        print(f"\n Error: {e}")





