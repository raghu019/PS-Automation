import pyautogui
import time
import pygetwindow as gw
from pywinauto.application import Application
from pywinauto.findwindows import ElementNotFoundError

class HPTester:
    def __init__(self, app_title="HP"):
        self.app_title = app_title
        self.application = None
        self.main_window = None

    def _log_result(self, step_name, status, message=""):
        status_text = "PASS" if status else "FAIL"
        print(f"[{status_text}] {step_name}: {message}")

    # ---------------- Open HP Application ----------------
    def open_hp_application(self):
        """Open HP application using Windows search"""
        try:
            pyautogui.press('winleft')
            time.sleep(1)
            pyautogui.write(self.app_title)
            time.sleep(1)
            pyautogui.press('enter')
            time.sleep(5)

            active_window = gw.getActiveWindow()
            if active_window and self.app_title in active_window.title:
                active_window.maximize()
                time.sleep(2)
                self._log_result("Open Application", True)
                return True
            else:
                self._log_result("Open Application", False, "Wrong window focused")
                return False
        except Exception as e:
            self._log_result("Open Application", False, str(e))
            return False

    # ---------------- Connect to HP Application ----------------
    def connect_to_application(self):
        """Connect to HP application using pywinauto"""
        try:
            self.application = Application(backend="uia").connect(title_re=self.app_title)
            self.main_window = self.application.window(title_re=self.app_title)
            time.sleep(5)  # wait for UI to load
            self._log_result("Connect to Application", True)
            return True 
        except Exception as e:
            self._log_result("Connect to Application", False, str(e))
            return False

    # ---------------- Check AIC Module Visibility ----------------
    def check_aic_module_visibility(self, region):
        """Check if AIC module is visible, with special rule for China"""
        try:
            aic_module = self.main_window.child_window(title="hpaiassistant", control_type="Button")
            is_visible = aic_module.exists()

            if region.lower() == "china":
                if not is_visible:
                    self._log_result("AIC Module Visibility", True, "AIC module correctly not visible in China.")
                    return True
                else:
                    self._log_result("AIC Module Visibility", False, "AIC module should NOT be visible in China.")
                    return False
            else:
                if is_visible:
                    self._log_result("AIC Module Visibility", True, "AIC module is visible.")
                    return True
                else:
                    self._log_result("AIC Module Visibility", False, "AIC module not found.")
                    return False

        except ElementNotFoundError:
            if region.lower() == "china":
                self._log_result("AIC Module Visibility", True, "AIC module correctly not visible in China.")
                return True
            else:
                self._log_result("AIC Module Visibility", False, "AIC module not found.")
                return False
        except Exception as e:
            self._log_result("AIC Module Visibility", False, str(e))
            return False

    # ---------------- Set Region ----------------
    def set_region(self, region_name):
        try:
            pyautogui.hotkey('win', 'i')
            time.sleep(2)

            pyautogui.write('region')
            time.sleep(1)

            pyautogui.press('down')
            time.sleep(0.5)

            pyautogui.press('enter')
            time.sleep(3)

            for _ in range(5):
                pyautogui.press('tab')
                time.sleep(0.2)

            pyautogui.press('enter')
            time.sleep(1)

            pyautogui.write(region_name, interval=0.05)
            time.sleep(1)
            pyautogui.press('enter')
            time.sleep(1)

            pyautogui.hotkey('alt', 'f4')

            self._log_result("Set Region", True, f"Region set to {region_name}")
            return True

        except Exception as e:
            self._log_result("Set Region", False, str(e))
            return False

    # ---------------- Close HP Application via UI ----------------
    def close_hp_application(self):
        """Close HP application using UI button"""
        try:
            close_btn = self.main_window.child_window(
                auto_id="Close",
                control_type="Button").wait('exists', timeout=5)
            close_btn.click_input()
            time.sleep(2)
            self._log_result("Close Application", True)
            return True
        except Exception as e:
            self._log_result("Close Application", False, str(e))
            return False

    # ---------------- Run Full Test ----------------
    def run_test_for_region(self, region):
        print(f"\n--- Running Test for Region: {region} ---")
        if not self.set_region(region):
            return
        if not self.open_hp_application():
            return
        if not self.connect_to_application():
            return
        self.check_aic_module_visibility(region)
        self.close_hp_application()
        print("-" * 60)
        time.sleep(3)



# ---------------- Robot Framework Keywords (MODULE LEVEL) ----------------

_tester = HPTester(app_title="HP")


def get_supported_regions():
    """Robot keyword"""
    return [
        "United States",
        "United Kingdom",
        "India",
        "Australia",
        "China"
    ]


def run_test_for_region(region):
    """Robot keyword"""
    return _tester.run_test_for_region(region)


def set_region(region):
    return _tester.set_region(region)


def open_hp_application():
    return _tester.open_hp_application()


def connect_to_application():
    return _tester.connect_to_application()


def check_aic_module_visibility(region):
    return _tester.check_aic_module_visibility(region)


def close_hp_application():
    return _tester.close_hp_application()
