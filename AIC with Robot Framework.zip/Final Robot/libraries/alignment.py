import time
import pyautogui
from pywinauto import Application
import io
import sys
import re


class HpAutomation:
    def __init__(self, app_title="HP"):
        self.APP_TITLE = app_title
        self.main_window = None

    def launch_hp_app(self):
        try:
            pyautogui.press("winleft")
            time.sleep(1)
            pyautogui.write(self.APP_TITLE)
            time.sleep(1)
            pyautogui.press("enter")
            time.sleep(8)
            print("HP Application launched")
            print("***************")
        except Exception as e:
            raise Exception(f"Failed to launch HP Application: {e}")

    def connect_to_app(self):
        try:
            app = Application(backend="uia").connect(title_re=self.APP_TITLE)
            self.main_window = app.window(title_re=self.APP_TITLE)
            print("Connected to HP Application")
            print("***************")
            return self.main_window
        except Exception as e:
            raise Exception(f"Failed to connect to HP Application: {e}")

    def navigate_to_pc_device(self):
        try:
            pc_device = self.main_window.child_window(
                auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname",
                control_type="Text",
            )
            if pc_device.exists(timeout=15):
                pc_device.click_input()
                print("Navigated to PC Device")
                time.sleep(3)
                print("***************")
                return True
            raise Exception("PC Device element not found")
        except Exception as e:
            raise Exception(f"Error navigating to PC Device: {e}")

    # Device Details Card
    def verify_device_details_alignment(self):
        try:
            elements = self.main_window.descendants(control_type="Text")
            container = self.main_window.child_window(auto_id="container-layout", control_type="Group")

            if not container.exists(timeout=5):
                raise Exception("Container layout not found")

            crect = container.rectangle()
            left_gaps = []

            # Device Name
            for el in elements:
                auto_id = el.automation_id()
                if auto_id and "__device-name" in auto_id:
                    gap = el.rectangle().left - crect.left
                    print(f"Device Name Left Gap: {gap}px")
                    left_gaps.append(gap)
                    break

            # Device Nickname
            for el in elements:
                auto_id = el.automation_id()
                if auto_id and "__device-nickname" in auto_id:
                    gap = el.rectangle().left - crect.left
                    print(f"Device Nickname Left Gap: {gap}px")
                    left_gaps.append(gap)
                    break

            # Battery Details
            for el in elements:
                auto_id = el.automation_id()
                if auto_id and "undefined__list-item" in auto_id:
                    gap = el.rectangle().left - crect.left
                    print(f"Battery Details Left Gap: {gap}px")
                    left_gaps.append(gap)
                    break

            if not left_gaps:
                raise Exception("No device detail elements found")

            if not all(g == left_gaps[0] for g in left_gaps):
                raise Exception("Device detail elements are not aligned")

            print("Device detail elements are aligned")
            print("***************")
            return True

        except Exception as e:
            raise Exception(f"Error verifying device details: {e}")

    def verify_image_fixed(self):
        try:
            container = self.main_window.child_window(auto_id="container-layout", control_type="Group")
            if not container.exists(timeout=5):
                raise Exception("Container layout not found")

        # Find all image elements
            images = self.main_window.descendants(control_type="Image")

            image = None
            for img in images:
                auto_id = img.automation_id()
                if re.match(r"clientos-ui-toolkit-device-details-page-.*__large-image", auto_id) or \
                re.match(r"pcdevicedetails__large-image", auto_id):
                    image = img
                    print(f"Image found with auto_id: {auto_id}")
                    break

            if not image:
                raise Exception("No matching image found")

            # Record position before scroll
            y1 = image.rectangle().top

            # Scroll
            container.set_focus()
            for _ in range(5):
                self.main_window.type_keys("{PGDN}")
                time.sleep(0.5)

            # Record position after scroll
            y2 = image.rectangle().top

            if y1 != y2:
                raise Exception("Image is not fixed (it scrolls)")

            print("Image is fixed")
            print("***************")
            return True

        except Exception as e:
            raise Exception(f"Error verifying image fixed: {e}")

    def verify_ads_cards_alignment(self):
        try:
            cards = [
                {"title": "First Ads Card", "auto_id": "blt3fd183c9b8f0c0fb"},
                {"title": "Second Ads Card", "auto_id": "blta47e3ab186944c47"},
                {"title": "Get Help Card", "auto_id": "Support.SupportCard.GetHelp"},
            ]

            container = self.main_window.child_window(auto_id="container-layout", control_type="Group")
            if not container.exists(timeout=5):
                raise Exception("Container layout not found")

            crect = container.rectangle()
            supported_cards = []

            for c in cards:
                try:
                    ctrl = self.main_window.child_window(auto_id=c["auto_id"])
                    if ctrl.exists(timeout=5):
                        rect = ctrl.rectangle()
                        supported_cards.append({
                            "title": c["title"],
                            "id": c["auto_id"],
                            "width": rect.width(),
                            "x": rect.left,
                            "y": rect.top,
                            "right": rect.right
                        })
                    else:
                        print(f"{c['title']} not supported on this system")
                except Exception as e:
                    print(f"Error checking {c['title']}: {e}")

            if not supported_cards:
                raise Exception("No ads cards found on this system")

            print(f"\nSupported Ads Cards Found: {len(supported_cards)}")
            print(f"Container width: {crect.width()}px")

            left_gaps, right_gaps, widths = [], [], []
            for idx, card in enumerate(supported_cards, 1):
                left_gap = card["x"] - crect.left
                right_gap = crect.right - card["right"]
                left_gaps.append(left_gap)
                right_gaps.append(right_gap)
                widths.append(card["width"])

                print(f"\n{idx}. {card['title']}")
                print(f"   Width: {card['width']}px")
                print(f"   Left Gap: {left_gap}px")
                print(f"   Right Gap: {right_gap}px")

            tolerance = 2
            all_left_same = all(abs(g - left_gaps[0]) <= tolerance for g in left_gaps)
            all_right_same = all(abs(g - right_gaps[0]) <= tolerance for g in right_gaps)
            all_widths_same = all(abs(w - widths[0]) <= tolerance for w in widths)

            print("\nAlignment Check:")
            if all_left_same and all_right_same and all_widths_same:
                print("Ads cards are perfectly aligned")
                print("***************")
                return True
            else:
                raise Exception("Ads cards are not aligned properly")

        except Exception as e:
            raise Exception(f"Error verifying ads cards: {e}")


    def verify_module_cards_alignment(self):
        try:
            cards = [
                {"title": "Audio Card", "auto_id": "PcDeviceCards.PcDeviceActionCards.PcaudioXCoreCard"},
                {"title": "Video Card", "auto_id": "PcDeviceCards.PcDeviceActionCards.VideoXControlCard"},
                {"title": "Presence Sensing Card", "auto_id": "PcDeviceCards.PcDeviceActionCards.PcXActionsPresenceCard"},
                {"title": "System Control Card", "auto_id": "PcDeviceCards.PcDeviceActionCards.PcsystemcontrolXSettingsCard"},
                {"title": "Energy Consumption Card", "auto_id": "PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard"},
                {"title": "Battery Manager Card", "auto_id": "PcDeviceCards.PcDeviceActionCards.PcbatterymanagerXSettingsCard"},
                {"title": "Programmable Key Card", "auto_id": "PcDeviceCards.PcDeviceActionCards.ProgkeyXSettingsCard"},
                {"title": "Presence Detection Card", "auto_id": "PcDeviceCards.PcDeviceActionCards.SmartexperiencesXCoreCard"},
                {"title": "Well-being", "auto_id": "PcDeviceCards.PcDeviceActionCards.PcwellbeingXCoreCard"},
                {"title": "Display", "auto_id": "PcDeviceCards.PcDeviceActionCards.PcdisplayXControlCard"},
            ]

            container = self.main_window.child_window(auto_id="container-layout", control_type="Group")
            if not container.exists(timeout=5):
                raise Exception("Container layout not found")

            crect = container.rectangle()
            supported_cards = []

            for c in cards:
                try:
                    card = self.main_window.child_window(auto_id=c["auto_id"])
                    if card.exists(timeout=5):
                        rect = card.rectangle()
                        supported_cards.append({
                            "title": c["title"],
                            "id": c["auto_id"],
                            "width": rect.width(),
                            "height": rect.height(),
                            "x": rect.left,
                            "y": rect.top
                        })
                    else:
                        print(f"\n{c['title']} not supported on this system")
                except Exception as e:
                    print(f"\nError checking {c['title']}: {e}")

            if not supported_cards:
                raise Exception("No module cards supported on this system")

            supported_cards.sort(key=lambda c: (c["y"], c["x"]))
            rows = {}
            for card in supported_cards:
                rows.setdefault(card["y"], []).append(card)

            print(f"\nSupported Module Cards Found: {len(supported_cards)}")
            print(f"Container width: {crect.width()}px")

            for idx, card in enumerate(supported_cards, 1):
                print(f"{idx}. {card['title']}")
                print(f"   Width: {card['width']}px")

            row_left_gaps = []
            row_right_gaps = []
            horizontal_gaps_per_row = []
            vertical_gaps = []

            sorted_row_keys = sorted(rows.keys())
            for idx, row_y in enumerate(sorted_row_keys, 1):
                row_cards = rows[row_y]
                row_cards.sort(key=lambda c: c["x"])

                left_gap = row_cards[0]["x"] - crect.left
                row_left_gaps.append(left_gap)

                right_gap = crect.right - (row_cards[-1]["x"] + row_cards[-1]["width"])
                row_right_gaps.append(right_gap)

                print(f"\nRow {idx}:")
                print(f"Left Gap: {left_gap}px")
                print(f"Right Gap: {right_gap}px")

                gaps = []
                if len(row_cards) > 1:
                    for i in range(len(row_cards) - 1):
                        gap = row_cards[i + 1]["x"] - (row_cards[i]["x"] + row_cards[i]["width"])
                        gaps.append(gap)
                        print(f"{row_cards[i]['title']} → {row_cards[i + 1]['title']} = {gap}px")
                horizontal_gaps_per_row.append(gaps)

                if idx > 1:
                    prev_row_y = sorted_row_keys[idx - 2]
                    prev_row_height = max(c["height"] for c in rows[prev_row_y])
                    vertical_gap = row_y - (prev_row_y + prev_row_height)
                    vertical_gaps.append(vertical_gap)
                    print(f"Vertical gap from Row {idx-1} → Row {idx} = {vertical_gap}px")

            tolerance = 2
            all_left_same = all(abs(g - row_left_gaps[0]) <= tolerance for g in row_left_gaps)

            # Modified: Ignore right gap mismatch in the last row if it has fewer cards
            full_rows = [row for row in rows.values() if len(row) > 1]
            if len(full_rows) > 1:
                all_right_same = all(
                    abs(row_right_gaps[i] - row_right_gaps[0]) <= tolerance
                    for i in range(len(full_rows) - 1)
                )
            else:
                all_right_same = True

            all_horizontal_same = all(
                all(abs(gap - row[0]) <= tolerance for gap in row) if row else True
                for row in horizontal_gaps_per_row
            )
            all_vertical_same = all(abs(g - vertical_gaps[0]) <= tolerance for g in vertical_gaps) if vertical_gaps else True

            print("\nAlignment Check:")
            if all_left_same and all_horizontal_same and all_vertical_same:
                print("Cards are aligned (last row may be center-aligned with fewer cards)")
                print("***************")
                return True
            else:
                raise Exception("Cards are NOT perfectly aligned")

        except Exception as e:
            raise Exception(f"Error in verify_module_cards_alignment: {e}")

    def dump_ui_tree_to_file(self, filename="ui_dump.txt"):
        try:
            with open(filename, "w", encoding="utf-8") as f:
                buffer = io.StringIO()
                sys.stdout = buffer
                self.main_window.print_control_identifiers()
                sys.stdout = sys.__stdout__  # Reset stdout
                f.write(buffer.getvalue())
                buffer.close()
            print(f"UI tree dumped successfully to {filename}")
        except Exception as e:
            sys.stdout = sys.__stdout__  # Ensure stdout is reset on exception
            print(f"Failed to dump UI tree: {e}")


if __name__ == "__main__":
    hp = HpAutomation()
    hp.launch_hp_app()
    hp.connect_to_app()
    if hp.navigate_to_pc_device():
        hp.dump_ui_tree_to_file()
        hp.verify_image_fixed()
        hp.verify_device_details_alignment()
        hp.verify_ads_cards_alignment()
        hp.verify_module_cards_alignment()
