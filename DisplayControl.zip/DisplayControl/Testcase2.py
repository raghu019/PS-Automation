import time
import pyautogui
import pygetwindow as gw
from pywinauto import Application, Desktop
from pywinauto.keyboard import send_keys
import os
import re

class Pcdevice:
    TIMEOUT = 5

    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"

    # ----------------------------------------------------------
    # OPEN HP APP
    # ----------------------------------------------------------
    def open_hp_application(self):
        try:
            pyautogui.press("win")
            time.sleep(1)
            pyautogui.write(self.app_title)
            time.sleep(1)
            pyautogui.press("enter")
            time.sleep(3)

            active_window = gw.getActiveWindow()
            if active_window and self.app_title in active_window.title:
                active_window.maximize()
                time.sleep(10)
                print("HP application is open")
                return True
            else:
                print("HP app window not detected")
                return False
        except Exception as e:
            print(f"Unable to open HP application: {e}")
            return False

    # ----------------------------------------------------------
    # CONNECT TO APP WINDOW
    # ----------------------------------------------------------
    def connect_to_window(self):
        try:
            self.application = Application(backend="uia").connect(title_re=self.app_title)
            self.main_window = self.application.window(title_re=self.app_title)
            print("Connected to HP window")
            return True
        except Exception as e:
            print(f"Failed to connect to HP window: {e}")
            return False

    def connect_to_application(self):
        if not self.connect_to_window():
            return False
        time.sleep(5)
        return True

    # ----------------------------------------------------------
    # OPEN DISPLAY CONTROL INSIDE HP APP
    # ----------------------------------------------------------
    def open_display_control(self):
        try:
            self.main_window.type_keys("{PGDN}")
            time.sleep(5)
            button = self.main_window.child_window(
                title="Display",
                auto_id="PcDeviceCards.PcDeviceActionCards.PcdisplayXControlCard",
                control_type="Button"
            )
            if button.exists(timeout=5):
                button.click_input()
                time.sleep(3)
                print("Display control opened")
                return True
            else:
                print("Display button not found")
                return False
        except Exception as e:
            print(f"Failed to open display control: {e}")
            return False
        
    def get_all_display_modes_name(self):
        """Return all available display mode names from the ListBox."""
        if not self.main_window:
            print("Application not connected.")
            return []
        try:
            combo_spec = self.main_window.child_window(
                auto_id="InternalDisplay.BasicSettings.DisplayModeSelect-select",
                control_type="ComboBox"
            )
            combo = combo_spec.wrapper_object()
            combo.click_input()
            time.sleep(1)

            list_box = self.main_window.child_window(
                auto_id="InternalDisplay.BasicSettings.DisplayModeSelect-select-listbox",
                control_type="List"
            )
            if not list_box.exists(timeout=5):
                print("Dropdown ListBox not found.")
                return []

            items = list_box.descendants(control_type="ListItem")
            modes = [i.window_text().strip() for i in items if i.window_text().strip()]
            print("Detected Display Modes:", modes)
            return modes
        except Exception as e:
            print(f"Error retrieving display modes: {e}")
            return []
            
    def select_display_mode(self):
        
        if not self.main_window:
            print("Application not connected.")
            return False
        try:
            # Step 1: Expand ComboBox
            combo_spec = self.main_window.child_window(
                auto_id="InternalDisplay.BasicSettings.DisplayModeSelect-select",
                control_type="ComboBox"
            )
            combo_spec.set_focus()
            combo_spec.expand()
            time.sleep(1)

            # Step 2: Focus ListBox
            list_box_spec = self.main_window.child_window(
                auto_id="InternalDisplay.BasicSettings.DisplayModeSelect-select-listbox",
                control_type="List"
            )
            list_box_spec.wait("exists ready", timeout=10)
            list_box_spec.set_focus()

            # Step 3: Navigate to option 0
            # HOME ensures we are at the very first item
            send_keys("{HOME}")
            send_keys("{DOWN}")

            # Step 4: Confirm selection
            send_keys("{ENTER}")
            
            return True
        except Exception as e:
            print(f"Error selecting option 0: {e}")
            return False
        
    def check_display_mode_value(self):
            """Return True if Display Mode is set to 'Default', otherwise False."""
            if not self.main_window:
                print("Application not connected.")
                return False

            try:
                combo = self.main_window.child_window(
                    auto_id="InternalDisplay.BasicSettings.DisplayModeSelect-select",
                    control_type="ComboBox"
                )

                if not combo.exists(timeout=10):
                    print("Display Mode ComboBox not found.")
                    return False

                # Read the visible Static text inside the ComboBox
                selected_text = combo.child_window(control_type="Text").window_text()

                print(f"Display Mode currently selected → {selected_text}")

                return selected_text.strip().lower() == "default"

            except Exception as e:
                print(f"Error checking display mode: {e}")
                return False
        
    def get_hp_brightness_value(self):
        """Press and hold Brightness slider, then capture tooltip numeric value."""
        if not self.main_window:
            print("Application not connected.")
            return None
        try:
            slider = self.main_window.child_window(
                title="Brightness",
                auto_id="InternalDisplay.BasicSettings.BrightnessSlider",
                control_type="Slider"
            )
            slider.wait("exists ready", timeout=10)
            rect = slider.rectangle()
            x, y = rect.mid_point().x, rect.mid_point().y

            pyautogui.moveTo(x, y)
            pyautogui.mouseDown()
            time.sleep(1)

            tooltip_value = None
            texts = self.main_window.descendants(control_type="Text")
            for t in texts:
                txt = t.window_text().strip()
                if txt.isdigit():
                    tooltip_value = int(txt)   # ✅ convert to int here
                    break

            pyautogui.mouseUp()

            if tooltip_value is not None:
                print(f"Brightness tooltip value → {tooltip_value}")
                return tooltip_value
            else:
                print("No brightness tooltip value found while holding slider.")
                return None

        except Exception as e:
            print(f"Error reading brightness tooltip: {e}")
            return None
    
    def set_brightness(self, target=50):
        """Set brightness slider to target value using keyboard arrows."""
        if not self.main_window:
            print("[Error] Application not connected")
            return False

        try:
            slider = self.main_window.child_window(
                title="Brightness",
                auto_id="InternalDisplay.BasicSettings.BrightnessSlider",
                control_type="Slider"
            )

            if slider.exists(timeout=5):
                slider.click_input()
                slider.set_focus()

                current_value = self.get_hp_brightness_value()
                if current_value is None:
                    print("[Error] Could not read current brightness")
                    return False

                diff = target - current_value
                if diff < 0:
                    slider.type_keys("{LEFT}" * abs(diff))
                elif diff > 0:
                    slider.type_keys("{RIGHT}" * diff)

                print(f"[Success] Brightness set to {target}%")
                time.sleep(5)
                return True
            else:
                print("[Error] Brightness slider not found")
                return False

        except Exception as e:
            print(f"[Error] set_brightness: {str(e)}")
            return False
        
    def open_settings(self):
                """Open Windows Settings → System → Display."""
                try:
                    # Open settings
                    pyautogui.press('winleft')
                    time.sleep(1)
                    pyautogui.write('Settings')
                    time.sleep(1)
                    pyautogui.press('enter')
                    time.sleep(5)

                    windows = Desktop(backend="uia").windows(title_re=".*Settings.*", visible_only=True)
                    settings_window = next(
                        (win for win in windows if win.element_info.class_name == "ApplicationFrameWindow"), None
                    )

                    if not settings_window:
                        raise Exception("Settings window not found.")

                    app = Application(backend="uia").connect(handle=settings_window.handle)
                    self.dlg = app.window(handle=settings_window.handle)
                    self.dlg.set_focus()
                    self.dlg.maximize()
                    time.sleep(2)

                    # Click System
                    system_item = self.dlg.child_window(title="System", control_type="ListItem")
                    system_item.wait("exists ready", timeout=10)
                    print("Clicking 'System'...")
                    system_item.click_input()
                    time.sleep(3)

                    # Click Display
                    display_item = self.dlg.child_window(title="Display", control_type="ListItem")
                    display_item.wait("exists ready", timeout=10)
                    print("Clicking 'Display'...")
                    display_item.click_input()
                    time.sleep(3)

                    print("Settings → System → Display opened successfully.")

                    #print("Dumping Settings identifiers...")
                    #self.dlg.print_control_identifiers()
                    return True
                
                

                except Exception as e:
                    print(f"Error navigating Settings: {e}")
                    return False
                
    def get_settings_brightness_value(self):
        """Read brightness tooltip value from Windows Settings → System → Display."""
        try:
            # Locate the brightness slider in Settings
            slider = self.dlg.child_window(
                auto_id="SystemSettings_Display_Multimon_Brightness_Slider",
                control_type="Slider"
            )
            slider.wait("exists ready", timeout=10)

            # Get slider rectangle and move mouse to midpoint
            rect = slider.rectangle()
            x, y = rect.mid_point().x, rect.mid_point().y

            pyautogui.moveTo(x, y)
            pyautogui.mouseDown()
            time.sleep(1)

            tooltip_value = None
            texts = self.dlg.descendants(control_type="Text")
            for t in texts:
                txt = t.window_text().strip()
                if txt.isdigit():
                    tooltip_value = int(txt)
                    break

            pyautogui.mouseUp()

            if tooltip_value is not None:
                print(f"[Settings] Brightness tooltip value → {tooltip_value}")
                return tooltip_value
            else:
                print("[Settings] No brightness tooltip value found.")
                return None

        except Exception as e:
            print(f"[Error] get_settings_brightness_tooltip_value: {e}")
            return None

    def get_color_profile_value(self):
            """Check the current Color Profile value in Settings → Display."""
            try:
                # Locate the ComboBox for Color profile
                combo = self.dlg.child_window(
                    title="Color profile",
                    auto_id="SystemSettings_Display_ColorProfileSetting_ComboBox",
                    control_type="ComboBox"
                )

                if not combo.exists(timeout=10):
                    print("Color Profile ComboBox not found.")
                    return None

                # Get the selected item text
                selected_item = combo.child_window(control_type="Text")
                value = selected_item.window_text()
                print(f"Color Profile currently selected → {value}")
                return value

            except Exception as e:
                print(f"Error checking Color Profile: {e}")
                return None 

    def verify_display_mode_matches_color_profile(self):
            """Verify that HP app option 0 matches Windows Settings color profile using common words."""
            modes = self.check_display_mode_value()
            if not modes:
                print("No display modes detected.")
                return False
            expected_mode = modes[0]
            print(f"Expected mode from HP app → {expected_mode}")

            if not self.select_display_mode():
                return False

            if not self.open_settings():
                return False

            actual_profile = self.get_color_profile_value()
            if not actual_profile:
                return False

            # Normalize both strings: lowercase, remove punctuation, split into words
            def normalize(text):
                text = text.lower()
                text = re.sub(r"[^\w\s]", " ", text)  # replace punctuation with space
                return set(text.split())

            expected_words = normalize(expected_mode)
            actual_words = normalize(actual_profile)

            # Check if they share at least one common word
            common = expected_words.intersection(actual_words)

            if common:
                print(f"Verification SUCCESS → Common words {common} found between HP mode '{expected_mode}' and Settings profile '{actual_profile}'")
                return True
            else:
                print(f"Verification FAILED → No common words between HP mode '{expected_mode}' and Settings profile '{actual_profile}'")
                return False
        
    
        
    def run_second_testcase(self):
        print("\n===== Running Display Mode, Color Profile & Brightness Test =====")

        results = {}

        # 4) Set Brightness = 50
        results["Set Brightness = 50"] = self.set_brightness(50)

        # 5) Check HP Brightness Value
        hp_brightness = self.get_hp_brightness_value()
        results["Check HP Brightness Value"] = hp_brightness is not None
        if hp_brightness is not None:
            print(f"HP Brightness Value → {hp_brightness}")

        # 6) Open Settings → Display
        settings_opened = self.open_settings()
        results["Open Settings"] = settings_opened

        # 7) Check Setting Brightness Value
        settings_brightness = self.get_settings_brightness_value() if settings_opened else None
        results["Check Setting Brightness Value"] = settings_brightness is not None
        if settings_brightness is not None:
            print(f"Settings Brightness Value → {settings_brightness}")


        # 10) Verify HP Brightness vs Settings Brightness
        if hp_brightness is not None and settings_brightness is not None:
            results["HP Brightness matches Settings"] = (hp_brightness == settings_brightness)
        else:
            results["HP Brightness matches Settings"] = False

        # ------------------ SUMMARY ------------------
        print("\n===== TEST RESULTS =====")
        for test, status in results.items():
            print(f"{test:35} → {'PASS' if status else 'FAIL'}")

        final = all(results.values())
        print("\nFINAL RESULT:", "PASS" if final else "FAIL")
        print("===============================================")

        return final




# ----------------------------------------------------------
# MAIN EXECUTION
# ----------------------------------------------------------
if __name__ == "__main__":
    pc = Pcdevice()

    if not pc.open_hp_application():
        exit()

    if not pc.connect_to_application():
        exit()

    if not pc.open_display_control():
        exit()

    pc.run_second_testcase()
