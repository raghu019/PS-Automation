import time
import pyautogui
import pygetwindow as gw
from pywinauto import Application, Desktop
from pywinauto.keyboard import send_keys
import os
import sys
import io
import re


class Pcdevice:
    TIMEOUT = 5

    def __init__(self):
        self.application = None
        self.main_window = None
        self.dlg = None
        self.app_title = "HP"
        self.logs = {}  # store pass/fail results
        self.baseline_folder = os.path.join(os.getcwd(), "baseline")
        os.makedirs(self.baseline_folder, exist_ok=True)

    # ------------------------------------------------------------
    #  LOGGING UTILITY
    # ------------------------------------------------------------
    def log(self, test_name, status):
        self.logs[test_name] = status
        print(f"[{'PASS' if status else 'FAIL'}] {test_name}")

    # ------------------------------------------------------------
    # 1. OPEN HP APPLICATION
    # ------------------------------------------------------------
    def open_hp_application(self):
        try:
            pyautogui.press("win")
            time.sleep(1)
            pyautogui.write(self.app_title)
            time.sleep(1)
            pyautogui.press("enter")
            time.sleep(3)

            active_window = gw.getActiveWindow()
            status = bool(active_window and self.app_title in active_window.title)

            self.log("Open HP Application", status)

            if status:
                active_window.maximize()
                time.sleep(10)
            return status

        except Exception as e:
            print(f"Unable to open HP application: {e}")
            self.log("Open HP Application", False)
            return False

    # ------------------------------------------------------------
    # 2. CONNECT TO HP WINDOW
    # ------------------------------------------------------------
    def connect_to_window(self):
        try:
            self.application = Application(backend="uia").connect(title_re=self.app_title)
            self.main_window = self.application.window(title_re=self.app_title)

            self.log("Connect to HP Window", True)
            return True

        except Exception as e:
            print(f"Failed to connect to HP window: {e}")
            self.log("Connect to HP Window", False)
            return False

    # ------------------------------------------------------------
    # 3. CONNECT TO APP (combined)
    # ------------------------------------------------------------
    def connect_to_application(self):
        status = self.connect_to_window()
        self.log("Connect to Application", status)
        time.sleep(5)
        return status

    # ------------------------------------------------------------
    # 4. UI TREE DUMP
    # ------------------------------------------------------------
    def dump_ui_tree_to_file(self):
        if not self.main_window:
            print("Cannot dump UI tree — HP window not connected")
            self.log("Dump UI Tree", False)
            return False

        dump_path = os.path.join(self.baseline_folder, "ui_dump.txt")
        try:
            original_stdout = sys.stdout
            buffer = io.StringIO()
            sys.stdout = buffer

            self.main_window.print_control_identifiers()

            sys.stdout = original_stdout
            with open(dump_path, "w", encoding="utf-8") as f:
                f.write(buffer.getvalue())

            buffer.close()

            self.log("Dump UI Tree", True)
            return True

        except Exception as e:
            sys.stdout = original_stdout
            print(f"Dump UI Tree Error: {e}")
            self.log("Dump UI Tree", False)
            return False

    # ------------------------------------------------------------
    # 5. OPEN DISPLAY SECTION
    # ------------------------------------------------------------
    def open_display(self):
        if not self.connect_to_application():
            self.log("Open Display Section", False)
            return False

        try:
            self.main_window.type_keys('{PGDN}')
            time.sleep(5)

            button = self.main_window.child_window(
                title="Display",
                auto_id="PcDeviceCards.PcDeviceActionCards.PcdisplayXControlCard",
                control_type="Button"
            )

            status = button.exists()

            if status:
                button.click_input()
                time.sleep(2)

            self.log("Open Display Section", status)
            return status

        except Exception as e:
            print(f"Failed to open Display section: {e}")
            self.log("Open Display Section", False)
            return False

    # ------------------------------------------------------------
    # 6. GET DISPLAY MODES
    # ------------------------------------------------------------
    def get_display_modes(self):
        try:
            combo = self.main_window.child_window(
                auto_id="InternalDisplay.BasicSettings.DisplayModeSelect-select",
                control_type="ComboBox"
            ).wrapper_object()

            combo.click_input()
            time.sleep(1)

            list_box = self.main_window.child_window(
                auto_id="InternalDisplay.BasicSettings.DisplayModeSelect-select-listbox",
                control_type="List"
            )

            if not list_box.exists(timeout=5):
                self.log("Get Display Modes", False)
                return []

            items = list_box.descendants(control_type="ListItem")
            modes = [i.window_text().strip() for i in items if i.window_text().strip()]

            print("Detected Display Modes:", modes)
            self.log("Get Display Modes", bool(modes))
            return modes

        except Exception as e:
            print(f"Error retrieving display modes: {e}")
            self.log("Get Display Modes", False)
            return []

    # ------------------------------------------------------------
    # 7. SELECT OPTION 0
    # ------------------------------------------------------------
    def select_display_mode_option0(self):
        try:
            combo = self.main_window.child_window(
                auto_id="InternalDisplay.BasicSettings.DisplayModeSelect-select",
                control_type="ComboBox"
            )

            combo.set_focus()
            combo.expand()
            time.sleep(1)

            list_box = self.main_window.child_window(
                auto_id="InternalDisplay.BasicSettings.DisplayModeSelect-select-listbox",
                control_type="List"
            )
            list_box.wait("exists ready", timeout=10)
            list_box.set_focus()

            send_keys("{HOME}")
            send_keys("{ENTER}")

            print("Option 0 (sRGB Web) selected successfully.")
            self.log("Select Display Mode Option 0", True)
            return True

        except Exception as e:
            print(f"Error selecting option 0: {e}")
            self.log("Select Display Mode Option 0", False)
            return False

    # ------------------------------------------------------------
    # 8. OPEN SETTINGS → SYSTEM → DISPLAY
    # ------------------------------------------------------------
    def open_settings_and_check_power_mode(self):
        try:
            pyautogui.press('winleft')
            time.sleep(1)
            pyautogui.write('Settings')
            time.sleep(1)
            pyautogui.press('enter')
            time.sleep(5)

            windows = Desktop(backend="uia").windows(title_re=".*Settings.*", visible_only=True)
            settings_window = next(
                (win for win in windows if win.element_info.class_name == "ApplicationFrameWindow"), None
            )

            if not settings_window:
                raise Exception("Settings window not found.")

            app = Application(backend="uia").connect(handle=settings_window.handle)
            self.dlg = app.window(handle=settings_window.handle)

            self.dlg.set_focus()
            self.dlg.maximize()
            time.sleep(2)

            self.dlg.child_window(title="System", control_type="ListItem").wait("exists ready", timeout=10).click_input()
            time.sleep(2)

            self.dlg.child_window(title="Display", control_type="ListItem").wait("exists ready", timeout=10).click_input()
            time.sleep(2)

            self.log("Open Windows Settings", True)
            return True

        except Exception as e:
            print(f"Error navigating Settings: {e}")
            self.log("Open Windows Settings", False)
            return False

    # ------------------------------------------------------------
    # 9. GET COLOR PROFILE
    # ------------------------------------------------------------
    def get_color_profile_value(self):
        try:
            combo = self.dlg.child_window(
                title="Color profile",
                auto_id="SystemSettings_Display_ColorProfileSetting_ComboBox",
                control_type="ComboBox"
            )

            if not combo.exists(timeout=10):
                self.log("Get Color Profile", False)
                return None

            value = combo.child_window(control_type="Text").window_text()
            print(f"Color Profile currently selected → {value}")

            self.log("Get Color Profile", True)
            return value

        except Exception as e:
            print(f"Error checking Color Profile: {e}")
            self.log("Get Color Profile", False)
            return None

    # ------------------------------------------------------------
    # 10. VERIFY DISPLAY MODE VS COLOR PROFILE
    # ------------------------------------------------------------
    def verify_display_mode_matches_color_profile(self):
        modes = self.get_display_modes()
        if not modes:
            self.log("Verify Mode vs Profile", False)
            return False

        expected_mode = modes[0]
        print(f"Expected HP Mode → {expected_mode}")

        if not self.select_display_mode_option0(): 
            self.log("Verify Mode vs Profile", False)
            return False

        if not self.open_settings_and_check_power_mode(): 
            self.log("Verify Mode vs Profile", False)
            return False

        actual_profile = self.get_color_profile_value()
        if not actual_profile:
            self.log("Verify Mode vs Profile", False)
            return False

        def normalize(text):
            return set(re.sub(r"[^\w\s]", " ", text.lower()).split())

        common = normalize(expected_mode).intersection(normalize(actual_profile))

        status = bool(common)
        print(f"Common Words → {common}")

        self.log("Verify Mode vs Profile", status)
        return status

    # ------------------------------------------------------------
    # SUMMARY
    # ------------------------------------------------------------
    def print_summary(self):
        print("\n========== TEST SUMMARY ==========")
        for name, result in self.logs.items():
            print(f"{name:40} → {'PASS' if result else 'FAIL'}")
        print("=================================\n")


# ---------------- Run Example ----------------
if __name__ == "__main__":
    pc = Pcdevice()
    pc.open_hp_application()
    pc.connect_to_window()
    pc.connect_to_application()
    pc.open_display()
    pc.verify_display_mode_matches_color_profile()
    pc.print_summary()
