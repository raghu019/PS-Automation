import time
import pyautogui
import pygetwindow as gw
from pywinauto import Application, Desktop
from pywinauto.keyboard import send_keys
import os

class Pcdevice:
    TIMEOUT = 5

    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"

    # ----------------------------------------------------------
    # OPEN HP APP
    # ----------------------------------------------------------
    def open_hp_application(self):
        try:
            pyautogui.press("win")
            time.sleep(1)
            pyautogui.write(self.app_title)
            time.sleep(1)
            pyautogui.press("enter")
            time.sleep(3)

            active_window = gw.getActiveWindow()
            if active_window and self.app_title in active_window.title:
                active_window.maximize()
                time.sleep(10)
                print("HP application is open")
                return True
            else:
                print("HP app window not detected")
                return False
        except Exception as e:
            print(f"Unable to open HP application: {e}")
            return False

    # ----------------------------------------------------------
    # CONNECT TO APP WINDOW
    # ----------------------------------------------------------
    def connect_to_window(self):
        try:
            self.application = Application(backend="uia").connect(title_re=self.app_title)
            self.main_window = self.application.window(title_re=self.app_title)
            print("Connected to HP window")
            return True
        except Exception as e:
            print(f"Failed to connect to HP window: {e}")
            return False

    def connect_to_application(self):
        if not self.connect_to_window():
            return False
        time.sleep(5)
        return True

    # ----------------------------------------------------------
    # OPEN DISPLAY CONTROL INSIDE HP APP
    # ----------------------------------------------------------
    def open_display_control(self):
        try:
            self.main_window.type_keys("{PGDN}")
            time.sleep(3)
            button = self.main_window.child_window(
                title="Display",
                auto_id="PcDeviceCards.PcDeviceActionCards.PcdisplayXControlCard",
                control_type="Button"
            )
            if button.exists(timeout=5):
                button.click_input()
                time.sleep(3)
                print("Display control opened")
                return True
            else:
                print("Display button not found")
                return False
        except Exception as e:
            print(f"Failed to open display control: {e}")
            return False

    # ----------------------------------------------------------
    # CHECKERS FOR THE FIRST TEST CASE
    # ----------------------------------------------------------

    def check_display_mode_value(self):
        """Check if Display Mode is 'Default' """
        try:
            combo = self.main_window.child_window(
                auto_id="InternalDisplay.BasicSettings.DisplayModeSelect-select",
                control_type="ComboBox"
            )
            combo.wait("exists ready", timeout=10)
            selected_text = combo.child_window(control_type="Text").window_text()
            print(f"Display Mode: {selected_text}")
            return selected_text.strip().lower() == "default"
        except:
            print("Error reading Display Mode")
            return False

    def is_adjust_contrast_off(self):
        """Check if Adjust Contrast is OFF"""
        try:
            toggle = self.main_window.child_window(
                auto_id="InternalDisplay.BasicSettings.ContrastSwitch__toggle",
                control_type="Button"
            )
            toggle.wait("exists ready", timeout=10)
            state = toggle.get_toggle_state()  # 0 = OFF
            print(f"Adjust Contrast state: {state}")
            return state == 0
        except:
            print("Error reading Adjust Contrast toggle")
            return False

    def get_brightness_value(self):
        """Press and hold Brightness slider, then capture tooltip numeric value."""
        if not self.main_window:
            print("Application not connected.")
            return None
        try:
            slider = self.main_window.child_window(
                title="Brightness",
                auto_id="InternalDisplay.BasicSettings.BrightnessSlider",
                control_type="Slider"
            )
            slider.wait("exists ready", timeout=10)
            rect = slider.rectangle()
            x, y = rect.mid_point().x, rect.mid_point().y

            pyautogui.moveTo(x, y)
            pyautogui.mouseDown()
            time.sleep(1)

            tooltip_value = None
            texts = self.main_window.descendants(control_type="Text")
            for t in texts:
                txt = t.window_text().strip()
                if txt.isdigit():
                    tooltip_value = int(txt)   # ✅ convert to int here
                    break

            pyautogui.mouseUp()

            if tooltip_value is not None:
                print(f"Brightness tooltip value → {tooltip_value}")
                return tooltip_value
            else:
                print("No brightness tooltip value found while holding slider.")
                return None

        except Exception as e:
            print(f"Error reading brightness tooltip: {e}")
            return None

    def is_hdr_off(self):
        """Check if HDR is OFF"""
        try:
            toggle = self.main_window.child_window(
                auto_id="InternalDisplay.BasicSettings.HdrSwitch__toggle",
                control_type="Button"
            )
            toggle.wait("exists ready", timeout=10)
            state = toggle.get_toggle_state()  # 0 = OFF
            print(f"HDR State: {state}")
            return state == 0
        except:
            print("Error reading HDR toggle")
            return False

    # ----------------------------------------------------------
    # FIRST TEST CASE
    # ----------------------------------------------------------
    def run_first_time_launch_test(self):
        print("\n===== We are checking by default values. =====")

        results = {}

        # 1) Display Mode
        results["Display Mode = Default"] = self.check_display_mode_value()

        # 2) Adjust Contrast
        results["Adjust Contrast = OFF"] = self.is_adjust_contrast_off()

        # 3) Brightness = 90
        brightness = self.get_brightness_value()
        results["Brightness = 90"] = (brightness == 90)

        # 4) HDR toggle
        results["HDR = OFF"] = self.is_hdr_off()

        # ------------------ SUMMARY ------------------
        print("\n===== TEST RESULTS =====")
        for test, status in results.items():
            print(f"{test:30} → {'PASS' if status else 'FAIL'}")

        final = all(results.values())
        print("\nFINAL RESULT:", "PASS" if final else "FAIL")
        print("===============================================")

        return final


# ----------------------------------------------------------
# MAIN EXECUTION
# ----------------------------------------------------------
if __name__ == "__main__":
    pc = Pcdevice()

    if not pc.open_hp_application():
        exit()

    if not pc.connect_to_application():
        exit()

    if not pc.open_display_control():
        exit()

    pc.run_first_time_launch_test()
