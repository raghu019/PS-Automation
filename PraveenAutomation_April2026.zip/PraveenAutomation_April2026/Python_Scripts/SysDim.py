import os
os.environ["PYGAME_HIDE_SUPPORT_PROMPT"] = "hide"

import time
import subprocess
import pyautogui
import pygetwindow as gw
import shutil
from PIL import ImageChops, ImageStat
from pywinauto import Application
from pywinauto.keyboard import send_keys
from datetime import datetime


pyautogui.FAILSAFE = True

# ============================================================
# CONFIG
# ============================================================
APP_TITLE = "HP"

AUTO_FOCUS_TOGGLE = "SystemControl.SystemControl.FocusModeToggle__toggle"

FOCUS_LABEL = "Focus mode"
DIM_LABEL = "Dim background windows"

NOTEPAD_EXE = "notepad.exe"
NOTEPAD_TITLE_KEYWORD = "Notepad"

SCREENSHOT_PATH = r"C:\PraveenAutomation\ROBOT-OTA\screenshots"

MIN_LUMINANCE_DROP_FOR_DIM = 8.0
MIN_LUMINANCE_RISE_FOR_UNDIM = 8.0
MIN_DIFF_SCORE = 5.0

os.makedirs(SCREENSHOT_PATH, exist_ok=True)


def save_screenshot(name):
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = os.path.join(SCREENSHOT_PATH, f"{name}.png")
    pyautogui.screenshot(path)
    print(f"[INFO] Screenshot saved: {path}")


# ============================================================
# HP APP CONTROL
# ============================================================
class MyHP:
    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = APP_TITLE
        self.check_results = []

    def _log(self, name, status, msg=""):
        status = bool(status)
        self.check_results.append(status)
        print(f"[{'PASS' if status else 'FAIL'}] {name}" + (f" - {msg}" if msg else ""))

    def _info(self, name, msg=""):
        print(f"[INFO] {name}" + (f" - {msg}" if msg else ""))

    def open_hp_application(self) -> bool:
        pyautogui.press("winleft")
        time.sleep(1)
        pyautogui.write(self.app_title)
        time.sleep(1)
        pyautogui.press("enter")

        time.sleep(12)

        win = None
        try:
            win = gw.getActiveWindow()
        except Exception:
            pass

        if not win or self.app_title not in (win.title or ""):
            try:
                candidates = [w for w in gw.getAllWindows() if self.app_title in (w.title or "")]
                if candidates:
                    win = candidates[0]
                    win.activate()
                    time.sleep(1)
            except Exception:
                pass

        if win and self.app_title in (win.title or ""):
            try:
                win.maximize()
            except Exception:
                pass
            self._log("Open Application", True)
            return True

        self._log("Open Application", False)
        return False

    def connect_to_application(self) -> bool:
        try:
            self.application = Application(backend="uia").connect(
                title_re=f".*{self.app_title}.*", timeout=15
            )
            self.main_window = self.application.window(title_re=f".*{self.app_title}.*")
            time.sleep(2)
            self._log("Connect to Application", True)
            return True
        except Exception as e:
            self._log("Connect to Application", False, str(e))
            return False

    def close_hp_application(self):
        try:
            if self.main_window:
                self.main_window.close()
                time.sleep(2)
            self._log("Close Application", True)
        except Exception as e:
            self._log("Close Application", False, str(e))

    def focus_hp(self):
        try:
            self.main_window.set_focus()
            time.sleep(0.5)
        except Exception:
            pass

    def open_System_Control(self) -> bool:
        try:
            self.focus_hp()

            btn = self.main_window.child_window(title="System control", control_type="Button")

            if btn.exists(timeout=3) and btn.is_visible():
                btn.wait("visible", timeout=5)
                btn.set_focus()
                time.sleep(0.3)
                btn.click_input()
                time.sleep(3)
                self._log("Open System control", True)
                return True

            return False

        except Exception as e:
            self._log("Open System control", False, str(e))
            return False

    def open_System_Control_with_scroll_retry(self) -> bool:
        try:
            self.focus_hp()
            self.main_window.wait("ready", timeout=15)

            time.sleep(12)

            if self.open_System_Control():
                return True

            send_keys("{PGDN}")
            time.sleep(3)

            if self.open_System_Control():
                return True

            time.sleep(5)
            send_keys("{PGDN}")
            time.sleep(3)

            if self.open_System_Control():
                return True

            send_keys("{PGDN}")
            time.sleep(2)
            send_keys("{PGUP}")
            time.sleep(2)

            if self.open_System_Control():
                return True

            self._log("Open System control", False, "Not found after scrolling")
            return False

        except Exception as e:
            self._log("Open System control", False, str(e))
            return False


# ============================================================
# IMAGE HELPERS
# ============================================================
def capture_fullscreen():
    return pyautogui.screenshot()

def crop_image(img, left, top, right, bottom):
    return img.crop((left, top, right, bottom))

def mean_luminance(img):
    return float(ImageStat.Stat(img.convert("L")).mean[0])

def diff_score(a, b):
    d = ImageChops.difference(a.convert("L"), b.convert("L"))
    stat = ImageStat.Stat(d)
    return float((stat.mean[0] ** 0.5) * 16.0)


# ============================================================
# FOCUS MODE VALIDATOR
# ============================================================
class FocusModeValidator:
    def __init__(self, hp: MyHP):
        self.hp = hp
        self.notepad_win = None

    def log(self, name, ok, msg=""):
        print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f" - {msg}" if msg else ""))

    def wait_for_focus_mode_ui(self, timeout=20):
        end = time.time() + timeout
        while time.time() < end:
            try:
                scope = self.hp.main_window

                label1 = scope.child_window(title=FOCUS_LABEL, control_type="Text")
                label2 = scope.child_window(title=DIM_LABEL, control_type="Text")

                if label1.exists(timeout=1) and label2.exists(timeout=1):
                    return True

            except Exception:
                pass

            time.sleep(0.5)

        return False

    def find_focus_toggle(self):
        try:
            return self.hp.main_window.child_window(
                title_re=".*Focus.*",
                control_type="Button"
            )
        except Exception:
            return None

    def set_focus_mode(self, turn_on=True):
        self.hp.focus_hp()

        t = self.find_focus_toggle()
        if not t or not t.exists():
            self.log("Focus toggle", False)
            return False

        try:
            current_state = t.get_toggle_state() if hasattr(t, "get_toggle_state") else None

            if current_state is not None:
                if turn_on and current_state == 1:
                    self.log("Focus mode ON", True)
                    return True
                if not turn_on and current_state == 0:
                    self.log("Focus mode OFF", True)
                    return True

            t.set_focus()
            time.sleep(0.3)
            t.click_input()
            time.sleep(1.2)

            self.log(f"Focus mode {'ON' if turn_on else 'OFF'}", True)
            return True

        except Exception as e:
            self.log("Toggle click", False, str(e))
            return False

    def get_hp_screen_region(self):
        r = self.hp.main_window.rectangle()
        return (r.left + 60, r.top + 110, r.right - 60, r.bottom - 60)

    def capture_hp_region(self):
        full = capture_fullscreen()
        return crop_image(full, *self.get_hp_screen_region())

    def open_notepad(self):
        subprocess.Popen([NOTEPAD_EXE])
        time.sleep(2)
        wins = [w for w in gw.getAllWindows() if "Notepad" in (w.title or "")]
        if wins:
            self.notepad_win = wins[0]
            return True
        return False

    def activate_notepad(self):
        if self.notepad_win:
            self.notepad_win.activate()
            time.sleep(1)

    def validate_turn_on_and_dim(self):
        self.hp.focus_hp()

        # OFF first
        self.set_focus_mode(False)

        if not self.open_notepad():
            self.log("Notepad Open", False)
            return False

        self.activate_notepad()

        img_off = self.capture_hp_region()
        save_screenshot("toggle_off_state")

        # ON
        self.hp.focus_hp()
        self.set_focus_mode(True)

        self.activate_notepad()

        img_on = self.capture_hp_region()
        save_screenshot("toggle_on_state")

        score = diff_score(img_off, img_on)
        print(f"[INFO] Diff Score: {score}")

        return score > MIN_DIFF_SCORE


    def clear_screenshots(self):
        if os.path.exists(SCREENSHOT_PATH):
            for f in os.listdir(SCREENSHOT_PATH):
                try:
                    os.remove(os.path.join(SCREENSHOT_PATH, f))
                except:
                    pass


# ============================================================
# RUNNER
# ============================================================
def run_focus_mode_test_case():
    print("=== Started Focus Mode Validation Script ===")

    hp = MyHP()

    if not hp.open_hp_application():
        print("❌ STOP: HP App launch failed")
        return False

    if not hp.connect_to_application():
        print("❌ STOP: Connection failed")
        return False

    print("✅ PASS: HP App launched")

    print("[INFO] Waiting 12 sec for modules...")
    time.sleep(12)

    if not hp.open_System_Control_with_scroll_retry():
        print("❌ STOP: System Control not found")
        return False

    print("✅ PASS: Navigated to System Control")

    validator = FocusModeValidator(hp)

    if not validator.wait_for_focus_mode_ui():
        print("❌ STOP: UI not loaded")
        return False

    print("✅ PASS: System Control opened")

    toggle = validator.find_focus_toggle()
    if not toggle or not toggle.exists():
        print("❌ STOP: Dim toggle not found")
        return False

    print("✅ PASS: Dim toggle found")

    print("[INFO] Validating DIM behavior...")
    result = validator.validate_turn_on_and_dim()

    if not result:
        print("❌ FAIL: Dim not working")
        return False

    print("✅ PASS: Dim working")

    hp.close_hp_application()

    try:
        for w in gw.getAllWindows():
            if "Notepad" in (w.title or ""):
                w.close()
    except:
        pass

    print("✅ Test Completed Successfully")
    return True


if __name__ == "__main__":
    run_focus_mode_test_case()