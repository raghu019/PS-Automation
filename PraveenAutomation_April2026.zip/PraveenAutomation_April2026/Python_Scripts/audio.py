import os
os.environ["PYGAME_HIDE_SUPPORT_PROMPT"] = "hide"

import time
import re
import pyautogui
import pygetwindow as gw
from pywinauto import Application

import pygame
import numpy as np
import sounddevice as sd

pyautogui.FAILSAFE = True


# ============================================================
# CONFIG
# ============================================================

APP_TITLE = "HP"

# ✅ Update if needed
TEST_MUSIC_PATH = r"C:\PraveenAutomation\ROBOT-OTA\Source\sample music.mp3"

# ✅ IMPORTANT: Stereo Mix / What U Hear INPUT device index
# If unsure, set None once to print device list and choose correct index.
LOOPBACK_DEVICE_INDEX = 1

SAMPLE_RATE = 44100
RECORD_SECONDS = 6

# ✅ KEEP OLD SCROLL METHOD
SCROLL_DOWN_AMOUNT = -698
SCROLL_UP_AMOUNT = 900

# Systems where Audio card is far off-screen need more than 1 scroll
AUDIO_OPEN_SCROLL_RETRIES = 8

# Resolution/preset scrolling
PRESET_SCROLL_TRIES = 8

# Equalizer scanning (scroll-aware)
EQUALIZER_SCAN_TRIES = 8

# Preset apply wait
APPLY_PRESET_WAIT_SEC = 2.5

# Audio analysis thresholds
SIMILARITY_THRESHOLD = 0.995
MIN_DISTANCE_THRESHOLD = 0.01

# Retry capture if feature extraction fails
CAPTURE_RETRIES = 2

# Retry analysis once if too similar (helps flakiness)
ANALYSIS_RETRY_ONCE = True

# Scenario keywords
SPEAKER_OUTPUT_KW = "speaker"
SPEAKER_INPUT_KW = "microphone array"
HEADPHONE_OUTPUT_KW = "headphone"
HEADPHONE_INPUT_KW = "headset microphone"

SPEAKER_PRESETS = ["music", "movie", "voice"]
HEADPHONE_PRESETS = ["music", "movie", "voice", "strategy", "rpg", "shooter"]


# ============================================================
# UTILS
# ============================================================

def norm(s: str) -> str:
    return (s or "").strip().lower()

def list_audio_devices():
    devices = sd.query_devices()
    print("\n=== Available audio devices (sounddevice) ===")
    for i, dev in enumerate(devices):
        print(f"{i}: {dev['name']} | max_in={dev['max_input_channels']} max_out={dev['max_output_channels']}")
    print("===========================================\n")


# ============================================================
# HP AUDIO AUTOMATION CLASS
# ============================================================

class MyHP:
    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = APP_TITLE

        self.samplerate = SAMPLE_RATE
        self.loopback_device_index = LOOPBACK_DEVICE_INDEX

        self.check_results = []

        # Tracks if we had to scroll to reach Audio card (old behavior)
        self.scrolled_for_audio = False

    # ---------------- Logging ----------------
    def _log(self, name, status, msg=""):
        status = bool(status)
        self.check_results.append(status)
        print(f"[{'PASS' if status else 'FAIL'}] {name}" + (f" - {msg}" if msg else ""))

    def _info(self, name, msg=""):
        print(f"[INFO] {name}" + (f" - {msg}" if msg else ""))

    # ---------------- App control ----------------
    def open_hp_application(self) -> bool:
        pyautogui.press("winleft")
        time.sleep(1)
        pyautogui.write(self.app_title)
        time.sleep(1)
        pyautogui.press("enter")
        time.sleep(6)

        win = None
        try:
            win = gw.getActiveWindow()
        except Exception:
            pass

        if not win or self.app_title not in (win.title or ""):
            try:
                candidates = [w for w in gw.getAllWindows() if self.app_title in (w.title or "")]
                if candidates:
                    win = candidates[0]
                    try:
                        win.activate()
                        time.sleep(1)
                    except Exception:
                        pass
            except Exception:
                win = None

        if win and self.app_title in (win.title or ""):
            try:
                win.maximize()
            except Exception:
                pass
            self._log("Open Application", True)
            return True

        self._log("Open Application", False, "HP window not active")
        return False

    def connect_to_application(self) -> bool:
        try:
            self.application = Application(backend="uia").connect(title_re=f".*{self.app_title}.*", timeout=15)
            self.main_window = self.application.window(title_re=f".*{self.app_title}.*")
            time.sleep(2)
            self._log("Connect to Application", True)
            return True
        except Exception as e:
            self._log("Connect to Application", False, str(e))
            return False

    def close_hp_application(self) -> bool:
        try:
            if self.main_window:
                try:
                    self.main_window.close()
                except Exception:
                    pass
                time.sleep(2)
            self._log("Close Application", True)
            return True
        except Exception as e:
            self._log("Close Application", False, str(e))
            return False

    # ---------------- Optional popups (keep your behavior) ----------------
    def click_accept_all(self) -> bool:
        try:
            self.main_window.set_focus()
            btn = self.main_window.child_window(title="Accept all", control_type="Button")
            start = time.time()
            while time.time() - start < 5:
                if btn.exists() and btn.is_visible():
                    btn.click_input()
                    time.sleep(1.5)
                    self._log("Accept all button clicked", True)
                    return True
                time.sleep(0.4)
            self._log("Accept all button not visible for more than 5 seconds, skipping...", True)
            return True
        except Exception as e:
            self._log("Accept all click failed", False, str(e))
            return False

    def click_skip(self) -> bool:
        try:
            self.main_window.set_focus()
            btn = self.application.top_window().child_window(title="Skip", control_type="Button")
            start = time.time()
            while time.time() - start < 5:
                if btn.exists() and btn.is_visible():
                    btn.click_input()
                    time.sleep(1.5)
                    self._log("Skip button clicked", True)
                    return True
                time.sleep(0.4)
            self._log("Skip button not visible for more than 5 seconds, skipping...", True)
            return True
        except Exception as e:
            self._log("Skip click failed", False, str(e))
            return False

    # ---------------- Focus + scroll safety (still old scroll amount) ----------------
    def focus_hp(self):
        try:
            self.main_window.set_focus()
        except Exception:
            pass
        time.sleep(0.2)

    def hp_rect(self):
        try:
            return self.main_window.rectangle()
        except Exception:
            return None

    def move_mouse_inside_hp(self):
        self.focus_hp()
        r = self.hp_rect()
        if not r:
            return
        x = r.left + int(r.width() * 0.5)
        y = r.top + int(r.height() * 0.55)
        pyautogui.moveTo(x, y, duration=0.05)

    def scroll_once(self):
        # KEEP old scroll amount; ensure HP focus so VS Code doesn't scroll
        self.focus_hp()
        self.move_mouse_inside_hp()
        pyautogui.scroll(SCROLL_DOWN_AMOUNT)
        time.sleep(1)

    def scroll_to_top(self):
        self.focus_hp()
        self.move_mouse_inside_hp()
        for _ in range(10):
            pyautogui.scroll(SCROLL_UP_AMOUNT)
            time.sleep(0.1)

    # ---------------- Open Audio (single attempt, no interim FAIL poison) ----------------
    def open_Audio(self) -> bool:
        """
        Single attempt to click Audio.
        IMPORTANT: Do NOT log FAIL when not visible (retry loop handles it).
        """
        try:
            self.main_window.set_focus()
            self.main_window.wait("ready", timeout=15)

            btn = self.main_window.child_window(title="Audio", control_type="Button")
            if btn.exists(timeout=2) and btn.is_visible():
                btn.click_input()
                time.sleep(3)
                self._log("Open Audio", True)
                return True

            # do not log FAIL here (prevents check_results poisoning)
            return False

        except Exception as e:
            # only log real exception
            self._log("Open Audio", False, str(e))
            return False

    def open_audio_with_scroll_retry(self, max_scrolls=AUDIO_OPEN_SCROLL_RETRIES) -> bool:
        """
        Your old behavior: open -> scroll_once -> retry, but robust for far off-screen systems.
        Sets self.scrolled_for_audio = True if scrolling was needed.
        Logs FAIL only once if all retries exhausted.
        """
        self.scrolled_for_audio = False

        try:
            self.main_window.set_focus()
            self.main_window.wait("ready", timeout=15)
        except Exception:
            pass

        # attempt 0
        if self.open_Audio():
            return True

        # else scroll+retry
        for attempt in range(1, max_scrolls + 1):
            self._info("Open Audio", f"Audio off-screen -> scrolling and retrying ({attempt}/{max_scrolls})")
            self.scroll_once()
            self.scrolled_for_audio = True
            if self.open_Audio():
                return True

        self._log("Open Audio", False, "Audio button not found after scroll retries")
        return False

    # ---------------- Dropdown selection (Auto IDs) ----------------
    def select_output_input_dropdowns(self, output_kw, input_kw):
        self.scroll_to_top()

        out_combo = None
        in_combo = None
        try:
            out_combo = self.main_window.child_window(
                auto_id="Audio.BasicSettings.DefaultOutputDevice-select", control_type="ComboBox"
            )
            in_combo = self.main_window.child_window(
                auto_id="Audio.BasicSettings.DefaultInputDevice-select", control_type="ComboBox"
            )
        except Exception:
            combos = self.main_window.descendants(control_type="ComboBox")
            if len(combos) >= 2:
                out_combo = combos[0]
                in_combo = combos[1]
            elif len(combos) == 1:
                out_combo = combos[0]
                in_combo = combos[0]

        if out_combo is None or in_combo is None:
            self._log("Select Output/Input Dropdowns", False, "ComboBox controls not found")
            return False

        def pick(combo, kw):
            self.focus_hp()
            try:
                combo.click_input()
            except Exception:
                try:
                    r = combo.rectangle()
                    pyautogui.click(r.left + 15, r.top + 15)
                except Exception:
                    return False
            time.sleep(0.4)

            try:
                top = self.application.top_window()
                for it in top.descendants(control_type="ListItem"):
                    if kw.lower() in norm(it.window_text()):
                        it.click_input()
                        time.sleep(0.4)
                        return True
            except Exception:
                pass

            pyautogui.write(kw)
            pyautogui.press("enter")
            time.sleep(0.4)
            return True

        ok_out = pick(out_combo, output_kw)
        ok_in = pick(in_combo, input_kw)

        self._log(f"Select Output ({output_kw})", ok_out)
        self._log(f"Select Input ({input_kw})", ok_in)
        return ok_out and ok_in

    # ---------------- Detect output device ----------------
    def detect_output_device(self):
        try:
            combos = self.main_window.descendants(control_type="ComboBox")
            if not combos:
                self._log("Detect Output Device", False, "No ComboBox found")
                return None

            combo = combos[0]
            try:
                current = combo.get_value()
            except Exception:
                current = combo.window_text()

            if not current:
                self._log("Detect Output Device", False, "Unable to read output device")
                return None

            print(f"\nDetected Output Device: {current}")
            return current
        except Exception as e:
            self._log("Detect Output Device", False, str(e))
            return None

    # ---------------- Equalizer validation (scroll-aware + visible-only) ----------------
    def _equalizer_visible_on_screen(self) -> bool:
        try:
            texts = self.main_window.descendants(control_type="Text")
            for t in texts:
                try:
                    if t.is_visible() and "equalizer" in norm(t.window_text()):
                        return True
                except Exception:
                    continue
        except Exception:
            pass
        return False

    def verify_equalizer_present(self, output_source: str) -> bool:
        src = norm(output_source)
        self.scroll_to_top()

        if "speaker" in src:
            for _ in range(EQUALIZER_SCAN_TRIES):
                if self._equalizer_visible_on_screen():
                    self._log("Equalizer visible for Speakers", True)
                    return True
                self.scroll_once()
            self._log("Equalizer NOT visible for Speakers", False,
                      "Expected Equalizer but not detected after scrolling")
            return False

        if "headphone" in src:
            for _ in range(EQUALIZER_SCAN_TRIES):
                if self._equalizer_visible_on_screen():
                    self._log("Equalizer visible for Headphones", False,
                              "Equalizer detected but should not show")
                    return False
                self.scroll_once()
            self._log("Equalizer NOT visible for Headphones", True)
            return True

        self._log("Equalizer Validation", False, f"Unknown output source: {output_source}")
        return False

    # ---------------- Presets (RadioButton only) ----------------
    def _visible_radio_names(self):
        names = []
        try:
            radios = self.main_window.descendants(control_type="RadioButton")
            for r in radios:
                try:
                    if r.is_visible():
                        t = norm(r.window_text())
                        if t:
                            names.append(t)
                except Exception:
                    continue
        except Exception:
            pass
        return names

    def ensure_presets_present(self, expected_presets) -> bool:
        expected_set = set(map(norm, expected_presets))
        for _ in range(PRESET_SCROLL_TRIES):
            found = set(self._visible_radio_names())
            missing = sorted(list(expected_set - found))
            if not missing:
                self._log("Validate Presets Visible", True, f"Found {sorted(list(expected_set))}")
                return True
            self._info("Presets not visible", f"Missing {missing} -> scrolling to bring into view...")
            self.scroll_once()
        self._log("Validate Presets Visible", False, f"Missing presets: {missing}")
        return False

    def find_radio_by_text(self, preset_name: str):
        key = norm(preset_name)
        try:
            radios = self.main_window.descendants(control_type="RadioButton")
            for r in radios:
                if norm(r.window_text()) == key:
                    return r
        except Exception:
            pass
        return None

    def select_preset_and_verify(self, preset_name: str) -> bool:
        """
        Strategy/RPG/Shooter sometimes don't expose toggle state.
        If not confirmable, proceed to audio capture/analysis (real validation).
        """
        rb = self.find_radio_by_text(preset_name)
        if not rb:
            self._log(f"Preset '{preset_name}' selected", False, "RadioButton not found")
            return False

        self.focus_hp()
        try:
            rb.scroll_into_view()
        except Exception:
            pass

        clicked = False
        for _ in range(4):
            try:
                rb.click_input()
                clicked = True
            except Exception:
                pass

            time.sleep(APPLY_PRESET_WAIT_SEC)

            # confirm if possible
            try:
                if rb.get_toggle_state() == 1:
                    self._log(f"Preset '{preset_name}' selected", True, "Toggle state ON")
                    return True
            except Exception:
                pass

            try:
                if rb.is_selected():
                    self._log(f"Preset '{preset_name}' selected", True, "Selected pattern")
                    return True
            except Exception:
                pass

        if not clicked:
            self._log(f"Preset '{preset_name}' selected", False, "Unable to click preset")
            return False

        self._log(
            f"Preset '{preset_name}' selected",
            True,
            "Selection state not readable; proceeding to audio capture/analysis validation"
        )
        return True

    # -------- Playback + record --------
    def start_music(self) -> bool:
        try:
            pygame.mixer.init()
            pygame.mixer.music.load(TEST_MUSIC_PATH)
            pygame.mixer.music.play(-1)
            time.sleep(1)
            playing = bool(pygame.mixer.music.get_busy())
            self._log("Start Continuous Playback", playing, "Music looping")
            return playing
        except Exception as e:
            self._log("Start Continuous Playback", False, str(e))
            return False

    def stop_music(self):
        try:
            pygame.mixer.music.stop()
            pygame.mixer.quit()
            self._log("Stop Playback", True)
        except Exception as e:
            self._log("Stop Playback", False, str(e))

    def record_system_audio(self, duration_sec: int):
        if self.loopback_device_index is None:
            list_audio_devices()
            self._log("Record Audio", False, "LOOPBACK_DEVICE_INDEX is None. Set correct index and rerun.")
            return None

        try:
            frames = int(duration_sec * self.samplerate)
            self._log("Record Audio", True, f"Recording {duration_sec}s from device index {self.loopback_device_index}")

            audio = sd.rec(
                frames,
                samplerate=self.samplerate,
                channels=2,
                dtype="float32",
                device=self.loopback_device_index
            )
            sd.wait()

            if audio.ndim > 1:
                audio = np.mean(audio, axis=1)

            audio = audio - np.mean(audio)
            return audio
        except Exception as e:
            self._log("Record Audio", False, str(e))
            return None

    def extract_band_feature(self, audio):
        if audio is None or len(audio) == 0:
            return None

        window = np.hanning(len(audio))
        audio = audio * window

        spectrum = np.abs(np.fft.rfft(audio))
        freqs = np.fft.rfftfreq(len(audio), 1 / self.samplerate)

        bands = [
            (20, 60),
            (60, 250),
            (250, 500),
            (500, 2000),
            (2000, 4000),
            (4000, 6000),
            (6000, 20000)
        ]

        feat = []
        for lo, hi in bands:
            idx = np.where((freqs >= lo) & (freqs <= hi))[0]
            feat.append(float(np.mean(spectrum[idx])) if len(idx) else 0.0)

        feat = np.array(feat, dtype=np.float32)
        nrm = float(np.linalg.norm(feat))
        if nrm > 0:
            feat = feat / nrm
        return feat

    def cosine_similarity(self, f1, f2):
        if f1 is None or f2 is None:
            return 0.0
        n = min(len(f1), len(f2))
        a = f1[:n]
        b = f2[:n]
        denom = float(np.linalg.norm(a) * np.linalg.norm(b))
        if denom == 0:
            return 0.0
        return float(np.dot(a, b) / denom)

    def feature_distance(self, f1, f2):
        if f1 is None or f2 is None:
            return float("inf")
        n = min(len(f1), len(f2))
        return float(np.linalg.norm(f1[:n] - f2[:n]))


# ============================================================
# SCENARIO RUNNER
# ============================================================

def run_test_case_scenario(output_kw, input_kw) -> bool:
    print(f"=== Started Audio Presets Script ({output_kw}/{input_kw}) ===")
    hp = MyHP()

    if not hp.open_hp_application():
        return False
    if not hp.connect_to_application():
        hp.close_hp_application()
        return False

    if not hp.click_accept_all():
        hp.close_hp_application()
        return False
    if not hp.click_skip():
        hp.close_hp_application()
        return False

    # ✅ Your old off-screen behavior (robust)
    if not hp.open_audio_with_scroll_retry(max_scrolls=AUDIO_OPEN_SCROLL_RETRIES):
        hp.close_hp_application()
        return False

    # Select output/input
    if not hp.select_output_input_dropdowns(output_kw, input_kw):
        hp.close_hp_application()
        return False

    output_device = hp.detect_output_device()
    if not output_device:
        hp.close_hp_application()
        return False

    # ---------------------------------------------------------
    # STRICT SCENARIO GUARD (prevents false PASS)
    # ---------------------------------------------------------
    expected = norm(output_kw)
    actual = norm(output_device)

    if expected not in actual:
        msg = f"Expected output '{output_kw}' but detected '{output_device}'. Device not connected/selected."
        print(f"[FAIL] {msg}")
        hp._log("Validate Output Device Matches Scenario", False, msg)
        hp.close_hp_application()
        return False
    else:
        hp._log("Validate Output Device Matches Scenario", True,
                f"Expected '{output_kw}', Actual '{output_device}'")

    # Decide presets
    if "speaker" in actual:
        presets = SPEAKER_PRESETS
        hp._info("Scenario", "Speakers detected → Expecting 3 presets and Equalizer visible")
    else:
        presets = HEADPHONE_PRESETS
        hp._info("Scenario", "Headphones detected → Expecting 6 presets and Equalizer NOT visible")

    # Equalizer validation
    if not hp.verify_equalizer_present(actual):
        hp.close_hp_application()
        return False

    # ✅ Keep your old post-audio scroll behavior
    if hp.scrolled_for_audio:
        print("[INFO] Scrolling once before selecting presets due to Audio card being off-screen...")
        hp.scroll_once()
        hp.scroll_once()
        time.sleep(1)

    if "headphone" in actual and hp.scrolled_for_audio:
        print("[INFO] Additional scroll for headphone presets...")
        pyautogui.scroll(-40)
        time.sleep(1)

    # ✅ Keep your old resolution-based preset visibility check
    try:
        btns = hp.main_window.descendants(control_type="RadioButton")
        preset_names = [b.window_text().lower() for b in btns if b.is_visible()]
    except Exception:
        preset_names = []

    if not ("music" in preset_names and "movie" in preset_names and "voice" in preset_names) and not hp.scrolled_for_audio:
        print("[INFO] Presets not visible on current screen → scrolling once to bring presets into view...")
        hp.scroll_once()
        hp.scroll_once()
        time.sleep(1)

        if "headphone" in actual:
            print("[INFO] Headphones detected -> scrolling one more time for extra presets")
            pyautogui.scroll(-40)
            time.sleep(1)

    # Ensure presets visible (extra robustness)
    if not hp.ensure_presets_present(presets):
        hp.close_hp_application()
        return False

    # Start music
    if not hp.start_music():
        hp.close_hp_application()
        return False

    # Capture features per preset
    preset_features = {}
    for preset in presets:
        print(f"\n=== Processing preset: {preset} ===")

        if not hp.select_preset_and_verify(preset):
            hp.stop_music()
            hp.close_hp_application()
            return False

        feat = None
        for attempt in range(CAPTURE_RETRIES + 1):
            audio = hp.record_system_audio(RECORD_SECONDS)
            feat = hp.extract_band_feature(audio)
            if feat is not None:
                break
            hp._info("Capture Retry", f"Feature extraction failed, retry {attempt + 1}")

        if feat is None:
            hp._log("Feature Extraction", False, f"Could not extract feature for preset {preset}")
            hp.stop_music()
            hp.close_hp_application()
            return False

        preset_features[preset] = feat

    hp.stop_music()

    # Analyze differences vs baseline
    baseline = "music"
    base = preset_features.get(baseline)
    if base is None:
        hp._log("Baseline present", False, "Baseline 'music' missing")
        hp.close_hp_application()
        return False

    print("\n=== Analyzing audio differences between presets ===")
    analysis_ok = True

    for preset in presets:
        if preset == baseline:
            continue

        sim = hp.cosine_similarity(base, preset_features[preset])
        dist = hp.feature_distance(base, preset_features[preset])
        print(f"Similarity({baseline} vs {preset}) = {sim:.4f}, Distance={dist:.4f}")

        if (sim < SIMILARITY_THRESHOLD) or (dist > MIN_DISTANCE_THRESHOLD):
            hp._log(f"{preset} preset audio analysis", True, f"sim={sim:.4f}, dist={dist:.4f}")
        else:
            if ANALYSIS_RETRY_ONCE:
                hp._info("Analysis Retry", f"{preset} too similar -> reselect + recapture once")
                hp.start_music()
                hp.select_preset_and_verify(preset)
                audio2 = hp.record_system_audio(RECORD_SECONDS)
                feat2 = hp.extract_band_feature(audio2)
                hp.stop_music()

                if feat2 is not None:
                    sim2 = hp.cosine_similarity(base, feat2)
                    dist2 = hp.feature_distance(base, feat2)
                    print(f"Retry Similarity({baseline} vs {preset}) = {sim2:.4f}, Distance={dist2:.4f}")
                    if (sim2 < SIMILARITY_THRESHOLD) or (dist2 > MIN_DISTANCE_THRESHOLD):
                        hp._log(f"{preset} preset audio analysis (retry)", True, f"sim={sim2:.4f}, dist={dist2:.4f}")
                        continue

            hp._log(f"{preset} preset audio analysis", False, f"Too similar: sim={sim:.4f}, dist={dist:.4f}")
            analysis_ok = False

    print("\n=== FINAL RESULT ===")
    scenario_ok = all(hp.check_results) and analysis_ok
    print("[SCENARIO PASS]" if scenario_ok else "[SCENARIO FAIL]", f"{output_kw}/{input_kw}")

    hp.close_hp_application()
    return bool(scenario_ok)


def run_both_audio_scenarios() -> bool:
    speakers_ok = run_test_case_scenario(SPEAKER_OUTPUT_KW, SPEAKER_INPUT_KW)

    print("\n=== Switching to HEADPHONES scenario ===\n")
    time.sleep(2)

    headphones_ok = run_test_case_scenario(HEADPHONE_OUTPUT_KW, HEADPHONE_INPUT_KW)

    overall = bool(speakers_ok) and bool(headphones_ok)

    print("\n===== AUDIO VALIDATION FINAL RESULT =====")
    if overall:
        print("[AUDIO OVERALL PASS] Speakers + Headphones validation PASSED")
    else:
        print("[AUDIO OVERALL FAIL] One or more scenarios FAILED (Speakers/Headphones)")
    return overall


# Robot Framework keyword entry point
def run_audio_validation() -> bool:
    return run_both_audio_scenarios()


if __name__ == "__main__":
    run_both_audio_scenarios()