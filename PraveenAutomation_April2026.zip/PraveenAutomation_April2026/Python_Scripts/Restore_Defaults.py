import os
os.environ["PYGAME_HIDE_SUPPORT_PROMPT"] = "hide"

import time
import pyautogui
import pygetwindow as gw
from pywinauto import Application
import subprocess

pyautogui.FAILSAFE = True


class MyHP:
    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"
        self.check_results = []

        # ===== Auto IDs =====
        self.OUT_DROPDOWN_AUTO = "Audio.BasicSettings.DefaultOutputDevice-select"
        self.IN_DROPDOWN_AUTO = "Audio.BasicSettings.DefaultInputDevice-select"

        self.OUT_SLIDER_AUTO = "Audio.BasicSettings.OutputVolumeSlider"
        self.IN_SLIDER_AUTO = "Audio.BasicSettings.InputVolumeSlider"

        self.OUT_MUTE_AUTO = "Audio.BasicSettings.OutputMuteToggle__toggle"
        self.IN_MUTE_AUTO = "Audio.BasicSettings.InputMuteToggle__toggle"

        self.RESTORE_AUTO = "Audio.BasicSettings.RestoreDefaultsButton"

        self.TASKBAR_MARGIN = 140

    # =========================================================
    # LOGGING
    # =========================================================
    def _log(self, name, status, msg=""):
        self.check_results.append(bool(status))
        print(f"[{'PASS' if status else 'FAIL'}] {name}" + (f" - {msg}" if msg else ""))

    def _info(self, name, msg=""):
        print(f"[INFO] {name}" + (f" - {msg}" if msg else ""))

    # =========================================================
    # APP CONTROL
    # =========================================================
    def open_hp_application(self):
        pyautogui.press("winleft")
        time.sleep(1)
        pyautogui.write(self.app_title)
        time.sleep(1)
        pyautogui.press("enter")
        
        # Poll for window instead of long sleep to handle interruptions
        for _ in range(60):  # 6 seconds total (60 * 0.1s)
            try:
                win = gw.getActiveWindow()
                if win and self.app_title in win.title:
                    try:
                        win.maximize()
                    except Exception:
                        pass
                    self._log("Open Application", True)
                    return
                time.sleep(0.1)
            except KeyboardInterrupt:
                raise
            except Exception:
                time.sleep(0.1)
                continue
        
        # Fallback: try one more time
        win = gw.getActiveWindow()
        if win and self.app_title in win.title:
            try:
                win.maximize()
            except Exception:
                pass
            self._log("Open Application", True)
        else:
            return True

        self._log("Open Application", False)
        return False

    def connect_to_application(self):
        for attempt in range(3):  # Try up to 3 times
            try:
                self.application = Application(backend="uia").connect(title_re=self.app_title)
                self.main_window = self.application.window(title_re=self.app_title)
                time.sleep(2)
                self._log("Connect to Application", True)
                return True
            except Exception as e:
                if attempt < 2:  # Don't log error on last attempt
                    print(f"[INFO] Connection attempt {attempt + 1} failed, retrying...")
                    time.sleep(1)
                else:
                    self._log("Connect to Application", False, str(e))
                    return False

    def close_hp_application(self):
        try:
            if self.main_window:
                self.main_window.close()
                time.sleep(2)
            # Also try to kill any remaining HP processes
            subprocess.run(["taskkill", "/f", "/im", "HP*.exe"], capture_output=True)
            time.sleep(1)
            self._log("Close Application", True)
            return True
        except Exception:
            pass
        self._log("Close Application", False)
        return False

    # =========================================================
    # WINDOW SAFETY / SCROLL
    # =========================================================
    def focus_hp(self):
        try:
            self.main_window.set_focus()
        except Exception:
            pass
        time.sleep(0.2)

    def hp_rect(self):
        try:
            return self.main_window.rectangle()
        except Exception:
            return None

    def coords_safe_for_hp(self, x, y):
        w = self.hp_rect()
        if not w:
            return False
        if x < w.left or x > w.right:
            return False
        if y < w.top or y > (w.bottom - self.TASKBAR_MARGIN):
            return False
        return True

    def move_mouse_inside_hp(self):
        self.focus_hp()
        w = self.hp_rect()
        if not w:
            return
        x = w.left + int(w.width() * 0.5)
        y = w.top + int(w.height() * 0.55)
        pyautogui.moveTo(x, y, duration=0.05)

    def scroll_once(self):
        self.move_mouse_inside_hp()
        pyautogui.scroll(-600)
        time.sleep(1)

    def scroll_to_top(self):
        self.move_mouse_inside_hp()
        for _ in range(10):
            pyautogui.scroll(900)
            time.sleep(0.1)

    def scroll_until_ctrl_center_safe(self, ctrl, tries=120):
        self.move_mouse_inside_hp()
        for _ in range(tries):
            try:
                r = ctrl.rectangle()
                cx = r.left + r.width() // 2
                cy = r.top + r.height() // 2
                if self.coords_safe_for_hp(cx, cy):
                    return True
            except Exception:
                pass
            pyautogui.scroll(-250)
            time.sleep(0.1)
        return False

    # =========================================================
    # SAFE CLICK
    # =========================================================
    def safe_click_center(self, ctrl, label):
        if not ctrl:
            self._info(label, "Control not found")
            return False

        self.scroll_until_ctrl_center_safe(ctrl)
        try:
            r = ctrl.rectangle()
            cx = r.left + r.width() // 2
            cy = r.top + r.height() // 2

            if not self.coords_safe_for_hp(cx, cy):
                self._info(label, "Unsafe click blocked")
                return False

            self.focus_hp()
            pyautogui.click(cx, cy)
            time.sleep(0.3)
            return True
        except Exception:
            return False

    # =========================================================
    # OPEN AUDIO
    # =========================================================
    def open_audio(self):
        try:
            self.focus_hp()
            btn = self.main_window.child_window(title="Audio", control_type="Button")
            btn.wait("exists ready", timeout=10)
            btn.click_input()
            time.sleep(2)
            self._log("Open Audio", True)
            return True
        except Exception:
            return False

    # =========================================================
    # DROPDOWNS
    # =========================================================
    def select_output_input_dropdowns(self, output_kw, input_kw):
        self.scroll_to_top()

        out_combo = self.main_window.child_window(
            auto_id=self.OUT_DROPDOWN_AUTO, control_type="ComboBox"
        )
        in_combo = self.main_window.child_window(
            auto_id=self.IN_DROPDOWN_AUTO, control_type="ComboBox"
        )

        def pick(combo, kw):
            if not self.safe_click_center(combo, f"Open {kw} Dropdown"):
                return False, "Dropdown not clickable"

            try:
                top = self.application.top_window()
                for it in top.descendants(control_type="ListItem"):
                    if kw.lower() in (it.window_text() or "").lower():
                        it.click_input()
                        time.sleep(0.4)
                        return True, ""
            except Exception as e:
                # If UIA read fails, treat as fail (do NOT assume success)
                try:
                    pyautogui.press("esc")
                except Exception:
                    pass
                return False, f"Dropdown read failed: {e}"

            # ====== IMPORTANT FIX HERE ======
            # If keyword not found in dropdown listitems, FAIL (do not type and press enter)
            try:
                pyautogui.press("esc")
            except Exception:
                pass
            return False, "not found / not connected"

        ok_out, out_msg = pick(out_combo, output_kw)
        ok_in, in_msg = pick(in_combo, input_kw)

        self._log(f"Select Output ({output_kw})", ok_out, out_msg if out_msg else "")
        self._log(f"Select Input ({input_kw})", ok_in, in_msg if in_msg else "")
        return ok_out and ok_in

    # =========================================================
    # READ HELPERS (ROBUST)
    # =========================================================
    def read_slider_value(self, slider_ctrl):
        try:
            val = slider_ctrl.iface_range_value.CurrentValue
            if val is not None:
                return int(round(val))
        except Exception:
            pass
        try:
            val = slider_ctrl.get_value()
            if val is not None:
                return int(round(float(val)))
        except Exception:
            pass
        return None

    def read_toggle_state(self, btn_ctrl):
        try:
            return btn_ctrl.iface_toggle.CurrentToggleState == 1
        except Exception:
            pass
        try:
            return btn_ctrl.get_toggle_state() == 1
        except Exception:
            pass
        return None

    # =========================================================
    # PRE-RESTORE
    # =========================================================
    def slider_to_max_arrow(self, slider_auto, label):
        slider = self.main_window.child_window(auto_id=slider_auto, control_type="Slider")
        self.scroll_until_ctrl_center_safe(slider)
        slider.set_focus()

        before = self.read_slider_value(slider)

        for _ in range(60):
            pyautogui.press("right")
            time.sleep(0.05)

        time.sleep(0.5)
        after = self.read_slider_value(slider)

        moved = before is not None and after is not None and after > before
        self._log(
            f"{label} Slider Increased",
            moved,
            f"Before={before}, After={after}"
        )

    def pre_restore_set_max_and_mute(self):
        self.slider_to_max_arrow(self.OUT_SLIDER_AUTO, "Output")
        self.slider_to_max_arrow(self.IN_SLIDER_AUTO, "Input")

        self.safe_click_center(
            self.main_window.child_window(auto_id=self.OUT_MUTE_AUTO, control_type="Button"),
            "Mute ON Output"
        )
        self.safe_click_center(
            self.main_window.child_window(auto_id=self.IN_MUTE_AUTO, control_type="Button"),
            "Mute ON Input"
        )

    # =========================================================
    # RESTORE
    # =========================================================
    def click_restore_defaults(self):
        btn = self.main_window.child_window(auto_id=self.RESTORE_AUTO, control_type="Button")
        self.safe_click_center(btn, "Restore Defaults")
        time.sleep(5)  # Increased delay to ensure restore completes
        self._log("Click Restore Defaults", True)

    # =========================================================
    # UI VALIDATION
    # =========================================================
    def verify_hpui_after_restore(self, expected_out, expected_in):
        self.scroll_to_top()
        time.sleep(3)

        out_slider = self.main_window.child_window(auto_id=self.OUT_SLIDER_AUTO, control_type="Slider")
        in_slider = self.main_window.child_window(auto_id=self.IN_SLIDER_AUTO, control_type="Slider")

        out_btn = self.main_window.child_window(auto_id=self.OUT_MUTE_AUTO, control_type="Button")
        in_btn = self.main_window.child_window(auto_id=self.IN_MUTE_AUTO, control_type="Button")

        self.scroll_until_ctrl_center_safe(out_slider)
        self.scroll_until_ctrl_center_safe(in_slider)

        out_v = self.read_slider_value(out_slider)
        in_v = self.read_slider_value(in_slider)
        out_m = self.read_toggle_state(out_btn)
        in_m = self.read_toggle_state(in_btn)

        self._log(f"HP UI Output Volume = {expected_out}", out_v == expected_out, f"Actual={out_v}")
        self._log(f"HP UI Input Volume = {expected_in}", in_v == expected_in, f"Actual={in_v}")
        self._log("HP UI Output Mute OFF", out_m is False)
        self._log("HP UI Input Mute OFF", in_m is False)

    # =========================================================
    # SYSTEM VALIDATION (SETTINGS UI)
    # =========================================================
    def open_sound_settings_and_device_keyboard(self, expected_out):
        """
        Updated navigation for Windows Sound Settings.

        Speakers:
          Win+R -> "ms-settings:sound-devices" -> ENTER -> 7 TABS

        Headphones:
          Win+R -> "ms-settings:sound-devices" -> ENTER -> DOWN ARROW -> ENTER -> 6 TABS
        """
        pyautogui.hotkey("win", "r")
        time.sleep(0.7)
        pyautogui.write("ms-settings:sound-devices")
        pyautogui.press("enter")
        time.sleep(5)
        # For speakers: Win+R -> ms-settings:sound-devices -> ENTER -> 6 TABS
        if expected_out == 40:  # Speakers
            pyautogui.press("enter")  # First enter to open sound devices page
            time.sleep(3)  # Wait for page to load
            for _ in range(6):
                pyautogui.press("tab")
                time.sleep(0.15)
            self._log("System: Open Device (Speakers)", True)

        # For headphones: down arrow, enter, then 6 tabs
        elif expected_out == 20:  # Headphones
            pyautogui.press("down")
            time.sleep(0.3)
            pyautogui.press("enter")
            time.sleep(2)
            for _ in range(6):
                pyautogui.press("tab")
                time.sleep(0.15)
            self._log("System: Open Device (Headphones)", True)

    def verify_system_volume(self, expected):
        app = Application(backend="uia").connect(title_re="Settings", timeout=5)
        win = app.window(title_re="Settings")

        for txt in win.descendants(control_type="Text"):
            if txt.window_text().strip() == str(expected):
                self._log(f"System Volume = {expected}%", True)
                return True

        self._log(f"System Volume = {expected}%", False)
        return False

    def verify_system_unmuted(self):
        app = Application(backend="uia").connect(title_re="Settings", timeout=5)
        win = app.window(title_re="Settings")

        if win.child_window(title="Mute volume", control_type="Button").exists(timeout=2):
            self._log("System Unmuted", True)
            return True

        self._log("System Unmuted", False)
        return False

    def close_settings(self):
        pyautogui.hotkey("alt", "f4")
        time.sleep(1)

# =========================================================
# RUNNER
# =========================================================
def run_one_scenario(name, out_kw, in_kw, expected_out, expected_in):
    print(f"\n===== RUN START: {name} =====")
    hp = MyHP()

    hp.open_hp_application()
    if not hp.connect_to_application():
        print(f"[ERROR] Failed to connect to HP application for {name}")
        return False

    if not hp.open_audio():
        hp._info("Open Audio", "Audio card not visible, scrolling once and retrying...")
        hp.scroll_once()
        hp.open_audio()

    # ====== IMPORTANT FIX HERE ======
    # Stop scenario immediately if headphones/headset mic not found
    if not hp.select_output_input_dropdowns(out_kw, in_kw):
        print(f"[ERROR] {name}: Device not found / not connected. Stopping scenario here.")
        hp.close_hp_application()
        return False

    hp.pre_restore_set_max_and_mute()
    hp.click_restore_defaults()

    hp.verify_hpui_after_restore(expected_out, expected_in)

    hp.open_sound_settings_and_device_keyboard(expected_out)

    hp.verify_system_volume(expected_out)
    hp.verify_system_unmuted()
    hp.close_settings()

    hp.close_hp_application()
    return all(hp.check_results)


def run_test_case():
    speakers = run_one_scenario(
        "SPEAKERS", "speaker", "microphone array", 40, 40
    )
    
    # Add longer delay between scenarios and ensure HP app is fully closed
    print("\n[INFO] Waiting 5 seconds before starting headphones test...")
    time.sleep(5)
    
    headphones = run_one_scenario(
        "HEADPHONES", "headphone", "headset microphone", 20, 40
    )

    print("\n===== FINAL RESULT =====")
    if speakers and headphones:
        print("[OVERALL PASS] Speakers + Headphones")
        return True
    else:
        print("[OVERALL FAIL] One or more scenarios failed")
        return False


if __name__ == "__main__":
    run_test_case()