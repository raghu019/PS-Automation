*** Settings ***
Library    ../Libraries/Keyword.py
Library    Collections


*** Test Cases ***

1.Main
    [Documentation]    OTA update flow
    ${result}=    Main
    Should Be True    ${result}    OTA update failed


2.run audio validation
    [Documentation]    Audio presets validation
    ${result}=    run audio validation
    Should Be True    ${result}    Audio presets validation failed

3.run test case
    [Documentation]    Audio Restore Default Button validation
    ${result}=    run test case
    Should Be True    ${result}    Audio Restore Default Button validation failed

4.run focus mode test case
    [Documentation]    System control focus mode validation
    ${result}=    run focus mode test case
    Should Be True    ${result}    System control focus mode validation failed