from OTA_update import main as ota_main
from audio import run_audio_validation as audio_validation
from audio import MyHP
from Restore_Defaults import run_test_case as Audio_Restore_Defaults_main
from SysDim import run_focus_mode_test_case as System_control_Focus_mode_validation
from robot.api import logger

# Instantiate HP app object
hp_app = MyHP()


# ------------ Robot Framework keywords --------------#

def main():
    """OTA update flow."""
    result = ota_main()
    logger.info(f"OTA update successfully completed: {result}")
    return result


def run_audio_validation():
    """Audio presets validation."""
    result = audio_validation()
    logger.info(f"Audio validation result: {result}")
    return result

def run_test_case():
    """Audio Restore Defaults Button test."""
    result = Audio_Restore_Defaults_main()
    logger.info(f"Restore Defaults Button result: {result}")
    return result

def run_focus_mode_test_case():
    """System control focus mode test."""
    result = System_control_Focus_mode_validation()
    logger.info(f"System control Focus mode validation Result: {result}")
    return result


