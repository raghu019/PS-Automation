*** Settings ***
Library    ../libraries/Keyword.py
Library    Collections

*** Test Cases ***
1.Open HP Application       
    [Documentation]    Open the HP application
    ${result}=   Open Hp Application
    Should Be True    ${result}    Failed to open HP application

2.connect to Application

    [Documentation]    Connect application
    ${result}=    Connect To Application
    Should Be True    ${result}    Failed to connect 


3.Handle startup condition
    [Documentation]    Handle startup the HP application
    ${result}=    Handle Startup Conditions
    Should Be True    ${result}    Failed to handle startup condition


4.navigate_to_HPPK
    [Documentation]   Navigate to HPPK
    ${result}=    navigate_to_HPPK
    Should Be True    ${result}    Failed to Navigate to HPPK application


6.TC_ID_C42900996_Programmable_key_Commercial_Platform
    [Documentation]   Verify UI of PK on Commercial platforms
    ${result}=    TC_ID_C42900996_Programmable_key_Commercial_Platform
    Should Be True    ${result}    Verify UI of PK on Commercial platforms


7.TC_ID_C51871477_click_hp_programmable_key
    [Documentation]    Press Programable key and verify UI
    ${result}=    TC_ID_C51871477_click_hp_programmable_key_UI
    Should Be True    ${result}    Failed to click Programable key



8.TC_ID_C42900999_click_shift_programmable_key
    [Documentation]    click Shift+Programable key
    ${result}=    TC_ID_C42900999_click_shift_programmable_key
    Should Be True    ${result}    Failed to click Shift+Programable key


9.TC_ID_C42901000_click_ctrl_programmable_key
    [Documentation]   Press Ctrl+Programable key
    ${result}=    TC_ID_C42901000_click_ctrl_programmable_key
    Should Be True    ${result}    Failed to click Ctrl+Programable key


10.TC_ID_C42901001_click_alt_programmable_key
    [Documentation]   Press Alt+Programable key
    ${result}=    TC_ID_C42901001_click_alt_programmable_key
    Should Be True    ${result}    Failed to click Alt+Programable key


11.TC_ID_C42901014_ESCkey_Application
    [Documentation]   Click ESC key for Add application page
    ${result}=    TC_ID_C42901014_ESCkey_Application
    Should Be True    ${result}   Click ESC key for Add application page


12.TC_ID_C42901015_delete_Application
    [Documentation]   click delete button for cretaed task
    ${result}=    TC_ID_C42901015_delete_Application
    Should Be True    ${result}   click delete button for cretaed task


13.TC_ID_C42901013_Enterkey_Application
    [Documentation]   Add Application to create task
    ${result}=    TC_ID_C42901013_Enterkey_Application
    Should Be True    ${result}    Add Application to create task


14.device_page_backbutton
    [Documentation]   Navigate back to device page
    ${result}=    device_page_backbutton
    Should Be True    ${result}    Failed to Navigate back to device page

