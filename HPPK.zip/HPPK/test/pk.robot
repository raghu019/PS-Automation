*** Settings ***
Library    ../libraries/Keyword.py
Library    Collections

*** Test Cases ***
1.Open HP Application       
    [Documentation]    Open the HP application
    ${result}=   Open Hp Application
    Should Be True    ${result}    Failed to open HP application

2.connect to Application

    [Documentation]    Connect application
    ${result}=    Connect To Application
    Should Be True    ${result}    Failed to connect 


3.Handle startup condition
    [Documentation]    Handle startup the HP application
    ${result}=    Handle Startup Conditions
    Should Be True    ${result}    Failed to handle startup condition


4.navigate_to_HPPK
    [Documentation]   Navigate to HPPK
    ${result}=    navigate_to_HPPK
    Should Be True    ${result}    Failed to Navigate to HPPK application


5.TC_ID_C42900999_click_shift_programmable_key
    [Documentation]    Press Shift+Programable key
    ${result}=    TC_ID_C42900999_click_shift_programmable_key
    Should Be True    ${result}    Failed to Press Shift+Programable key


6.TC_ID_C42901000_click_ctrl_programmable_key
    [Documentation]   Press Ctrl+Programable key
    ${result}=    TC_ID_C42901000_click_ctrl_programmable_key
    Should Be True    ${result}    Failed to Press Ctrl+Programable key


7.TC_ID_C42901001_click_alt_programmable_key
    [Documentation]   Press Alt+Programable key
    ${result}=    TC_ID_C42901001_click_alt_programmable_key
    Should Be True    ${result}    Failed to Press Alt+Programable key


8.device_page_backbutton
    [Documentation]   Navigate back to device page
    ${result}=    device_page_backbutton
    Should Be True    ${result}    Failed to Navigate back to device page

