import pyautogui
import pygetwindow as gw
from pywinauto import Application
import os
import sys
import io
import time
from pywinauto.timings import Timings
from robot.libraries.BuiltIn import BuiltIn
from pywinauto.timings import wait_until
import datetime
from pywinauto.timings import wait_until_passes
from pywinauto import Desktop
from Screenshot import capture_failure_screenshot  
from datetime import datetime 
import pyperclip
import subprocess
from pywinauto.keyboard import send_keys
   

 
class MyHP:
    TIMEOUT = 5
 
    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"
        self.baseline_folder = r"C:\Users\cmit\Pictures\HPPK\libraries\Identifiers"
        # if not os.path.exists(self.baseline_folder):
        #     os.makedirs(self.baseline_folder)

    def _log_result(self, test_name, status, message=""):
            """
            Central logger.
            Automatically captures screenshot on FAILURE.
            Logs to console and Robot Framework.
            """
            result = "PASS" if status else "FAIL"
            screenshot_path = None

            if not status:
                # Capture screenshot
                try:
                    screenshot_dir = os.path.join(os.getcwd(), "screenshots")
                    os.makedirs(screenshot_dir, exist_ok=True)

                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    safe_name = test_name.replace(" ", "_").replace("/", "_")
                    screenshot_path = os.path.join(screenshot_dir, f"{safe_name}_{timestamp}.png")

                    pyautogui.screenshot(screenshot_path)
                    print(f"[SCREENSHOT] Saved: {screenshot_path}")

                    # Log to Robot Framework
                    try:
                        BuiltIn().log(
                            f"{result}: {test_name} - {message}<br>"
                            f"Screenshot: <a href='{screenshot_path}'>{screenshot_path}</a>",
                            html=True
                        )
                    except Exception as e:
                        print(f"[ROBOT LOGGING FAILED] {e}")

                except Exception as e:
                    print(f"[SCREENSHOT ERROR] {e}")

            # Console output
            if screenshot_path:
                print(f"[{result}] {test_name}: {message} | Screenshot: {screenshot_path}")
            else:
                print(f"[{result}] {test_name}: {message}")

    def _log_debug(self, message):
                """
                Debug logger.
                Prints debug messages to console and Robot Framework log.
                """
                print(f"[DEBUG] {message}")
                try:
                    BuiltIn().log(f"[DEBUG] {message}")
                except Exception:
                    pass


 

            # ---------------- Open HP Application ----------------
    def open_hp_application(self):
        try:
            pyautogui.press("winleft")
            time.sleep(1)
            pyautogui.write(self.app_title)
            time.sleep(1)
            pyautogui.press("enter")
            time.sleep(5)

            self._log_result("Open Application", True)
            return True

        except Exception as e:
            self._log_result("Open Application", False, str(e))
            return False
    


    def connect_to_application(self):

            try:
                windows = Desktop(backend="uia").windows(title="HP")

                if not windows:
                    raise Exception("HP window not found")

                print(f"DEBUG: Found {len(windows)} HP windows")

                selected = None
                max_area = 0

                for win in windows:
                    try:
                        if win.is_visible():
                            rect = win.rectangle()
                            area = rect.width() * rect.height()

                            if area > max_area:
                                max_area = area
                                selected = win
                    except:
                        pass

                if not selected:
                    raise Exception("No valid window found")

        
                self.main_window = Desktop(backend="uia").window(handle=selected.handle)

                # Wait properly
                self.main_window.wait("visible", timeout=10)

                self.main_window.set_focus()

                print(f"DEBUG: Connected to window = {self.main_window.window_text()}")

                self._log_result("Connect to Application", True)
                return True

            except Exception as e:
                self.main_window = None
                self._log_result("Connect to Application", False, str(e))
                return False



    # ---------------- Handle Location Permission ----------------

    def handle_location_permission_popup(self):
        """Handle location popup only if it appears"""

        try:
            time.sleep(2)

            active_window = gw.getActiveWindow()

            # Check if any active window exists
            if active_window and active_window.title:
                title = active_window.title.lower()

                # Check if location permission popup is active
                if "location" in title:
                    self._log_debug(f"Location popup detected: {title}")

                    # Default focus = No → move to Yes
                    pyautogui.press("tab")
                    time.sleep(0.5)
                    pyautogui.press("enter")
                    time.sleep(2) 

                    self._log_result("Location Permission", True, "Clicked YES")
                    return True

            # Popup not present → continue
            self._log_debug("Location popup not present - continuing test")
            return True

        except Exception as e:
            self._log_result("Location Permission", False, str(e))
            return False

        

    # ---------------- Click Accept All ----------------

    def click_accept_all_button(self):
        """Click Accept all consent button if popup appears"""
        try:
            if not self.main_window:
                self._log_result("Accept All", True, "HP window not connected - skipping")
                return True

            btn = self.main_window.child_window(
                auto_id="FuFConsents.FuFConsents.AcceptAllButton",
                control_type="Button"
            )

            if btn.wait("exists enabled visible ready", timeout=4):
                btn.set_focus()
                btn.click_input()
                time.sleep(2)
                self._log_result("Accept All", True, "Clicked Accept All")
            else:
                self._log_result("Accept All", True, "Popup not present - skipped")

            return True

        except Exception as e:
            self._log_result("Accept All", True, f"Skipped due to exception: {e}")
            return True
        

    # ---------------- Continue As Guest ----------------

    def click_continue_as_guest_button(self):
        """Click Continue as guest button if popup appears"""
        try:
            if not self.main_window:
                self._log_result("Continue As Guest", True, "HP window not connected - skipping")
                return True

            btn = self.main_window.child_window(
                title="Continue as guest",
                auto_id="WelcomeScreen.WelcomeScreenView.ContinueAsGuestButton",
                control_type="Button"
            )

            # Check if popup exists
            if btn.exists(timeout=5):
                btn.click_input()
                time.sleep(3)
                self._log_result("Continue As Guest", True, "Clicked")
            else:
                self._log_result("Continue As Guest", True, "Popup not present - skipped")

            return True

        except Exception as e:
            self._log_result("Continue As Guest", True, f"Skipped due to exception: {e}")
            return True


    # ---------------- Maximize HP Application ----------------

    def maximize_hp_application(self):
        try:
            windows = gw.getWindowsWithTitle(self.app_title)

            if windows:
                win = windows[0]
                win.activate()
                win.maximize()
                time.sleep(2)

                self._log_result("Maximize Application", True)
                return True

            self._log_result("Maximize Application", False, "HP window not found")
            return False

        except Exception as e:
            self._log_result("Maximize Application", False, str(e))
            return False
        
    def navigate_to_pc_device(self):
        pc_device = self.main_window.child_window(
            auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname",
            control_type="Text"
        )

        if pc_device.exists(timeout=5):
            time.sleep(3)
            pc_device.click_input()
            time.sleep(3)
            return True
        return False


    # ---------------- Handle Startup Conditions ----------------

    def handle_startup_conditions(self):

        try:

            self.handle_location_permission_popup()
            self.maximize_hp_application()
            self.click_accept_all_button()
            self.click_continue_as_guest_button()
            self.navigate_to_pc_device()

            self._log_result("Startup Handling", True)
            return True

        except Exception as e:
            self._log_result("Startup Handling", False, str(e))
            return False

    
    
   
   
    # ---------------- Dump UI Tree to File ----------------

    def dump_ui_tree_to_file(self):
        """Dump the full UI tree of the current main window to a text file."""
        if not self.main_window:
            self._log_result("Dump UI Tree", False, "Application not connected")
            return False
        try:
            dump_path = os.path.join(self.baseline_folder, "ui_dump.txt")
            with open(dump_path, "w", encoding="utf-8") as f:
                buffer = io.StringIO()
                sys.stdout = buffer
                self.main_window.print_control_identifiers()
                sys.stdout = sys.__stdout__  # Reset stdout
                f.write(buffer.getvalue())
                buffer.close()
            self._log_result("Dump UI Tree", True, f"Saved to {dump_path}")
            return True
        except Exception as e:
            sys.stdout = sys.__stdout__  # Ensure stdout is reset
            self._log_result("Dump UI Tree", False, str(e))
            return False
 
       

    
  # ---------------- Navigate to Audio control ----------------         
       
            
    def navigate_to_HPPK(self):
        """Navigate to the HPPK module inside PC Device page"""

        # ---------- Print Test CaHPPK modulese Header ----------
        print("\nTEST CASE 1: Navigate to ")
        print("-" * 60)

        if not self.main_window:
            self._log_result("Navigate to HPPK module", False, "Application not connected")
            print("Test case 'Navigate toHPPK module' completed : FAIL")
            print("-" * 60)
            return False

        try:
            self.main_window.set_focus()
            time.sleep(7) 

            audio_btn = self.main_window.child_window(
                # title_re=".*Display.*",
                auto_id="PcDeviceCards.PcDeviceActionCards.ProgkeyXSettingsCard",
                control_type="Button"
            )

            # ---------- Step 1: Page Down ----------
            self.main_window.type_keys("{PGDN}") 
            time.sleep(2)

            # ---------- Step 2: Two UP nudges ----------
            for _ in range(8):
                self.main_window.type_keys("{UP}")
                time.sleep(1)

            # ---------- Step 3: Click Audio ----------
            if audio_btn.exists(timeout=3): 
                time.sleep(2)
                audio_btn.click_input()
                time.sleep(8)
                self._log_result("Navigate to HPPK module", True)
                print("\nOverall test results : PASS")
                print("-" * 60)
                return True

            self._log_result(
                "Navigate to HPPK module",
                False,
                "HPPK module not visible after PGDN + UP UP"
            )
            print("\nOverall test results : FAIL")
            print("-" * 60)
            return False 

        except Exception as e:
            self._log_result("Navigate to HPPK module", False, str(e))
            print("\nOverall test results : FAIL")
            print("-" * 60)
            return False


# ------------------------------------------------------------------------------------------------------------------------------------------


    def TC_ID_C51871477_click_hp_programmable_key_UI(self):

        """
        Click HP Programmable Key and verify all options
        """

        print("\nTEST CASE : Verify HP Programmable Key Options")
        print("-" * 60)

        if not self.main_window:

            self._log_result(
                "HP Programmable Key Verification",
                False,
                "Application not connected"
            )

            print("\nOverall test results : FAIL")
            print("-" * 60)
            return False

        try:

            self.main_window.set_focus()
            time.sleep(2)

            # =====================================================
            # Click HP Programmable Key Arrow
            # =====================================================

            hp_pk_btn = self.main_window.child_window(
                title="HP programmable key",
                control_type="Text"
            )

            if not hp_pk_btn.exists(timeout=5):

                self._log_result(
                    "HP Programmable Key Verification",
                    False,
                    "HP Programmable Key button not found"
                )

                print("\nOverall test results : FAIL")
                print("-" * 60)
                return False

            hp_pk_btn.click_input()
            time.sleep(2)

            all_passed = True

            # =====================================================
            # Verify Header
            # =====================================================

            header = self.main_window.child_window(
                auto_id="Progkey.DetailCard.AssignPKHeader",
                control_type="Text"
            )

            if header.exists(timeout=5):

                print("✓ Header present : Assign programmable key")

            else:

                print("✗ Header missing")
                all_passed = False

            # =====================================================
            # Verify Labels and Radio Buttons
            # =====================================================

            verification_items = [

                (
                    "Automation",
                    "Progkey.DetailCard.Automation",
                    "Progkey.DetailCard.PKAutomation__radio-button"
                ),

                (
                    "Key sequence",
                    "Progkey.DetailCard.KeySequence",
                    "Progkey.DetailCard.PKKeySequence__radio-button"
                ),

                (
                    "Text input",
                    "Progkey.DetailCard.TextInput",
                    "Progkey.DetailCard.PKTextInput__radio-button"
                ),

                (
                    "HP programmable key",
                    "Progkey.DetailCard.Default",
                    "Progkey.DetailCard.PKDefault__radio-button"
                )

            ]

            for name, text_auto_id, radio_auto_id in verification_items:

                text_ctrl = self.main_window.child_window(
                    auto_id=text_auto_id,
                    control_type="Text"
                )

                radio_ctrl = self.main_window.child_window(
                    auto_id=radio_auto_id,
                    control_type="RadioButton"
                )

                text_exists = text_ctrl.exists(timeout=3)
                radio_exists = radio_ctrl.exists(timeout=3)

                if text_exists and radio_exists:

                    print(f"✓ {name} text and radio button present")

                else:

                    print(f"✗ {name} verification failed")
                    all_passed = False

            # =====================================================
            # Verify HP Programmable Key Selected By Default
            # =====================================================

            default_radio = self.main_window.child_window(
                auto_id="Progkey.DetailCard.PKDefault__radio-button",
                control_type="RadioButton"
            )

            try:

                default_selected = default_radio.get_toggle_state() == 1

            except Exception:

                try:
                    default_selected = default_radio.is_selected()
                except Exception:
                    default_selected = False

            if default_selected:

                print("✓ HP programmable key radio button is selected by default")

            else:

                print("✗ HP programmable key radio button is NOT selected")
                all_passed = False

            # =====================================================
            # Verify Other Radio Buttons Not Selected
            # =====================================================

            other_radios = [

                (
                    "Automation",
                    "Progkey.DetailCard.PKAutomation__radio-button"
                ),

                (
                    "Key sequence",
                    "Progkey.DetailCard.PKKeySequence__radio-button"
                ),

                (
                    "Text input",
                    "Progkey.DetailCard.PKTextInput__radio-button"
                )

            ]

            for name, radio_auto_id in other_radios:

                radio = self.main_window.child_window(
                    auto_id=radio_auto_id,
                    control_type="RadioButton"
                )

                try:

                    selected = radio.get_toggle_state() == 1

                except Exception:

                    try:
                        selected = radio.is_selected()
                    except Exception:
                        selected = False

                if selected:

                    print(f"✗ {name} radio button should not be selected")
                    all_passed = False

                else:

                    print(f"✓ {name} radio button is not selected")

            # =====================================================
            # Final Result
            # =====================================================

            if all_passed:

                print("\nNavigating back to Device Page...")
                self.device_page_backbutton()

                self._log_result(
                    "HP Programmable Key Verification",
                    True
                )

                print("\nOverall test results : PASS")
                print("-" * 60)
                return True

            self._log_result(
                "HP Programmable Key Verification",
                False,
                "One or more verifications failed"
            )

            print("\nOverall test results : FAIL")
            print("-" * 60)
            return False

        except Exception as e:

            self._log_result(
                "HP Programmable Key Verification",
                False,
                str(e)
            )

            print("\nOverall test results : FAIL")
            print("-" * 60)
            return False















# =======================================================================================================================================================================================

    def TC_ID_C42900999_click_shift_programmable_key(self):
        
        """Click Shift + Programmable Key and verify all options"""

        print("\nTEST CASE : Verify Shift + Programmable Key Options")
        print("-" * 60)

        if not self.main_window:
            self._log_result(
                "Shift + Programmable Key Verification",
                False,
                "Application not connected"
            )
            print("\nOverall test results : FAIL")
            print("-" * 60)
            return False

        try:
            self.main_window.set_focus()
            time.sleep(2)

            # =====================================================
            # Click Shift + Programmable Key Arrow
            # =====================================================
            shift_pk_btn = self.main_window.child_window(
                title="shift + programmable key",
                control_type="Button"
            )

            if not shift_pk_btn.exists(timeout=5):
                self._log_result(
                    "Shift + Programmable Key Verification",
                    False,
                    "Shift + Programmable Key button not found"
                )
                print("\nOverall test results : FAIL")
                print("-" * 60)
                return False

            shift_pk_btn.click_input()
            time.sleep(5)

            all_passed = True

            # =====================================================
            # Verify Header
            # =====================================================
            header = self.main_window.child_window(
                auto_id="Progkey.DetailCard.AssignShiftPKHeader",
                control_type="Text"
            )

            if header.exists(timeout=3):
                print("✓ Header present : Assign shift + programmable key")
            else:
                print("✗ Header missing")
                all_passed = False

            # =====================================================
            # Verify Labels and Radio Buttons
            # =====================================================
            verification_items = [
                (
                    "Automation",
                    "Progkey.DetailCard.Automation",
                    "Progkey.DetailCard.ShiftPKAutomation__radio-button"
                ),
                (
                    "Key sequence",
                    "Progkey.DetailCard.KeySequence",
                    "Progkey.DetailCard.ShiftPKKeySequence__radio-button"
                ),
                (
                    "Text input",
                    "Progkey.DetailCard.TextInput",
                    "Progkey.DetailCard.ShiftPKTextInput__radio-button"
                ),
                (
                    "Not assigned",
                    "Progkey.DetailCard.Default",
                    "Progkey.DetailCard.ShiftPKDefault__radio-button"
                )
            ]

            for name, text_auto_id, radio_auto_id in verification_items:

                text_ctrl = self.main_window.child_window(
                    auto_id=text_auto_id,
                    control_type="Text"
                )

                radio_ctrl = self.main_window.child_window(
                    auto_id=radio_auto_id,
                    control_type="RadioButton"
                )

                text_exists = text_ctrl.exists(timeout=2)
                radio_exists = radio_ctrl.exists(timeout=2)

                if text_exists and radio_exists:
                    print(f"✓ {name} text and radio button present")
                else:
                    print(f"✗ {name} verification failed")
                    all_passed = False

            # =====================================================
            # Verify Not Assigned Selected By Default
            # =====================================================
            default_radio = self.main_window.child_window(
                auto_id="Progkey.DetailCard.ShiftPKDefault__radio-button",
                control_type="RadioButton"
            )

            try:
                default_selected = default_radio.get_toggle_state() == 1
            except Exception:
                try:
                    default_selected = default_radio.is_selected()
                except Exception:
                    default_selected = False

            if default_selected:
                print("✓ Not assigned radio button is selected by default")
            else:
                print("✗ Not assigned radio button is NOT selected by default")
                all_passed = False

            # =====================================================
            # Verify Other Radio Buttons Are Not Selected
            # =====================================================
            other_radios = [
                (
                    "Automation",
                    "Progkey.DetailCard.ShiftPKAutomation__radio-button"
                ),
                (
                    "Key sequence",
                    "Progkey.DetailCard.ShiftPKKeySequence__radio-button"
                ),
                (
                    "Text input",
                    "Progkey.DetailCard.ShiftPKTextInput__radio-button"
                )
            ]

            for name, radio_auto_id in other_radios:

                radio = self.main_window.child_window(
                    auto_id=radio_auto_id,
                    control_type="RadioButton"
                )

                try:
                    selected = radio.get_toggle_state() == 1
                except Exception:
                    try:
                        selected = radio.is_selected()
                    except Exception:
                        selected = False

                if selected:
                    print(f"✗ {name} radio button should not be selected")
                    all_passed = False
                else:
                    print(f"✓ {name} radio button is not selected")

            # =====================================================
            # Final Result
            # =====================================================
            if all_passed:

                print("\nNavigating back to Device Page...")
                self.device_page_backbutton()

                self._log_result(
                    "Shift + Programmable Key Verification",
                    True
                )

                print("\nOverall test results : PASS")
                print("-" * 60)
                return True

            self._log_result(
                "Shift + Programmable Key Verification",
                False,
                "One or more verifications failed"
            )

            print("\nOverall test results : FAIL")
            print("-" * 60)
            return False

        except Exception as e:
            self._log_result(
                "Shift + Programmable Key Verification",
                False,
                str(e)
            )

            print("\nOverall test results : FAIL")
            print("-" * 60)
            return False

# -------------------------------------------------------------------------------------------------------------------------------------------------


    def TC_ID_C42901000_click_ctrl_programmable_key(self):

        """Click Ctrl + Programmable Key and verify all options"""

        print("\nTEST CASE : Verify Ctrl + Programmable Key Options")
        print("-" * 60)

        if not self.main_window:
            self._log_result(
                "Ctrl + programmable Key Verification",
                False,
                "Application not connected"
            )
            print("\nOverall test results : FAIL")
            print("-" * 60)
            return False

        try:
            self.main_window.set_focus()
            time.sleep(2)

            # =====================================================
            # Click Ctrl + Programmable Key Arrow
            # =====================================================
            ctrl_pk_btn = self.main_window.child_window(
                title="ctrl + programmable key",
                control_type="Button"
            )

            if not ctrl_pk_btn.exists(timeout=5):
                self._log_result(
                    "Ctrl + Programmable Key Verification",
                    False,
                    "Ctrl + Programmable Key button not found"
                )
                print("\nOverall test results : FAIL")
                print("-" * 60)
                return False

            ctrl_pk_btn.click_input()
            time.sleep(3)

            all_passed = True

            # =====================================================
            # Verify Header
            # =====================================================
            header = self.main_window.child_window(
                auto_id="Progkey.DetailCard.AssignCtlPKHeader",
                control_type="Text"
            )

            if header.exists(timeout=3):
                print("✓ Header present : Assign ctrl + programmable key")
            else:
                print("✗ Header missing")
                all_passed = False

            # =====================================================
            # Verify Labels and Radio Buttons
            # =====================================================
            verification_items = [
                (
                    "Automation",
                    "Progkey.DetailCard.Automation",
                    "Progkey.DetailCard.CtlPKAutomation__radio-button"
                ),
                (
                    "Key sequence",
                    "Progkey.DetailCard.KeySequence",
                    "Progkey.DetailCard.CtlPKKeySequence__radio-button"
                ),
                (
                    "Text input",
                    "Progkey.DetailCard.TextInput",
                    "Progkey.DetailCard.CtlPKTextInput__radio-button"
                ),
                (
                    "Not assigned",
                    "Progkey.DetailCard.Default",
                    "Progkey.DetailCard.CtlPKDefault__radio-button"
                )
            ]

            for name, text_auto_id, radio_auto_id in verification_items:

                text_ctrl = self.main_window.child_window(
                    auto_id=text_auto_id,
                    control_type="Text"
                )

                radio_ctrl = self.main_window.child_window(
                    auto_id=radio_auto_id,
                    control_type="RadioButton"
                )

                text_exists = text_ctrl.exists(timeout=2)
                radio_exists = radio_ctrl.exists(timeout=2)

                if text_exists and radio_exists:
                    print(f"✓ {name} text and radio button present")
                else:
                    print(f"✗ {name} verification failed")
                    all_passed = False

            # =====================================================
            # Verify Default Option Exists
            # =====================================================
            default_radio = self.main_window.child_window(
                auto_id="Progkey.DetailCard.CtlPKDefault__radio-button",
                control_type="RadioButton"
            )

            if default_radio.exists(timeout=2):
                print("✓ Not assigned radio button present")
            else:
                print("✗ Not assigned radio button missing")
                all_passed = False

            # =====================================================
            # Verify Other Radio Buttons Exist
            # =====================================================
            other_radios = [
                (
                    "Automation",
                    "Progkey.DetailCard.CtlPKAutomation__radio-button"
                ),
                (
                    "Key sequence",
                    "Progkey.DetailCard.CtlPKKeySequence__radio-button"
                ),
                (
                    "Text input",
                    "Progkey.DetailCard.CtlPKTextInput__radio-button"
                )
            ]

            for name, radio_auto_id in other_radios:

                radio = self.main_window.child_window(
                    auto_id=radio_auto_id,
                    control_type="RadioButton"
                )

                if radio.exists(timeout=2):
                    print(f"✓ {name} radio button present")
                else:
                    print(f"✗ {name} radio button missing")
                    all_passed = False

            # =====================================================
            # Final Result
            # =====================================================
            if all_passed:

                print("\nNavigating back to Device Page...")
                self.device_page_backbutton()

                self._log_result(
                    "Ctrl + Programmable Key Verification",
                    True
                )

                print("\nOverall test results : PASS")
                print("-" * 60)
                return True

            self._log_result(
                "Ctrl + Programmable Key Verification",
                False,
                "One or more verifications failed"
            )

            print("\nOverall test results : FAIL")
            print("-" * 60)
            return False

        except Exception as e:

            self._log_result(
                "Ctrl + Programmable Key Verification",
                False,
                str(e)
            )

            print(f"\nException: {e}")
            print("\nOverall test results : FAIL")
            print("-" * 60)
            return False

# -------------------------------------------------------------------------------------------------------------------------------------------


    def TC_ID_C42901001_click_alt_programmable_key(self):

        """Click Alt + Programmable Key and verify all options"""

        print("\nTEST CASE : Verify Alt + Programmable Key Options")
        print("-" * 60)

        if not self.main_window:
            self._log_result(
                "Alt + programmable Key Verification",
                False,
                "Application not connected"
            )
            print("\nOverall test results : FAIL")
            print("-" * 60)
            return False

        try:
            self.main_window.set_focus()
            time.sleep(2)

            # =====================================================
            # Click Alt + Programmable Key Arrow
            # =====================================================
            alt_pk_btn = self.main_window.child_window(
                title="alt + programmable key",
                control_type="Button"
            )

            if not alt_pk_btn.exists(timeout=5):
                self._log_result(
                    "Alt + Programmable Key Verification",
                    False,
                    "Alt + Programmable Key button not found"
                )
                print("\nOverall test results : FAIL")
                print("-" * 60)
                return False

            alt_pk_btn.click_input()
            time.sleep(3)

            all_passed = True

            # =====================================================
            # Verify Header
            # =====================================================
            header = self.main_window.child_window(
                auto_id="Progkey.DetailCard.AssignAltPKHeader",
                control_type="Text"
            )

            if header.exists(timeout=3):
                print("✓ Header present : Assign alt + programmable key")
            else:
                print("✗ Header missing")
                all_passed = False

            # =====================================================
            # Verify Labels and Radio Buttons
            # =====================================================
            verification_items = [
                (
                    "Automation",
                    "Progkey.DetailCard.Automation",
                    "Progkey.DetailCard.AltPKAutomation__radio-button"
                ),
                (
                    "Key sequence",
                    "Progkey.DetailCard.KeySequence",
                    "Progkey.DetailCard.AltPKKeySequence__radio-button"
                ),
                (
                    "Text input",
                    "Progkey.DetailCard.TextInput",
                    "Progkey.DetailCard.AltPKTextInput__radio-button"
                ),
                (
                    "Not assigned",
                    "Progkey.DetailCard.Default",
                    "Progkey.DetailCard.AltPKDefault__radio-button"
                )
            ]

            for name, text_auto_id, radio_auto_id in verification_items:

                text_ctrl = self.main_window.child_window(
                    auto_id=text_auto_id,
                    control_type="Text"
                )

                radio_ctrl = self.main_window.child_window(
                    auto_id=radio_auto_id,
                    control_type="RadioButton"
                )

                text_exists = text_ctrl.exists(timeout=2)
                radio_exists = radio_ctrl.exists(timeout=2)

                if text_exists and radio_exists:
                    print(f"✓ {name} text and radio button present")
                else:
                    print(f"✗ {name} verification failed")
                    all_passed = False

            # =====================================================
            # Verify Default Option Exists
            # =====================================================
            default_radio = self.main_window.child_window(
                auto_id="Progkey.DetailCard.AltPKDefault__radio-button",
                control_type="RadioButton"
            )

            if default_radio.exists(timeout=2):
                print("✓ Not assigned radio button present")
            else:
                print("✗ Not assigned radio button missing")
                all_passed = False

            # =====================================================
            # Verify Other Radio Buttons Exist
            # =====================================================
            other_radios = [
                (
                    "Automation",
                    "Progkey.DetailCard.AltPKAutomation__radio-button"
                ),
                (
                    "Key sequence",
                    "Progkey.DetailCard.AltPKKeySequence__radio-button"
                ),
                (
                    "Text input",
                    "Progkey.DetailCard.AltPKTextInput__radio-button"
                )
            ]

            for name, radio_auto_id in other_radios:

                radio = self.main_window.child_window(
                    auto_id=radio_auto_id,
                    control_type="RadioButton"
                )

                if radio.exists(timeout=2):
                    print(f"✓ {name} radio button present")
                else:
                    print(f"✗ {name} radio button missing")
                    all_passed = False

            # =====================================================
            # Final Result
            # =====================================================
            if all_passed:

                print("\nNavigating back to Device Page...")
                self.device_page_backbutton()

                self._log_result(
                    "Alt + Programmable Key Verification",
                    True
                )

                print("\nOverall test results : PASS")
                print("-" * 60)
                return True

            self._log_result(
                "Alt + Programmable Key Verification",
                False,
                "One or more verifications failed"
            )

            print("\nOverall test results : FAIL")
            print("-" * 60)
            return False

        except Exception as e:

            self._log_result(
                "Alt + Programmable Key Verification",
                False,
                str(e)
            )

            print(f"\nException: {e}")
            print("\nOverall test results : FAIL")
            print("-" * 60)
            return False

# ---------------------------------------------------------------------------------------------------------------------------------------

    def TC_ID_C42900996_Programmable_key_Commercial_Platform(self):

        """
        TEST CASE : Verify Programmable Key Tooltip and All Elements
        """

        print("\nTEST CASE : Verify Programmable Key Tooltip and All Elements")
        print("-" * 60)

        if not self.main_window:

            self._log_result(
                "Programmable Key Verification",
                False,
                "Application not connected"
            )

            print("OVERALL TEST RESULT : FAIL")
            print("-" * 60)
            return False

        try:

            self.main_window.set_focus()
            self.main_window.wait("exists ready", timeout=10)

            all_passed = True

            # =====================================================
            # VERIFY TOOLTIP TEXT
            # =====================================================

            try:

                header = self.main_window.child_window(
                    auto_id="Progkey.MenuCard.ProgrammablekeyHeader",
                    control_type="Text"
                )

                expected_tooltip = (
                    "Create personalized shortcuts. Assign apps, websites, "
                    "files or folders to open for your shortcut."
                )

                if header.exists(timeout=5):

                    header_text = header.window_text()

                    if expected_tooltip in header_text:

                        self._log_result(
                            "Programmable Key Tooltip",
                            True,
                            "Tooltip text verified successfully"
                        )

                    else:

                        all_passed = False

                        self._log_result(
                            "Programmable Key Tooltip",
                            False,
                            "Tooltip text mismatch"
                        )

                else:

                    all_passed = False

                    self._log_result(
                        "Programmable Key Tooltip",
                        False,
                        "Header not found"
                    )

            except Exception as e:

                all_passed = False

                self._log_result(
                    "Programmable Key Tooltip",
                    False,
                    str(e)
                )

            # =====================================================
            # HP PROGRAMMABLE KEY TEXT
            # =====================================================

            hp_text = self.main_window.child_window(
                auto_id="Progkey.MenuCard.PKConfigs",
                control_type="Text"
            )

            if hp_text.exists(timeout=5):

                self._log_result(
                    "HP Programmable Key Text",
                    True,
                    hp_text.window_text()
                )

            else:

                all_passed = False

                self._log_result(
                    "HP Programmable Key Text",
                    False,
                    "Text not found"
                )

            # =====================================================
            # SHIFT
            # =====================================================

            shift_label = self.main_window.child_window(
                title="shift",
                control_type="Text"
            )

            shift_assignment = self.main_window.child_window(
                auto_id="Progkey.MenuCard.ShiftPKConfigs",
                control_type="Text"
            )

            shift_button = self.main_window.child_window(
                title_re="(?i)^shift \\+ programmable key$",
                control_type="Button"
            )

            if shift_label.exists(timeout=5):
                self._log_result("Shift Label", True, "shift text present")
            else:
                all_passed = False

            if shift_assignment.exists(timeout=5):
                self._log_result(
                    "Shift Assignment",
                    True,
                    shift_assignment.window_text()
                )
            else:
                all_passed = False

            if shift_button.exists(timeout=5):
                self._log_result(
                    "Shift Arrow Button",
                    True,
                    "Button present"
                )
            else:
                all_passed = False

            # =====================================================
            # CTRL
            # =====================================================

            ctrl_label = self.main_window.child_window(
                title="ctrl",
                control_type="Text"
            )

            ctrl_assignment = self.main_window.child_window(
                auto_id="Progkey.MenuCard.CtlPKConfigs",
                control_type="Text"
            )

            ctrl_button = self.main_window.child_window(
                title_re="(?i)^ctrl \\+ programmable key$",
                control_type="Button"
            )

            if ctrl_label.exists(timeout=5):
                self._log_result("Ctrl Label", True, "ctrl text present")
            else:
                all_passed = False

            if ctrl_assignment.exists(timeout=5):
                self._log_result(
                    "Ctrl Assignment",
                    True,
                    ctrl_assignment.window_text()
                )
            else:
                all_passed = False

            if ctrl_button.exists(timeout=5):
                self._log_result(
                    "Ctrl Arrow Button",
                    True,
                    "Button present"
                )
            else:
                all_passed = False

            # =====================================================
            # ALT
            # =====================================================

            alt_label = self.main_window.child_window(
                title="alt",
                control_type="Text"
            )

            alt_assignment = self.main_window.child_window(
                auto_id="Progkey.MenuCard.AltPKConfigs",
                control_type="Text"
            )

            alt_button = self.main_window.child_window(
                title_re="(?i)^alt \\+ programmable key$",
                control_type="Button"
            )

            if alt_label.exists(timeout=5):
                self._log_result("Alt Label", True, "alt text present")
            else:
                all_passed = False

            if alt_assignment.exists(timeout=5):
                self._log_result(
                    "Alt Assignment",
                    True,
                    alt_assignment.window_text()
                )
            else:
                all_passed = False

            if alt_button.exists(timeout=5):
                self._log_result(
                    "Alt Arrow Button",
                    True,
                    "Button present"
                )
            else:
                all_passed = False

            # =====================================================
            # HP PROGRAMMABLE KEY BUTTON
            # =====================================================

            prog_button = self.main_window.child_window(
                title_re="(?i)^programmable key$",
                control_type="Button"
            )

            if prog_button.exists(timeout=5):

                self._log_result(
                    "Programmable Key Button",
                    True,
                    "Button present"
                )

            else:

                all_passed = False

                self._log_result(
                    "Programmable Key Button",
                    False,
                    "Button not found"
                )

            # =====================================================
            # FINAL RESULT
            # =====================================================

            if all_passed:

                print("\nOVERALL TEST RESULT : PASS")
                print("-" * 60)
                return True

            else:

                print("\nOVERALL TEST RESULT : FAIL")
                print("-" * 60)
                return False

        except Exception as e:

            self._log_result(
                "Programmable Key Verification",
                False,
                str(e)
            )

            print("\nOVERALL TEST RESULT : FAIL")
            print("-" * 60)
            return False






# ---------------- Verify Back button navigation from PC Device page to L1 page ----------------

    def device_page_backbutton(self):
        """
        TEST CASE 9: Verify Back button navigation from PC Device page
        """

        print("\nTEST CASE 9: Verify Back button navigation from PC Device page")
        print("-" * 60)

        # ---------- Check Application Connection ----------
        if not self.main_window:
            self._log_result(
                "Back Button",
                False,
                "Application not connected"
            )

            print("OVERALL TEST RESULT : FAIL")
            print("-" * 60)
            return False

        try:
            self.main_window.set_focus()
            self.main_window.wait("exists ready", timeout=10)

            back_button = self.main_window.child_window(
                auto_id="NavBar.NavBarView.BackButton",
                control_type="Button"
            )

            # ---------- Verify Back Button ----------
            if back_button.exists(timeout=5):

                back_button.wait("enabled", timeout=5)
                time.sleep(2)

                back_button.click_input()
                time.sleep(5)

                self._log_result(
                    "Back Button",
                    True,
                    "Back button clicked and navigated to L1 page"
                )

                print("OVERALL TEST RESULT : PASS")
                print("-" * 60)
                return True

            else:

                self._log_result(
                    "Back Button",
                    False,
                    "Back button not found on screen"
                )

                print("OVERALL TEST RESULT : FAIL")
                print("-" * 60)
                return False

        except Exception as e:

            self._log_result(
                "Back Button",
                False,
                f"Back button error: {e}"
            )

            print("OVERALL TEST RESULT : FAIL")
            print("-" * 60)
            return False

# -----------------------------------------------------------------------------------------------------------------------------------
            
    from pywinauto.keyboard import send_keys
    
    def TC_ID_C42901013_Enterkey_Application(self):

        """Verify HP Programmable Key -> Automation -> Application"""

        print("\nTEST CASE : Verify HP Programmable Key Automation Application")
        print("-" * 60)

        if not self.main_window:

            self._log_result(
                "HP Programmable Key Automation",
                False,
                "Application not connected"
            )

            print("\nOverall test results : FAIL")
            print("-" * 60)
            return False

        try:

            self.main_window.set_focus()
            time.sleep(2)

            # =====================================================
            # Click HP Programmable Key
            # =====================================================

            hp_pk_btn = self.main_window.child_window(
                title="HP programmable key",
                control_type="Text"
            )

            if not hp_pk_btn.exists(timeout=5):

                self._log_result(
                    "HP Programmable Key Automation",
                    False,
                    "HP Programmable Key not found"
                )

                print("\nOverall test results : FAIL")
                print("-" * 60)
                return False

            hp_pk_btn.click_input()
            time.sleep(2)

            print("✓ Clicked HP programmable key")

            # =====================================================
            # Click Automation Radio Button
            # =====================================================

            automation_radio = self.main_window.child_window(
                auto_id="Progkey.DetailCard.PKAutomation__radio-button",
                control_type="RadioButton"
            )

            if not automation_radio.exists(timeout=5):

                self._log_result(
                    "HP Programmable Key Automation",
                    False,
                    "Automation radio button not found"
                )

                print("\nOverall test results : FAIL")
                print("-" * 60)
                return False

            automation_radio.click_input()
            time.sleep(2)

            print("✓ Clicked Automation radio button")

            all_passed = True

            try:
                selected = automation_radio.get_toggle_state() == 1
            except Exception:
                try:
                    selected = automation_radio.is_selected()
                except Exception:
                    selected = False

            if selected:

                print("✓ Automation radio button selected")

            else:

                print("✗ Automation radio button not selected")
                all_passed = False

            # =====================================================
            # Select Application
            # =====================================================

            select_combobox = self.main_window.child_window(
                title="Select",
                auto_id="Progkey.DetailCard.SelectInput-select",
                control_type="ComboBox"
            )

            if not select_combobox.exists(timeout=5):

                print("✗ Select ComboBox not found")
                all_passed = False

            else:

                select_combobox.click_input()
                time.sleep(2)

                send_keys("{DOWN}")
                time.sleep(1)

                send_keys("{ENTER}")
                time.sleep(3)

                print("✓ Selected Application option")

            # =====================================================
            # Click Access
            # =====================================================

            access_btn = self.main_window.child_window(
                title="Access",
                control_type="Button"
            )

            if access_btn.exists(timeout=10):

                access_btn.click_input()
                time.sleep(2)

                print("✓ Clicked Access application")

            else:

                print("✗ Access button not found")
                all_passed = False

            # =====================================================
            # Click Continue
            # =====================================================

            continue_btn = self.main_window.child_window(
                title="Continue",
                control_type="Button"
            )

            if continue_btn.exists(timeout=10):

                continue_btn.click_input()
                time.sleep(4)

                print("✓ Clicked Continue button")

            else:

                print("✗ Continue button not found")
                all_passed = False

            # =====================================================
            # Verify Automation Text
            # =====================================================

            automation_text = self.main_window.child_window(
                title="Automation",
                auto_id="Progkey.DetailCard.Automation",
                control_type="Text"
            )

            if automation_text.exists(timeout=5):

                print("✓ Automation text present")

            else:

                print("✗ Automation text not found")
                all_passed = False

            # =====================================================
            # Verify Access Image
            # =====================================================

            access_image = self.main_window.child_window(
                auto_id="Progkey.DetailCard.ApplicationIcon1",
                control_type="Image"
            )

            if access_image.exists(timeout=5):

                print("✓ Access application image present")

            else:

                print("✗ Access application image not found")
                all_passed = False

            # =====================================================
            # Verify Access Text
            # =====================================================

            access_text = self.main_window.child_window(
                title="Access",
                control_type="Text"
            )

            if access_text.exists(timeout=5):

                print("✓ Access application text present")

            else:

                print("✗ Access application text not found")
                all_passed = False

            # =====================================================
            # Verify Delete Button
            # =====================================================

            delete_btn = self.main_window.child_window(
                auto_id="Progkey.DetailCard.DeleteButton1",
                control_type="Button"
            )

            if delete_btn.exists(timeout=5):

                print("✓ Delete button/icon present")

            else:

                print("✗ Delete button/icon not found")
                all_passed = False

            # =====================================================
            # Final Result
            # =====================================================

            if all_passed:

                print("\nNavigating back to Device Page...")
                self.device_page_backbutton()

                self._log_result(
                    "HP Programmable Key Automation",
                    True
                )

                print("\nOverall test results : PASS")
                print("-" * 60)

                return True

            self._log_result(
                "HP Programmable Key Automation",
                False,
                "One or more verifications failed"
            )

            print("\nOverall test results : FAIL")
            print("-" * 60)

            return False

        except Exception as e:

            self._log_result(
                "HP Programmable Key Automation",
                False,
                str(e)
            )

            print(f"\nException: {e}")
            print("\nOverall test results : FAIL")
            print("-" * 60)

            return False


# ----------------------------------------------------------------------------------------------------------------------------------

    def TC_ID_C42901014_ESCkey_Application(self):

        """Verify HP Programmable Key -> Automation -> Application -> ESC"""

        print("\nTEST CASE : Verify HP Programmable Key Automation Application ESC")
        print("-" * 60)

        if not self.main_window:

            self._log_result(
                "HP Programmable Key Automation Application ESC",
                False,
                "Application not connected"
            )

            print("\nOverall test results : FAIL")
            print("-" * 60)
            return False

        try:

            self.main_window.set_focus()
            time.sleep(2)

            all_passed = True

            # =====================================================
            # Click HP Programmable Key
            # =====================================================

            hp_pk_btn = self.main_window.child_window(
                title="HP programmable key",
                control_type="Text"
            )

            if not hp_pk_btn.exists(timeout=5):

                self._log_result(
                    "HP Programmable Key Automation Application ESC",
                    False,
                    "HP Programmable Key not found"
                )

                print("\nOverall test results : FAIL")
                print("-" * 60)
                return False

            hp_pk_btn.click_input()
            time.sleep(2)

            print("✓ Clicked HP programmable key")

            # =====================================================
            # Click Automation Radio Button
            # =====================================================

            automation_radio = self.main_window.child_window(
                auto_id="Progkey.DetailCard.PKAutomation__radio-button",
                control_type="RadioButton"
            )

            if automation_radio.exists(timeout=5):

                automation_radio.click_input()
                time.sleep(2)

                try:
                    selected = automation_radio.get_toggle_state() == 1
                except Exception:
                    try:
                        selected = automation_radio.is_selected()
                    except Exception:
                        selected = False

                if selected:

                    print("✓ Automation radio button selected")

                else:

                    print("✗ Automation radio button not selected")
                    all_passed = False

            else:

                print("✗ Automation radio button not found")
                all_passed = False

            # =====================================================
            # Select Application from dropdown
            # =====================================================

            select_combobox = self.main_window.child_window(
                title="Select",
                auto_id="Progkey.DetailCard.SelectInput-select",
                control_type="ComboBox"
            )

            if select_combobox.exists(timeout=5):

                select_combobox.click_input()
                time.sleep(2)

                send_keys("{DOWN}")
                time.sleep(1)

                send_keys("{ENTER}")
                time.sleep(3)

                print("✓ Selected Application option")

            else:

                print("✗ Select ComboBox not found")
                all_passed = False

            # =====================================================
            # Verify Add Application Page Opened
            # =====================================================

            access_btn = self.main_window.child_window(
                title="Access",
                control_type="Button"
            )

            if access_btn.exists(timeout=10):

                print("✓ Add Application page opened")

            else:

                print("✗ Add Application page not opened")
                all_passed = False

            # =====================================================
            # Select Access Application
            # =====================================================

            if access_btn.exists(timeout=5):

                access_btn.click_input()
                time.sleep(2)

                print("✓ Selected Access application")

            else:

                print("✗ Access application not found")
                all_passed = False

            # =====================================================
            # Verify Continue Button Enabled (Don't Click)
            # =====================================================

            continue_btn = self.main_window.child_window(
                title="Continue",
                control_type="Button"
            )

            if continue_btn.exists(timeout=5):

                if continue_btn.is_enabled():

                    print("✓ Continue button is enabled")

                else:

                    print("✗ Continue button is disabled")
                    all_passed = False

            else:

                print("✗ Continue button not found")
                all_passed = False

            # =====================================================
            # Press ESC
            # =====================================================

            send_keys("{ESC}")
            time.sleep(3)

            print("✓ Pressed ESC key")

            # =====================================================
            # Verify Add Application Page Closed
            # =====================================================

            access_btn_after_esc = self.main_window.child_window(
                title="Access",
                control_type="Button"
            )

            if not access_btn_after_esc.exists(timeout=3):

                print("✓ Add Application page closed")

            else:

                print("✗ Add Application page still open")
                all_passed = False

            # =====================================================
            # Verify Delete Button Does NOT Exist
            # =====================================================

            delete_btn = self.main_window.child_window(
                auto_id="Progkey.DetailCard.DeleteButton1",
                control_type="Button"
            )

            if not delete_btn.exists(timeout=3):

                print("✓ Delete button is not present")

            else:

                print("✗ Delete button exists unexpectedly")
                all_passed = False

            # =====================================================
            # Final Result
            # =====================================================

            if all_passed:

                print("\nNavigating back to Device Page...")
                self.device_page_backbutton()

                self._log_result(
                    "HP Programmable Key Automation Application ESC",
                    True
                )

                print("\nOverall test results : PASS")
                print("-" * 60)

                return True

            else:

                self._log_result(
                    "HP Programmable Key Automation Application ESC",
                    False,
                    "One or more verifications failed"
                )

                print("\nOverall test results : FAIL")
                print("-" * 60)

                return False

        except Exception as e:

            self._log_result(
                "HP Programmable Key Automation Application ESC",
                False,
                str(e)
            )

            print(f"\nException : {e}")
            print("\nOverall test results : FAIL")
            print("-" * 60)

            return False
        
# ----------------------------------------------------------------------------------------------------------------------------

    def TC_ID_C42901015_delete_Application(self):

        """Verify HP Programmable Key -> Automation -> Add Access -> Delete Access"""

        print("\nTEST CASE : Verify Add Access and Delete Access")
        print("-" * 60)

        if not self.main_window:

            self._log_result(
                "Add Access and Delete Access",
                False,
                "Application not connected"
            )

            print("\nOverall test results : FAIL")
            print("-" * 60)
            return False

        try:

            self.main_window.set_focus()
            time.sleep(2)

            all_passed = True

            # =====================================================
            # Click HP Programmable Key
            # =====================================================

            hp_pk_btn = self.main_window.child_window(
                title="HP programmable key",
                control_type="Text"
            )

            if not hp_pk_btn.exists(timeout=5):

                self._log_result(
                    "Add Access and Delete Access",
                    False,
                    "HP Programmable Key not found"
                )

                print("\nOverall test results : FAIL")
                print("-" * 60)
                return False

            hp_pk_btn.click_input()
            time.sleep(2)

            print("✓ Clicked HP programmable key")

            # =====================================================
            # Click Automation Radio Button
            # =====================================================

            automation_radio = self.main_window.child_window(
                auto_id="Progkey.DetailCard.PKAutomation__radio-button",
                control_type="RadioButton"
            )

            if not automation_radio.exists(timeout=5):

                self._log_result(
                    "Add Access and Delete Access",
                    False,
                    "Automation radio button not found"
                )

                print("\nOverall test results : FAIL")
                print("-" * 60)
                return False

            automation_radio.click_input()
            time.sleep(2)

            print("✓ Clicked Automation radio button")

            try:
                selected = automation_radio.get_toggle_state() == 1
            except Exception:
                try:
                    selected = automation_radio.is_selected()
                except Exception:
                    selected = False

            if selected:

                print("✓ Automation radio button selected")

            else:

                print("✗ Automation radio button not selected")
                all_passed = False

            # =====================================================
            # Select Application
            # =====================================================

            select_combobox = self.main_window.child_window(
                title="Select",
                auto_id="Progkey.DetailCard.SelectInput-select",
                control_type="ComboBox"
            )

            if select_combobox.exists(timeout=5):

                select_combobox.click_input()
                time.sleep(2)

                send_keys("{DOWN}")
                time.sleep(1)

                send_keys("{ENTER}")
                time.sleep(3)

                print("✓ Selected Application option")

            else:

                print("✗ Select ComboBox not found")
                all_passed = False

            # =====================================================
            # Select Access Application
            # =====================================================

            access_btn = self.main_window.child_window(
                title="Access",
                control_type="Button"
            )

            if access_btn.exists(timeout=10):

                access_btn.click_input()
                time.sleep(2)

                print("✓ Selected Access application")

            else:

                print("✗ Access application not found")
                all_passed = False

            # =====================================================
            # Click Continue
            # =====================================================

            continue_btn = self.main_window.child_window(
                title="Continue",
                control_type="Button"
            )

            if continue_btn.exists(timeout=10):

                continue_btn.click_input()
                time.sleep(4)

                print("✓ Clicked Continue button")

            else:

                print("✗ Continue button not found")
                all_passed = False

            # =====================================================
            # Verify Access Task Present
            # =====================================================

            access_text = self.main_window.child_window(
                title="Access",
                control_type="Text"
            )

            if access_text.exists(timeout=5):

                print("✓ Access task present")

            else:

                print("✗ Access task not found")
                all_passed = False

            # =====================================================
            # Verify Delete Button Present
            # =====================================================

            delete_btn = self.main_window.child_window(
                auto_id="Progkey.DetailCard.DeleteButton1",
                control_type="Button"
            )

            if delete_btn.exists(timeout=5):

                print("✓ Delete button present")

            else:

                print("✗ Delete button not found")
                all_passed = False

            # =====================================================
            # Delete Access
            # =====================================================

            if delete_btn.exists(timeout=5):

                delete_btn.click_input()
                time.sleep(3)

                print("✓ Deleted Access")

            else:

                print("✗ Unable to delete Access")
                all_passed = False

            # =====================================================
            # Verify Access Removed
            # =====================================================

            access_text = self.main_window.child_window(
                title="Access",
                control_type="Text"
            )

            if not access_text.exists(timeout=3):

                print("✓ Access removed successfully")

            else:

                print("✗ Access still present")
                all_passed = False

            # =====================================================
            # Final Result
            # =====================================================

            print("\nNavigating back to Device Page...")
            self.device_page_backbutton()

            if all_passed:

                self._log_result(
                    "Add Access and Delete Access",
                    True
                )

                print("\nOverall test results : PASS")
                print("-" * 60)

                return True

            else:

                self._log_result(
                    "Add Access and Delete Access",
                    False,
                    "One or more verifications failed"
                )

                print("\nOverall test results : FAIL")
                print("-" * 60)

                return False

        except Exception as e:

            self._log_result(
                "Add Access and Delete Access",
                False,
                str(e)
            )

            print(f"\nException : {e}")
            print("\nOverall test results : FAIL")
            print("-" * 60)

            return False

#    # ---------------- Run all steps in sequence ----------------

    def run_steps(self):
        steps = [
            
            self.open_hp_application,
            self.connect_to_application,
            self.handle_startup_conditions,
            self.navigate_to_HPPK,
    
            self.TC_ID_C42900996_Programmable_key_Commercial_Platform,
            self.TC_ID_C51871477_click_hp_programmable_key_UI,
            self.TC_ID_C42900999_click_shift_programmable_key,
            self.TC_ID_C42901000_click_ctrl_programmable_key,
            self.TC_ID_C42901001_click_alt_programmable_key,
            self.TC_ID_C42901014_ESCkey_Application,
            self.TC_ID_C42901015_delete_Application,
            
            self.TC_ID_C42901013_Enterkey_Application,

            # self.dump_ui_tree_to_file,
            self.device_page_backbutton

            
        ]

        
        overall_status = True

        print("\n" + "=" * 60)
        print(" STARTING TEST EXECUTION")
        print("=" * 60)

        for step in steps:
            step_name = step.__name__

            print(f"\n STEP: {step_name}")
            print("-" * 50)

            try:
                result = step()

                if not result:
                    print(f"STEP FAILED: {step_name}")
                    overall_status = False
                    continue  #  put break to stop execution on failure (recommended)
                else:
                    print(f"STEP PASSED: {step_name}")

            except Exception as e:
                print(f"STEP ERROR: {step_name} | {str(e)}")
                overall_status = False
                break

        # -------------------------------------------------
        # FINAL RESULT
        # -------------------------------------------------
        print("\n" + "=" * 60)

        if overall_status:
            print("OVERALL TEST RESULT: PASS")
        else:
            print("OVERALL TEST RESULT: FAIL")

        print("=" * 60)

        return overall_status



    # ---------------- Main ----------------
   
if __name__ == "__main__":
    hp_app = MyHP()

    if hp_app.run_steps():
        print("All tests completed.")
    else:
        print("OVERALL TEST RESULT : FAIL")