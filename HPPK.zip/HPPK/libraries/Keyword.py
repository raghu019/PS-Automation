from pk import MyHP      # Main HP app functions
from robot.api import logger

# Instantiate general HP app object
hp_app = MyHP()  

# ---------------- Robot Framework Keywords ----------------

def open_hp_application():
    """Open the HP application."""
    result = hp_app.open_hp_application()
    logger.info(f"Open HP Application result: {result}")
    return result


def connect_to_application():
    """Connect the HP application."""
    result = hp_app.connect_to_application()
    logger.info(f"Connect HP Application result: {result}")
    return result


def handle_startup_conditions():
    """handle the startup HP application."""
    result = hp_app.handle_startup_conditions()
    logger.info(f"Startup HP Application result: {result}")
    return result


def navigate_to_HPPK():
    """Navigate to HPPK"""
    result = hp_app.navigate_to_HPPK()
    logger.info(f"Navigate to HPPK result: {result}")
    return result



def TC_ID_C42900996_Programmable_key_Commercial_Platform():
    """Verify UI of PK on Commercial platforms"""
    result = hp_app.TC_ID_C42900996_Programmable_key_Commercial_Platform()
    logger.info(f"Verify UI of PK on Commercial platforms: {result}")
    return result


def TC_ID_C51871477_click_hp_programmable_key_UI():
    """Click programmable key"""
    result = hp_app.TC_ID_C51871477_click_hp_programmable_key_UI()
    logger.info(f"Click programmable key {result}")
    return result



def TC_ID_C42900999_click_shift_programmable_key():
    """Click shift+programmable key"""
    result = hp_app.TC_ID_C42900999_click_shift_programmable_key()
    logger.info(f"Click shift+programmable key {result}")
    return result


def TC_ID_C42901000_click_ctrl_programmable_key():
    """Click Ctrl+programmable key"""
    result = hp_app.TC_ID_C42901000_click_ctrl_programmable_key()
    logger.info(f"Click Ctrl+programmable key {result}")
    return result



def TC_ID_C42901001_click_alt_programmable_key():
    """Click Alt+programmable key"""
    result = hp_app.TC_ID_C42901001_click_alt_programmable_key()
    logger.info(f"Click Alt+programmable key {result}")
    return result



def TC_ID_C42901014_ESCkey_Application():
    """Click ESC key for Add application page"""
    result = hp_app.TC_ID_C42901014_ESCkey_Application()
    logger.info(f"Click ESC key for Add application page {result}")
    return result



def TC_ID_C42901015_delete_Application():
    """click delete button for cretaed task"""
    result = hp_app.TC_ID_C42901015_delete_Application()
    logger.info(f"click delete button for cretaed task {result}")
    return result


def TC_ID_C42901013_Enterkey_Application():
    """Add Application to create task"""
    result = hp_app.TC_ID_C42901013_Enterkey_Application()
    logger.info(f"Add Application to create task {result}")
    return result


def device_page_backbutton():
    """ Back to device page"""
    result = hp_app.device_page_backbutton()
    logger.info(f"device_page_backbutton: {result}")
    return result