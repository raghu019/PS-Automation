import pyautogui
import pygetwindow as gw
from pywinauto import Application
import os
import sys
import io
import time
from pywinauto.timings import Timings
from pywinauto.timings import wait_until_passes
from pywinauto import Desktop

 
class MyHP:
    TIMEOUT = 5
 
    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"
        self.baseline_folder = r"C:\Users\cmit\Desktop\HPX\Baseline"
        # if not os.path.exists(self.baseline_folder):
        #     os.makedirs(self.baseline_folder)
 
    # ---------------- Logger ----------------
    def _log_result(self, test_name, status, message=""):
        result = "PASS" if status else "FAIL"
        print(f"[{result}] {test_name}: {message}")

    def _log_debug(self, message):
        print(f"[DEBUG] {message}")


 
    # ---------------- Open HP Application ----------------
    def open_hp_application(self):
        """Open HP application using Windows search"""
        try:
            pyautogui.press('winleft')
            time.sleep(1)
            pyautogui.write(self.app_title)
            time.sleep(1)
            pyautogui.press('enter')
            time.sleep(5)
 
            active_window = gw.getActiveWindow()
            if active_window and self.app_title in active_window.title:
                active_window.maximize()
                time.sleep(2)
                self._log_result("Open Application", True)
                return True
            else:
                self._log_result("Open Application", False, "Wrong window focused")
                return False
        except Exception as e:
            self._log_result("Open Application", False, str(e))
            return False
 
    # ---------------- Connect to HP Application ----------------
    def connect_to_application(self):
        try:
            # Wait for the app to open properly
            time.sleep(3)
 
            # Get all open windows containing 'HP'
            hp_windows = [w for w in gw.getAllTitles() if "HP" in w and w.strip() != ""]
 
            if not hp_windows:
                self._log_result("Connect to Application", False, "No HP window found")
                return False
 
            # Print them to console for visibility
            print("\n[INFO] Detected HP-related windows:")
            for w in hp_windows:
                print(f"   - {w}")
 
            # Try to pick the main HP App window
            # (Adjust this condition to your exact app title if needed)
            main_title = None
            for w in hp_windows:
                if "HP" in w and "Service" not in w and "Support" not in w and "Quick" not in w:
                    main_title = w
                    break
 
            if not main_title:
                self._log_result("Connect to Application", False, "Main HP window not found")
                return False
 
            print(f"\n[INFO] Connecting to window: {main_title}")
 
            # Connect to that specific window
            self.application = Application(backend="uia").connect(title=main_title)
            self.main_window = self.application.window(title=main_title)
            time.sleep(2)
 
            self._log_result("Connect to Application", True, f"Connected to: {main_title}")
           
            # self.main_window.print_control_identifiers()
            return True
 
        except Exception as e:
            self._log_result("Connect to Application", False, str(e))
            return False
 
    # ---------------- Print Window Dump ----------------
    # def print_window_dump(self):
    #     """Print a hierarchical dump of all child windows"""
    #     if self.main_window:
    #         print("\n--- Window Dump ---")
    #         self.main_window.print_control_identifiers()
    #     else:
    #         self._log_result("Window Dump", False, "Main window not connected")

    def dump_ui_tree_to_file(self):
        """Dump the full UI tree of the current main window to a text file."""
        if not self.main_window:
            self._log_result("Dump UI Tree", False, "Application not connected")
            return False
        try:
            dump_path = os.path.join(self.baseline_folder, "ui_dump.txt")
            with open(dump_path, "w", encoding="utf-8") as f:
                buffer = io.StringIO()
                sys.stdout = buffer
                self.main_window.print_control_identifiers()
                sys.stdout = sys.__stdout__  # Reset stdout
                f.write(buffer.getvalue())
                buffer.close()
            self._log_result("Dump UI Tree", True, f"Saved to {dump_path}")
            return True
        except Exception as e:
            sys.stdout = sys.__stdout__  # Ensure stdout is reset
            self._log_result("Dump UI Tree", False, str(e))
            return False
 


   # ---------------- Navigate to Audio control ----------------
    
        
    def navigate_to_Audio(self):
        """Navigate to the Audio module inside PC Device page"""
        if not self.main_window:
            self._log_result("Navigate to Audio", False, "Application not connected")
            return False

        try:
            # Ensure HPX window is active
            self.main_window.set_focus()
            time.sleep(5)  # Wait for PC Device page to load

            # Locate Audio card button
            audio_btn = self.main_window.child_window(
                auto_id="PcDeviceCards.PcDeviceActionCards.PcaudioXCoreCard",
                control_type="Button"
            )

            # Perform a small scroll down (instead of full Page Down)

            for _ in range(10): # Adjust number of scrolls as needed
                self.main_window.type_keys("{DOWN}")
                time.sleep(1)

            # Click Audio card if found
            if audio_btn.exists(timeout=5):
                audio_btn.click_input()
                time.sleep(5)
                self._log_result("Navigate to audio page", True)
                return True
            else:
                self._log_result("Navigate to audio page", False, "Audio module button not found")
                return False

        except Exception as e:
            self._log_result("Navigate to audio page", False, str(e))




    # ---------------- Delete the apps from app bar----------------
                        
                     
    def del_app(self):
        """
        FULL WORKFLOW:

        1. Click ANY app → Delete → Continue
        2. Click ANY app → Delete → Cancel (optional)
        3. Click ANY app → Delete → Checkbox + Continue
        4. AGAIN Click ANY app → Delete → VERIFY NO POPUP APPEARS
        5. After workflow, delete any remaining apps in carousel if possible
        """

        if not self.main_window:
            self._log_result("Click Any App", False, "Application not connected")
            return False

        try:
            import time

            # --------------------------------------------------------------
            #  CORRECT CAROUSEL AUTO IDs (working ones)
            # --------------------------------------------------------------
            app_auto_ids = [
                ("Administrative Tools", "ReactPCContextAware.Carousel.CarouselItem2328013EC67257A5EFF59B60098FEB2B"),
                ("Calculator", "ReactPCContextAware.Carousel.CarouselItem2399C925B35566234AB600C70B12C40E"),
                ("Calendar", "ReactPCContextAware.Carousel.CarouselItemC24AD5F1F800ED5D431B6E23DAB94B1B"),
                ("Command Prompt", "ReactPCContextAware.Carousel.CarouselItem638D987E05CF5DE7460A01837C024F19"),
                ("Copilot", "ReactPCContextAware.Carousel.CarouselItem5256B9B8FF48BCECD8077FC44CBF239E"),
            ]

            # --------------------------------------------------------------
            # Helper → Click ANY visible app in carousel
            # --------------------------------------------------------------
            def click_any_app():
                for app_name, auto_id in app_auto_ids:
                    app_item = self.main_window.child_window(
                        auto_id=auto_id,
                        control_type="ListItem"
                    )

                    if app_item.exists(timeout=3) and app_item.is_visible():
                        app_item.click_input()
                        time.sleep(1)
                        self._log_result("Clicked App", True, f"App: {app_name}")
                        return app_name  # Return app name for logging

                self._log_result("Clicked App", False, "No visible app found in carousel")
                return None

            # --------------------------------------------------------------
            # Delete button
            # --------------------------------------------------------------
            def click_delete_button():
                delete_btn = self.main_window.child_window(
                    title="Delete profile",
                    auto_id="ReactPCContextAware.Carousel.DeleteProfileButton",
                    control_type="Button"
                )

                if delete_btn.exists(timeout=5):
                    if delete_btn.is_enabled():
                        time.sleep(1)
                        delete_btn.click_input()
                        time.sleep(1)
                        self._log_result("Delete Profile", True, "Delete profile clicked")
                        return True
                    else:
                        self._log_result("Delete Profile", False, "Delete button disabled for this app")
                        return False

                self._log_result("Delete Profile", False, "Delete profile not visible")
                return False

            # --------------------------------------------------------------
            # Delete Popup buttons
            # --------------------------------------------------------------
            def popup_continue():
                btn = self.main_window.child_window(
                    title="Continue",
                    auto_id="ReactPCContextAware.DeleteProfileModal.ContinueButton",
                    control_type="Button"
                )
                if btn.exists(timeout=4):
                    time.sleep(1)
                    btn.click_input()
                    time.sleep(1)
                    self._log_result("Popup Continue", True, "Continue clicked")
                    return True

                self._log_result("Popup Continue", False, "Continue not found")
                return False

            def popup_checkbox_continue():
                checkbox = self.main_window.child_window(
                    title="Do not show again",
                    auto_id="ReactPCContextAware.DeleteProfileModal.ConfirmationCheckbox__checkbox",
                    control_type="CheckBox"
                )

                if checkbox.exists(timeout=4):
                    checkbox.click_input()
                    time.sleep(0.5)
                    self._log_result("Popup Checkbox", True, "Checkbox selected")
                else:
                    self._log_result("Popup Checkbox", False, "Checkbox not found")

                return popup_continue()

            # ===================================================================
            # WORKFLOW
            # ===================================================================

            # Step 1: Delete → Continue
            app_name = click_any_app()
            if app_name and click_delete_button():
                popup_continue()

            # Step 3: Delete → Checkbox + Continue
            app_name = click_any_app()
            if app_name and click_delete_button():
                popup_checkbox_continue()

            # Step 4: Delete again → Verify NO popup appears
            app_name = click_any_app()
            if app_name and click_delete_button():
                time.sleep(2)
                popup = self.main_window.child_window(title="Delete Profile", control_type="Window")

                if popup.exists(timeout=1):
                    self._log_result("Popup Verification", False, "Popup appeared again! Not expected.")
                else:
                    self._log_result("Popup Verification", True, "No popup appeared as expected.")

            # Step 5: Delete any remaining apps in carousel
            self._log_debug("Checking for remaining apps to delete...")
            for app_name, auto_id in app_auto_ids:
                app_item = self.main_window.child_window(auto_id=auto_id, control_type="ListItem")
                if app_item.exists(timeout=2) and app_item.is_visible():
                    app_item.click_input()
                    time.sleep(1)
                    if click_delete_button():
                        popup_continue()  # Use Continue for cleanup
                        self._log_result("Cleanup Delete", True, f"Deleted remaining app: {app_name}")
                    else:
                        self._log_result("Cleanup Delete", False, f"Cannot delete app: {app_name}")

            return True

        except Exception as e:
            self._log_result("Select Any App for Focus", False, str(e))



    # ---------------- Navigate to CA module ----------------

    
    def navigate_to_CA(self):
        """Navigate to the CA module"""
        if not self.main_window:
            self._log_result("CA", False, "Application not connected")
            return False
        try:
            time.sleep(3)  # wait for CA page to load
 
            add_btn = self.main_window.child_window(title="Add Application", auto_id="ReactPCContextAware.Carousel.AddButton", control_type="Button")
 
            if add_btn.exists(timeout=10):  
                add_btn.click_input()
                time.sleep(2)
                self._log_result("Custom app Button clicked", True)
                return True
            else:
                self._log_result("add button exist", False, "button failed to click")
                return False
 
        except Exception as e:
            self._log_result("Add button clicking", False, str(e))
            return False
        
         


            # ------------ Add Multiple Apps (FINAL VERSION) -----------    
             
    def add_multiple_apps(self):
        try:
            self._log_result("Add Apps", True, "Starting process for multiple apps")

            # ✅ App details with auto_ids (including Command Prompt)
            apps_to_add = apps_to_add = [
                    ("Administrative Tools", "ReactPCContextAware.InstalledAppsModal.AppItem2328013EC67257A5EFF59B60098FEB2B"),
                    ("Calculator", "ReactPCContextAware.InstalledAppsModal.AppItem2399C925B35566234AB600C70B12C40E"),
                    ("Calendar", "ReactPCContextAware.InstalledAppsModal.AppItemC24AD5F1F800ED5D431B6E23DAB94B1B"),
                    ("Command Prompt", "ReactPCContextAware.InstalledAppsModal.AppItem638D987E05CF5DE7460A01837C024F19"),
                    ("Copilot", "ReactPCContextAware.InstalledAppsModal.AppItem5256B9B8FF48BCECD8077FC44CBF239E"),
                    ("HP System Information", "ReactPCContextAware.InstalledAppsModal.AppItem9C026CA7D49ECD66C934D6F700F17501"),
                    ("LinkedIn", "ReactPCContextAware.InstalledAppsModal.AppItem554B1A3213ECA0D51534E50B794A4C09"),
                    ("LiveCaptions", "ReactPCContextAware.InstalledAppsModal.AppItem0129D1E7D7570F8D575B759EAE255B33"),
                    ("Magnify", "ReactPCContextAware.InstalledAppsModal.AppItem1CB79190ED90A2079EB37225A66350F0"),
                    ("Mail", "ReactPCContextAware.InstalledAppsModal.AppItem5F577ECC7D8D86A4BF6A8264A777CC4B"),
                    ("Maps", "ReactPCContextAware.InstalledAppsModal.AppItemE63A770EFB1658BCC6A5E2F2D78678AD"),
                    ("Media Player", "ReactPCContextAware.InstalledAppsModal.AppItem1FFCF5F3FB0FD82F75DCEAE06845D9E6"),
                ]


            # List container reference (still needed but no scrolling done on it)
            list_container = self.main_window.child_window(
                auto_id="ReactPCContextAware.InstalledAppsModal.AppList",
                control_type="Group"
            )

            for index, (app_name, app_id) in enumerate(apps_to_add):
                app_btn = self.main_window.child_window(auto_id=app_id, control_type="Button")
                found = False

                # Try without scrolling first
                for _ in range(10):
                    if app_btn.exists() and app_btn.is_visible():
                        found = True
                        break
                    time.sleep(0.5)

                # Apply scroll logic if not found
                if not found:
                    self._log_result("Add Apps", True, f"Scrolling to find {app_name}...")

                    try:
                        # Ensure focus by selecting first app
                        first_app_btn = self.main_window.child_window(auto_id=apps_to_add[0][1], control_type="Button")
                        if first_app_btn.exists():
                            first_app_btn.click_input()
                            self._log_result("Add Apps", True, "Focus set by selecting Calculator")

                        # FIX: Scroll the MAIN WINDOW (NOT the list container)
                        for _ in range(15):
                            if app_btn.exists() and app_btn.is_visible():
                                found = True
                                break
                            self.main_window.type_keys("{PGDN}")   # CHANGED
                            time.sleep(1)

                        # Fallback: wheel scroll
                        if not found:
                            for _ in range(10):
                                if app_btn.exists() and app_btn.is_visible():
                                    found = True
                                    break
                                self.main_window.wheel_scroll(-1)  # CHANGED
                                time.sleep(1)

                    except Exception as e:
                        self._log_result("Add Apps", False, f"Scrolling failed: {str(e)}")

                if not found:
                    self._log_result("Add Apps", False, f"{app_name} button not visible, skipping...")
                    continue

                # Click app
                app_btn.click_input()
                time.sleep(2)
                self._log_result("Add Apps", True, f"{app_name} selected")

                # Step 2: Click Continue
                continue_btn = self.main_window.child_window(title="Continue", control_type="Button")
                for _ in range(10):
                    if continue_btn.exists() and continue_btn.is_enabled():
                        break
                    time.sleep(1)

                if not continue_btn.exists() or not continue_btn.is_enabled():
                    self._log_result("Add Apps", False, f"Continue button not enabled for {app_name}, skipping...")
                    continue

                continue_btn.click_input()
                time.sleep(2)
                self._log_result("Add Apps", True, f"Continue clicked for {app_name}")

                # Step 3: Click Add Application (+) button (except last app)
                if index < len(apps_to_add) - 1:
                    add_btn = self.main_window.child_window(
                        title="Add Application",
                        auto_id="ReactPCContextAware.Carousel.AddButton",
                        control_type="Button"
                    )

                    for _ in range(10):
                        if add_btn.exists():
                            break
                        time.sleep(0.5)
                    else:
                        self._log_result("Add Apps", False, "Add (+) button not found, skipping next app")
                        continue

                    add_btn.click_input()
                    time.sleep(2)
                    self._log_result("Add Apps", True, "Add (+) button clicked")

            return True

        except Exception as e:
            self._log_result("Add Apps", False, f"Exception occurred: {str(e)}")
            return False





#    # ---------------- Click Next button to scroll the apps in carousel/Appbar ----------------

    def click_carousel_next(self):
        """Click the carousel Next button to scroll apps"""
        if not self.main_window:
            self._log_result("Carousel Next Button", False, "Application not connected")
            return False

        try:
            # Locate the Next button in Audio carousel
            next_btn = self.main_window.child_window(
                title="Next",
                auto_id="ReactPCContextAware.Carousel.NextButton",
                control_type="Button"
            )

            if not next_btn.exists(timeout=5):
                self._log_result("Carousel Next Button", False, "Next button not found")
                return False
            
            # Click Next button 10 times
            for _ in range(10):
                next_btn.click_input()
                time.sleep(1)

            self._log_result("Carousel Next Button clicked", True)
            return True

        except Exception as e:
            self._log_result("Carousel Next Button", False, str(e))
            return False




    # ---------------- Verify and Hover app Tooltip in app bar ----------------
    
    def verify_carousel_app_tooltips(self):
            """
            Click each app in the carousel and verify its tooltip appears.
            Capture screenshot after successful tooltip match in a dedicated folder.
            """

            if not self.main_window:
                self._log_result("Carousel Tooltip Check", False, "Application not connected")
                return False

            # Folder for screenshots
            screenshot_dir = r"C:\Users\cmit\Desktop\HPX\Screenshots"
            os.makedirs(screenshot_dir, exist_ok=True)

            # List of app names in the carousel
            app_names = [
                "Administrative Tools",
                "Calculator",
                "Calendar",
                "Command Prompt",
                "Copilot",
                "HP System Information",
                "LinkedIn",
                "LiveCaptions"
            ]

            def _get_tooltip(expected_name):
                """Search within main window for tooltip by title and control type."""
                try:
                    tooltip = self.main_window.child_window(
                        title=expected_name,
                        control_type="ToolTip"
                    )
                    if tooltip.exists(timeout=1):
                        return tooltip.window_text().strip()
                except:
                    pass
                return None

            try:
                for expected_name in app_names:
                    # Locate the app by title and control type
                    app_item = self.main_window.child_window(
                        title=f"carousel-item-{expected_name}",
                        control_type="ListItem"
                    )

                    if not app_item.exists(timeout=5):
                        self._log_result(expected_name, False, "App not found in carousel")
                        continue

                    # Scroll into view
                    try:
                        app_item.scroll_into_view()
                    except:
                        pass

                    # Click and focus
                    try:
                        app_item.click_input()
                        app_item.set_focus()
                        time.sleep(3.0)  # Wait for tooltip to appear
                    except Exception as e:
                        self._log_result(expected_name, False, f"Click/Focus failed: {str(e)}")
                        continue

                    # Detect tooltip
                    tooltip_text = None
                    for _ in range(20):  # Retry for ~6 seconds
                        tooltip_text = _get_tooltip(expected_name)
                        if tooltip_text:
                            break
                        time.sleep(0.3)

                    if not tooltip_text:
                        self._log_result(expected_name, False, "Tooltip not visible after focus")
                        continue

                    # Validate tooltip text
                    if expected_name.lower() in tooltip_text.lower():
                        self._log_result(expected_name, True, f"Tooltip is matched : {tooltip_text}")

                        #  Capture screenshot after successful match
                        # try:
                        #     img = self.main_window.capture_as_image()
                        #     img.save(os.path.join(screenshot_dir, f"{expected_name}_tooltip_match.png"))
                        # except Exception as e:
                        #     self._log_result(expected_name, False, f"Screenshot failed: {str(e)}")

                    else:
                        self._log_result(expected_name, False, f"Tooltip is mismatched: {tooltip_text}")

                return True

            except Exception as e:
                self._log_result("Carousel Tooltip Check", False, str(e))
                return False



    # ---------------- Search and Add Calculator App ----------------
        
  
    def search_app_add(self):
        """
        Click search box, search for Calculator in Installed Apps modal, select it, click Continue,
        and verify it is added to the carousel.
        """

        if not self.main_window:
            self._log_result("Add Calculator App", False, "Application not connected")
            return False

        try:
            # Step 1: Locate and click the search box
            search_box = self.main_window.child_window(
                auto_id="ReactPCContextAware.InstalledAppsModal.SearchApplication__text-box",
                control_type="Edit"
            )

            if not search_box.exists(timeout=5):
                self._log_result("Add Calculator App", False, "Search box not found")
                return False

            search_box.click_input()
            search_box.set_focus()
            self._log_result("Add Calculator App", True, "Search box clicked and focused successfully")

            # Step 2: Enter search term
            search_term = "calculator"
            search_box.type_keys(search_term, with_spaces=True)
            self._log_result("Add Calculator App", True, f"Entered search term: {search_term}")

            # Step 3: Wait for Calculator app using provided auto_id and title
            app_item = self.main_window.child_window(
                title="Calculator",
                auto_id="ReactPCContextAware.InstalledAppsModal.AppItem2399C925B35566234AB600C70B12C40E",
                control_type="Button"
            )

            if not app_item.exists(timeout=15):
                # Retry with partial keyword if full name fails
                search_box.type_keys("^a{BACKSPACE}")  # Clear previous text
                search_box.type_keys("cal", with_spaces=True)
                self._log_result("Add Calculator App", True, "Retrying with partial keyword: cal")
                if not app_item.exists(timeout=15):
                    self._log_result("Add Calculator App", False, "Calculator app not found in search results")
                    return False

            # Step 4: Select the Calculator app
            app_item.click_input()
            self._log_result("Add Calculator App", True, "Calculator app selected")

            # Step 5: Click Continue button
            continue_btn = self.main_window.child_window(title="Continue", control_type="Button")
            if continue_btn.exists(timeout=5):
                continue_btn.click_input()
                self._log_result("Add Calculator App", True, "Clicked Continue button")
            else:
                self._log_result("Add Calculator App", False, "Continue button not found")
                return False

            # Step 6: Verify app added to carousel using provided auto_id
            carousel_item = self.main_window.child_window(
                title="carousel-item-Calculator",
                auto_id="ReactPCContextAware.Carousel.CarouselItem2399C925B35566234AB600C70B12C40E",
                control_type="ListItem"
            )

            if carousel_item.exists(timeout=20):
                self._log_result("Add Calculator App", True, "Calculator app added to carousel successfully")
                return True
            else:
                self._log_result("Add Calculator App", False, "Calculator app not added to carousel")
                return False

        except Exception as e:
            self._log_result("Add Calculator App", False, str(e))
            return False



    # ---------------- Verify application is present in carousel or not ----------------

    def verify_carousel_apps(self):
        """
        Verify that required apps exist in the carousel (title-based check only).
        """

        if not self.main_window:
            self._log_result("Carousel Verification", False, "Application not connected")
            return False

        # --- Apps to verify based on title only ---
        apps = [
            "Administrative Tools",
            "Calculator",
            "Calendar",
            "Command Prompt",
            "Copilot"
        ]

        all_passed = True

        try:
            for app_name in apps:

                # Locate using only the title (simple & reliable)
                item = self.main_window.child_window(
                    title=f"carousel-item-{app_name}",
                    control_type="ListItem"
                )

                if item.exists(timeout=10):
                    self._log_result(app_name, True, f"'{app_name}' present in carousel/Appbar")
                else:
                    self._log_result(app_name, False, f"'{app_name}' NOT found in carousel/Appbar")
                    all_passed = False

            return all_passed

        except Exception as e:
            self._log_result("Carousel Verification", False, str(e))
            return False





    # ---------------- Add Multiple Apps (IMPROVED SCROLLING) ----------------

    def add_multiple_apps1(self):
        try:
            self._log_result("Add Apps", True, "Starting process for multiple apps")

            # App details with auto_ids
            apps_to_add = [
                ("Administrative Tools", "ReactPCContextAware.InstalledAppsModal.AppItem2328013EC67257A5EFF59B60098FEB2B"),
                ("Calculator", "ReactPCContextAware.InstalledAppsModal.AppItem2399C925B35566234AB600C70B12C40E"),
                ("Calendar", "ReactPCContextAware.InstalledAppsModal.AppItemC24AD5F1F800ED5D431B6E23DAB94B1B"),
                ("Command Prompt", "ReactPCContextAware.InstalledAppsModal.AppItem638D987E05CF5DE7460A01837C024F19"),
                ("Copilot", "ReactPCContextAware.InstalledAppsModal.AppItem5256B9B8FF48BCECD8077FC44CBF239E"),
                ("HP System Information", "ReactPCContextAware.InstalledAppsModal.AppItem9C026CA7D49ECD66C934D6F700F17501"),
                ("LinkedIn", "ReactPCContextAware.InstalledAppsModal.AppItem554B1A3213ECA0D51534E50B794A4C09"),
                ("LiveCaptions", "ReactPCContextAware.InstalledAppsModal.AppItem0129D1E7D7570F8D575B759EAE255B33"),
                ("Magnify", "ReactPCContextAware.InstalledAppsModal.AppItem1CB79190ED90A2079EB37225A66350F0"),
                ("Mail", "ReactPCContextAware.InstalledAppsModal.AppItem5F577ECC7D8D86A4BF6A8264A777CC4B"),
                ("Maps", "ReactPCContextAware.InstalledAppsModal.AppItemE63A770EFB1658BCC6A5E2F2D78678AD"),
                ("Media Player", "ReactPCContextAware.InstalledAppsModal.AppItem1FFCF5F3FB0FD82F75DCEAE06845D9E6"),
            ]

            next_shown_logged = False

            for index, (app_name, app_id) in enumerate(apps_to_add):

                app_btn = self.main_window.child_window(auto_id=app_id, control_type="Button")
                found = False

                # Wait without scrolling
                for _ in range(5):
                    if app_btn.exists() and app_btn.is_visible():
                        found = True
                        break
                    time.sleep(0.5)

                # Scroll if app not visible
                if not found:
                    self._log_result("Add Apps", True, f"Scrolling to find {app_name}...")

                    try:
                        first_app_btn = self.main_window.child_window(
                            auto_id=apps_to_add[0][1], control_type="Button"
                        )
                        if first_app_btn.exists():
                            first_app_btn.click_input()
                            self._log_result("Add Apps", True, "Focus set by selecting first app")

                        # Page Down scroll
                        for _ in range(10):
                            if app_btn.exists() and app_btn.is_visible():
                                found = True
                                break
                            self.main_window.type_keys("{PGDN}")
                            time.sleep(0.5)

                        # Wheel scroll fallback
                        if not found:
                            for _ in range(5):
                                if app_btn.exists() and app_btn.is_visible():
                                    found = True
                                    break
                                self.main_window.wheel_scroll(-1)
                                time.sleep(0.5)

                    except Exception as e:
                        self._log_result("Add Apps", False, f"Scrolling failed: {str(e)}")

                if not found:
                    self._log_result("Add Apps", False, f"{app_name} button not visible, skipping...")
                    continue

                # Click the app item
                app_btn.click_input()
                time.sleep(0.5)
                self._log_result("Add Apps", True, f"{app_name} selected")

                # Continue button
                continue_btn = self.main_window.child_window(title="Continue", control_type="Button")
                for _ in range(5):
                    if continue_btn.exists() and continue_btn.is_enabled():
                        break
                    time.sleep(0.5)

                if not continue_btn.exists() or not continue_btn.is_enabled():
                    self._log_result("Add Apps", False, f"Continue not enabled for {app_name}, skipping...")
                    continue

                continue_btn.click_input()
                time.sleep(1)
                self._log_result("Add Apps", True, f"Continue clicked for {app_name}")

                # Check > (Next) button one time
                next_btn = self.main_window.child_window(
                    title="Next",
                    auto_id="ReactPCContextAware.Carousel.NextButton",
                    control_type="Button"
                )
                if next_btn.exists() and next_btn.is_visible() and not next_shown_logged:
                    self._log_result("Add Apps", True, "> (Next) button appeared in carousel — continuing to add apps")
                    next_shown_logged = True

                #  ONLY click Add (+) if not the last app
                if index < len(apps_to_add) - 1:

                    add_btn = self.main_window.child_window(
                        title="Add Application",
                        auto_id="ReactPCContextAware.Carousel.AddButton",
                        control_type="Button"
                    )
                    for _ in range(5):
                        if add_btn.exists() and add_btn.is_visible():
                            break
                        time.sleep(0.5)
                    else:
                        self._log_result("Add Apps", False, "Add (+) button not found to add next app")
                        continue

                    add_btn.click_input()
                    time.sleep(1)
                    self._log_result("Add Apps", True, "Add (+) button clicked")

                else:
                    self._log_result("Add Apps", True, f"No more apps to add after {app_name}")

            if not next_shown_logged:
                self._log_result("Add Apps", True, "> (Next) button did not appear in carousel during app addition")

            return True

        except Exception as e:
            self._log_result("Add Apps", False, f"Exception occurred: {str(e)}")
            return False






 
# ---------------- Main ----------------
if __name__ == "__main__":
    hp_app = MyHP()
    if hp_app.open_hp_application():
        if hp_app.connect_to_application():
            if hp_app.navigate_to_Audio():
                # if hp_app.navigate_to_CA():
                    # if hp_app.add_multiple_apps1():
                    #     if hp_app.click_carousel_next():
                    # if hp_app.verify_carousel_apps():
                    # if hp_app.navigate_to_CA():
                        # if hp_app.dump_ui_tree_to_file():
                    # if hp_app.search_app_add():
                        # if hp_app.verify_calculator_in_carousel():
                        # if hp_app.add_multiple_apps():
                        # if hp_app.dump_ui_tree_to_file():
                if hp_app.verify_carousel_app_tooltips():
                            # if hp_app.del_app():
                   
                    print("success")    