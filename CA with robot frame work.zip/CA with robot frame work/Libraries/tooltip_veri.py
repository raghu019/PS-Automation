# tooltip_veri.py
import time
from pywinauto import Application
import pygetwindow as gw

# ---------------- Logger ----------------
def _log_result(test_name, status, message=""):
    result = "PASS" if status else "FAIL"
    print(f"[{result}] {test_name}: {message}")

def _log_debug(message):
    print(f"[DEBUG] {message}")

# ---------------- Delete any app from carousel/Appbar ----------------
def del_app():
    """
    FULL WORKFLOW:
    1. Click ANY app → Delete → Continue
    2. Click ANY app → Delete → Checkbox + Continue
    3. Click ANY app → Delete → VERIFY NO POPUP APPEARS
    4. Delete any remaining apps in carousel if possible
    """

    try:
        # ---------------- Connect to HP main window ----------------
        hp_windows = [w for w in gw.getAllTitles() if "HP" in w and w.strip()]
        if not hp_windows:
            _log_result("Connect to Application", False, "No running HP window found")
            return False

        main_title = None
        for w in hp_windows:
            if "Service" not in w and "Support" not in w and "Quick" not in w:
                main_title = w
                break

        if not main_title:
            _log_result("Connect to Application", False, "Main HP window not found")
            return False

        application = Application(backend="uia").connect(title=main_title)
        main_window = application.window(title=main_title)
        _log_result("Connect to Application", True, f"Connected to: {main_title}")

        # ---------------- Carousel Auto IDs ----------------
        app_auto_ids = [
            ("Administrative Tools", "ReactPCContextAware.Carousel.CarouselItem2328013EC67257A5EFF59B60098FEB2B"),
            ("Calculator", "ReactPCContextAware.Carousel.CarouselItem2399C925B35566234AB600C70B12C40E"),
            ("Calendar", "ReactPCContextAware.Carousel.CarouselItemC24AD5F1F800ED5D431B6E23DAB94B1B"),
            ("Command Prompt", "ReactPCContextAware.Carousel.CarouselItem638D987E05CF5DE7460A01837C024F19"),
            ("Copilot", "ReactPCContextAware.Carousel.CarouselItem5256B9B8FF48BCECD8077FC44CBF239E"),
        ]

        # ---------------- Helper Functions ----------------
        def click_any_app():
            for app_name, auto_id in app_auto_ids:
                app_item = main_window.child_window(auto_id=auto_id, control_type="ListItem")
                if app_item.exists(timeout=3) and app_item.is_visible():
                    app_item.click_input()
                    time.sleep(1)
                    _log_result("Clicked App", True, f"App: {app_name}")
                    return app_name
            _log_result("Clicked App", False, "No visible app found in carousel")
            return None

        def click_delete_button():
            delete_btn = main_window.child_window(
                title="Delete profile",
                auto_id="ReactPCContextAware.Carousel.DeleteProfileButton",
                control_type="Button"
            )
            if delete_btn.exists(timeout=5) and delete_btn.is_enabled():
                delete_btn.click_input()
                time.sleep(1)
                _log_result("Delete Profile", True, "Delete profile clicked")
                return True
            _log_result("Delete Profile", False, "Delete button not visible or disabled")
            return False

        def popup_continue():
            btn = main_window.child_window(
                title="Continue",
                auto_id="ReactPCContextAware.DeleteProfileModal.ContinueButton",
                control_type="Button"
            )
            if btn.exists(timeout=4):
                btn.click_input()
                time.sleep(1)
                _log_result("Popup Continue", True, "Continue clicked")
                return True
            _log_result("Popup Continue", False, "Continue button not found")
            return False

        def popup_checkbox_continue():
            checkbox = main_window.child_window(
                title="Do not show again",
                auto_id="ReactPCContextAware.DeleteProfileModal.ConfirmationCheckbox__checkbox",
                control_type="CheckBox"
            )
            if checkbox.exists(timeout=4):
                checkbox.click_input()
                time.sleep(0.5)
                _log_result("Popup Checkbox", True, "Checkbox selected")
            else:
                _log_result("Popup Checkbox", False, "Checkbox not found")
            return popup_continue()

        # ---------------- Workflow ----------------
        _log_debug("Starting delete workflow...")

        # Step 1: Delete → Continue
        app_name = click_any_app()
        if app_name and click_delete_button():
            popup_continue()

        # Step 2: Delete → Checkbox + Continue
        app_name = click_any_app()
        if app_name and click_delete_button():
            popup_checkbox_continue()

        # Step 3: Delete again → Verify no popup appears
        app_name = click_any_app()
        if app_name and click_delete_button():
            time.sleep(2)
            popup = main_window.child_window(title="Delete Profile", control_type="Window")
            if popup.exists(timeout=1):
                _log_result("Popup Verification", False, "Popup appeared again! Not expected.")
            else:
                _log_result("Popup Verification", True, "No popup appeared as expected.")

        # Step 4: Delete any remaining apps in carousel
        _log_debug("Deleting remaining apps in carousel...")
        for app_name, auto_id in app_auto_ids:
            app_item = main_window.child_window(auto_id=auto_id, control_type="ListItem")
            if app_item.exists(timeout=2) and app_item.is_visible():
                app_item.click_input()
                time.sleep(1)
                if click_delete_button():
                    popup_continue()
                    _log_result("Cleanup Delete", True, f"Deleted remaining app: {app_name}")
                else:
                    _log_result("Cleanup Delete", False, f"Cannot delete app: {app_name}")

        _log_debug("Delete workflow completed.")
        return True

    except Exception as e:
        _log_result("Delete Workflow", False, str(e))
        return False

# ---------------- Run del_app directly ----------------
if __name__ == "__main__":
    if del_app():
        print("Delete workflow completed successfully.")
    else:
        print("Delete workflow failed.")
