import pyautogui
import pygetwindow as gw
from pywinauto import Application
import os
import sys
import io
import time
from pywinauto.timings import Timings
from pywinauto.timings import wait_until_passes
from pywinauto import Desktop

class MyHP:
    TIMEOUT = 5
 
    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"
        self.baseline_folder = r"C:\Users\cmit\Desktop\HPX\Baseline"
        # if not os.path.exists(self.baseline_folder):
        #     os.makedirs(self.baseline_folder)
 
    # ---------------- Logger ----------------
    def _log_result(self, test_name, status, message=""):
        result = "PASS" if status else "FAIL"
        print(f"[{result}] {test_name}: {message}")

    def _log_debug(self, message):
        print(f"[DEBUG] {message}")


 
    # ---------------- Open HP Application ----------------
    def open_hp_application(self):
        """Open HP application using Windows search"""
        try:
            pyautogui.press('winleft')
            time.sleep(1)
            pyautogui.write(self.app_title)
            time.sleep(1)
            pyautogui.press('enter')
            time.sleep(5)
 
            active_window = gw.getActiveWindow()
            if active_window and self.app_title in active_window.title:
                active_window.maximize()
                time.sleep(2)
                self._log_result("Open Application", True)
                return True
            else:
                self._log_result("Open Application", False, "Wrong window focused")
                return False
        except Exception as e:
            self._log_result("Open Application", False, str(e))
            return False
 
    # ---------------- Connect to HP Application ----------------
    def connect_to_application(self):
        try:
            # Wait for the app to open properly
            time.sleep(3)
 
            # Get all open windows containing 'HP'
            hp_windows = [w for w in gw.getAllTitles() if "HP" in w and w.strip() != ""]
 
            if not hp_windows:
                self._log_result("Connect to Application", False, "No HP window found")
                return False
 
            # Print them to console for visibility
            print("\n[INFO] Detected HP-related windows:")
            for w in hp_windows:
                print(f"   - {w}")
 
            # Try to pick the main HP App window
            # (Adjust this condition to your exact app title if needed)
            main_title = None
            for w in hp_windows:
                if "HP" in w and "Service" not in w and "Support" not in w and "Quick" not in w:
                    main_title = w
                    break
 
            if not main_title:
                self._log_result("Connect to Application", False, "Main HP window not found")
                return False
 
            print(f"\n[INFO] Connecting to window: {main_title}")
 
            # Connect to that specific window
            self.application = Application(backend="uia").connect(title=main_title)
            self.main_window = self.application.window(title=main_title)
            time.sleep(2)
 
            self._log_result("Connect to Application", True, f"Connected to: {main_title}")
           
            # self.main_window.print_control_identifiers()
            return True
 
        except Exception as e:
            self._log_result("Connect to Application", False, str(e))
            return False


    def dump_ui_tree_to_file(self):
            """Dump the full UI tree of the current main window to a text file."""
            if not self.main_window:
                self._log_result("Dump UI Tree", False, "Application not connected")
                return False
            try:
                dump_path = os.path.join(self.baseline_folder, "ui_dump.txt")
                with open(dump_path, "w", encoding="utf-8") as f:
                    buffer = io.StringIO()
                    sys.stdout = buffer
                    self.main_window.print_control_identifiers()
                    sys.stdout = sys.__stdout__  # Reset stdout
                    f.write(buffer.getvalue())
                    buffer.close()
                self._log_result("Dump UI Tree", True, f"Saved to {dump_path}")
                return True
            except Exception as e:
                sys.stdout = sys.__stdout__  # Ensure stdout is reset
                self._log_result("Dump UI Tree", False, str(e))
                return False




# ---------------- Navigate to Audio control ----------------
    
        
    def navigate_to_Audio(self):
        """Navigate to the Audio module inside PC Device page"""
        if not self.main_window:
            self._log_result("Navigate to Audio", False, "Application not connected")
            return False

        try:
            # Ensure HPX window is active
            self.main_window.set_focus()
            time.sleep(5)  # Wait for PC Device page to load

            # Locate Audio card button
            audio_btn = self.main_window.child_window(
                auto_id="PcDeviceCards.PcDeviceActionCards.PcaudioXCoreCard",
                control_type="Button"
            )

            # Perform a small scroll down (instead of full Page Down)

            # for _ in range(10): # Adjust number of scrolls as needed
            self.main_window.type_keys("{PGDN}")
            time.sleep(1)

            # Click Audio card if found
            if audio_btn.exists(timeout=5):
                audio_btn.click_input()
                time.sleep(10)
                self._log_result("Navigate to audio page", True)
                return True
            else:
                self._log_result("Navigate to audio page", False, "Audio module button not found")
                return False

        except Exception as e:
            self._log_result("Navigate to audio page", False, str(e))






    # ---------------- Verify Carousel Apps ----------------

    def verify_carousel_apps(self):
            """
            Verify that required apps exist in the carousel (title-based check only).
            """

            if not self.main_window:
                self._log_result("Carousel Verification", False, "Application not connected")
                return False

            # --- Apps to verify based on title only ---
            apps = [
                "Administrative Tools",
                "Calculator",
                "Calendar",
                "Command Prompt",
                "Copilot"
            ]

            all_passed = True

            try:
                for app_name in apps:

                    # Locate using only the title (simple & reliable)
                    item = self.main_window.child_window(
                        title=f"carousel-item-{app_name}",
                        control_type="ListItem"
                    )

                    if item.exists(timeout=10):
                        self._log_result(app_name, True, f"'{app_name}' present in carousel/Appbar")
                    else:
                        self._log_result(app_name, False, f"'{app_name}' NOT found in carousel/Appbar")
                        all_passed = False

                return all_passed

            except Exception as e:
                self._log_result("Carousel Verification", False, str(e))
                return False
            

    # ---------------- Launch Multiple Apps from Search ----------------

    def launch_multiple_apps_from_search(self):
        """
        Launch multiple predefined apps from Windows search bar and keep them open.
        Wait for 2 minutes after each launch. Example apps: Calculator, Clock, Calendar.
        """
        try:
            apps_to_launch = ["Calculator", "Clock", "Command prompt"]

            for app in apps_to_launch:
                pyautogui.press('winleft')      # Open Windows search
                time.sleep(1)

                pyautogui.write(app)            # Type app name
                time.sleep(2)

                pyautogui.press('enter')        # Launch app
                time.sleep(3)                   # Allow app to open

                # Keep app in focus
                windows = gw.getWindowsWithTitle(app)
                if windows:
                    windows[0].activate()

                # Log success
                self._log_result("Launch App", True, f"'{app}' launched and focused successfully")

                time.sleep(2)                 # Wait for 2 minutes before next app

            return True

        except Exception as e:
            self._log_result("Launch Multiple Apps", False, f"Error: {str(e)}")

# ---------------- Main ----------------
if __name__ == "__main__":
    hp_app = MyHP()
    if hp_app.open_hp_application():
         if hp_app.connect_to_application():
            if hp_app.navigate_to_Audio():
                # if hp_app.dump_ui_tree_to_file():
                if hp_app.verify_carousel_apps():
                #  if hp_app.launch_multiple_apps_from_search():
                     print("\n[INFO] Carousel apps verified successfully.")