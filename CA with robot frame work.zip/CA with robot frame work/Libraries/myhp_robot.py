# myhp_robot.py
from CA_applaunch import MyHP       # Main HP app functions
from tooltip_veri import del_app as tooltip_del_app  # Standalone function
from robot.api import logger

# Instantiate general HP app object
hp_app = MyHP()  

# ---------------- Robot Framework Keywords ----------------

def open_hp_application():
    """Open the HP application."""
    result = hp_app.open_hp_application()
    logger.info(f"Open HP Application result: {result}")
    return result

def connect_to_application():
    """Connect to the HP application."""
    result = hp_app.connect_to_application()
    logger.info(f"Connect to Application result: {result}")
    return result

def navigate_to_audio():
    """Navigate to Audio section."""
    result = hp_app.navigate_to_Audio()
    logger.info(f"Navigate to Audio result: {result}")
    return result

def verify_carousel_apps():
    """Verify carousel apps in HP application."""
    result = hp_app.verify_carousel_apps()
    if result:
        logger.info("All required carousel apps are present")
    else:
        logger.error("One or more carousel apps are missing")
    return result

def del_app():
    """
    Robot Framework keyword to delete any app from carousel/Appbar.
    """
    try:
        logger.info("Starting app deletion workflow...")
        result = tooltip_del_app()  # now calls the correct function
        if result:
            logger.info("App deletion workflow completed successfully")
        else:
            logger.error("App deletion workflow failed")
        return result
    except Exception as e:
        logger.error(f"Exception during del_app execution: {str(e)}")
        return False