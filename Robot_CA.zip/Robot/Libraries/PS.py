import pyautogui
import pygetwindow as gw
from pywinauto import Application
import os
import sys
import io
import time
from pywinauto.timings import Timings
from pywinauto.timings import wait_until_passes
from pywinauto import Desktop

 
class MyHP:
    TIMEOUT = 5
 
    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"
        self.baseline_folder = r"C:\Users\cmit\Pictures\Robot\Libraries\Identifiers"
        # if not os.path.exists(self.baseline_folder):
        #     os.makedirs(self.baseline_folder)
 
    # ---------------- Logger ----------------
    def _log_result(self, test_name, status, message=""):
        result = "PASS" if status else "FAIL"
        print(f"[{result}] {test_name}: {message}")

    def _log_debug(self, message):
        print(f"[DEBUG] {message}")


 
    # ---------------- Open HP Application ----------------
    def open_hp_application(self):
        """Open HP application using Windows search"""
        try:
            pyautogui.press('winleft')
            time.sleep(1)
            pyautogui.write(self.app_title)
            time.sleep(1)
            pyautogui.press('enter')
            time.sleep(5)
 
            active_window = gw.getActiveWindow()
            if active_window and self.app_title in active_window.title:
                active_window.maximize()
                time.sleep(2)
                self._log_result("Open Application", True)
                return True
            else:
                self._log_result("Open Application", False, "Wrong window focused")
                return False
        except Exception as e:
            self._log_result("Open Application", False, str(e))
            return False
 
    # ---------------- Connect to HP Application ----------------
    def connect_to_application(self):
        try:
            # Wait for the app to open properly
            time.sleep(3)
 
            # Get all open windows containing 'HP'
            hp_windows = [w for w in gw.getAllTitles() if "HP" in w and w.strip() != ""]
 
            if not hp_windows:
                self._log_result("Connect to Application", False, "No HP window found")
                return False
 
            # Print them to console for visibility
            print("\n[INFO] Detected HP-related windows:")
            for w in hp_windows:
                print(f"   - {w}")
 
            # Try to pick the main HP App window
            # (Adjust this condition to your exact app title if needed)
            main_title = None
            for w in hp_windows:
                if "HP" in w and "Service" not in w and "Support" not in w and "Quick" not in w:
                    main_title = w
                    break
 
            if not main_title:
                self._log_result("Connect to Application", False, "Main HP window not found")
                return False
 
            print(f"\n[INFO] Connecting to window: {main_title}")
 
            # Connect to that specific window
            self.application = Application(backend="uia").connect(title=main_title)
            self.main_window = self.application.window(title=main_title)
            time.sleep(2)
 
            self._log_result("Connect to Application", True, f"Connected to: {main_title}")
           
            # self.main_window.print_control_identifiers()
            return True
 
        except Exception as e:
            self._log_result("Connect to Application", False, str(e))
            return False
 
    # ---------------- Print Window Dump ----------------
    # def print_window_dump(self):
    #     """Print a hierarchical dump of all child windows"""
    #     if self.main_window:
    #         print("\n--- Window Dump ---")
    #         self.main_window.print_control_identifiers()
    #     else:
    #         self._log_result("Window Dump", False, "Main window not connected")

    def dump_ui_tree_to_file(self):
        """Dump the full UI tree of the current main window to a text file."""
        if not self.main_window:
            self._log_result("Dump UI Tree", False, "Application not connected")
            return False
        try:
            dump_path = os.path.join(self.baseline_folder, "ui_dump.txt")
            with open(dump_path, "w", encoding="utf-8") as f:
                buffer = io.StringIO()
                sys.stdout = buffer
                self.main_window.print_control_identifiers()
                sys.stdout = sys.__stdout__  # Reset stdout
                f.write(buffer.getvalue())
                buffer.close()
            self._log_result("Dump UI Tree", True, f"Saved to {dump_path}")
            return True
        except Exception as e:
            sys.stdout = sys.__stdout__  # Ensure stdout is reset
            self._log_result("Dump UI Tree", False, str(e))
            return False
 


  # ---------------- Navigate to Audio control ----------------         
       
            
    def navigate_to_Audio(self):
        """Navigate to the Audio module inside PC Device page"""

        # ---------- Print Test Case Header ----------
        print("\nTEST CASE 1: Navigate to Audio for CA module")
        print("-" * 60)

        if not self.main_window:
            self._log_result("Navigate to Audio", False, "Application not connected")
            print("Test case 'Navigate to Audio' completed : FAIL")
            print("-" * 60)
            return False

        try:
            self.main_window.set_focus()
            time.sleep(3)

            audio_btn = self.main_window.child_window(
                auto_id="PcDeviceCards.PcDeviceActionCards.PcaudioXCoreCard",
                control_type="Button"
            )

            # ---------- Step 1: Page Down ----------
            self.main_window.type_keys("{PGDN}")
            time.sleep(1)

            # ---------- Step 2: Two UP nudges ----------
            self.main_window.type_keys("{UP}")
            time.sleep(0.5)
            self.main_window.type_keys("{UP}")
            time.sleep(0.5)

            # ---------- Step 3: Click Audio ----------
            if audio_btn.exists(timeout=3):
                audio_btn.click_input()
                time.sleep(10)
                self._log_result("Navigate to audio page", True)
                print("\nOverall test results : PASS")
                print("-" * 60)
                return True

            self._log_result(
                "Navigate to audio page",
                False,
                "Audio card not visible after PGDN + UP UP"
            )
            print("\nOverall test results : FAIL")
            print("-" * 60)
            return False

        except Exception as e:
            self._log_result("Navigate to audio page", False, str(e))
            print("\nOverall test results : FAIL")
            print("-" * 60)
            return False






    # ---------------- Delete the apps from app bar----------------
                        
     
    def del_app(self):
        """
        FULL WORKFLOW:

        1. Click ANY app → Delete → Continue
        2. Click ANY app → Delete → Cancel (optional)
        3. Click ANY app → Delete → Checkbox + Continue
        4. AGAIN Click ANY app → Delete → VERIFY NO POPUP APPEARS
        5. After workflow, delete any remaining apps in carousel if possible
        """

        if not self.main_window:
            self._log_result("Click Any App", False, "Application not connected")
            return False

        try:
            import time
            import re

            # --------------------------------------------------------------
            #  APP TITLES (use title/control_type ONLY for apps)
            # --------------------------------------------------------------
            app_titles = [
                "Administrative Tools",
                "Calculator",
                "Calendar",
                "Command Prompt",
                "Copilot",
                "HP System Information",
                "Disk Cleanup",
                "LinkedIn",
            ]

            # Build the carousel item title exactly as exposed by the UI
            def carousel_title_for(app_name: str) -> str:
                return f"carousel-item-{app_name}"

            # --------------------------------------------------------------
            # Helper → Click ANY visible app in carousel (TITLE-ONLY)
            # --------------------------------------------------------------
            def click_any_app():
                # Try known apps first (deterministic order)
                for app_name in app_titles:
                    app_item = self.main_window.child_window(
                        title=carousel_title_for(app_name),
                        control_type="ListItem"
                    )
                    if app_item.exists(timeout=3) and app_item.is_visible():
                        app_item.click_input()
                        time.sleep(1)
                        self._log_result("Clicked App", True, f"App: {app_name}")
                        return app_name  # Return app name for logging

                # Fallback: click any visible carousel item by prefix
                any_item = self.main_window.child_window(
                    title_re=r"(?i)^carousel-item-",
                    control_type="ListItem"
                )
                if any_item.exists(timeout=3) and any_item.is_visible():
                    txt = (any_item.window_text() or "").strip()
                    m = re.match(r"(?i)^carousel-item-(.+)$", txt)
                    fallback_name = m.group(1).strip() if m else txt or "<Unnamed>"
                    any_item.click_input()
                    time.sleep(1)
                    self._log_result("Clicked App", True, f"App: {fallback_name}")
                    return fallback_name

                self._log_result("Clicked App", False, "No visible app found in carousel")
                return None

            # --------------------------------------------------------------
            # Delete button (unchanged)
            # --------------------------------------------------------------
            def click_delete_button():
                delete_btn = self.main_window.child_window(
                    title="Delete profile",
                    auto_id="ReactPCContextAware.Carousel.DeleteProfileButton",
                    control_type="Button"
                )

                if delete_btn.exists(timeout=5):
                    if delete_btn.is_enabled():
                        time.sleep(1)
                        delete_btn.click_input()
                        time.sleep(1)
                        self._log_result("Delete Profile", True, "Delete profile clicked")
                        return True
                    else:
                        self._log_result("Delete Profile", False, "Delete button disabled for this app")
                        return False

                self._log_result("Delete Profile", False, "Delete profile not visible")
                return False

            # --------------------------------------------------------------
            # Delete Popup buttons (unchanged)
            # --------------------------------------------------------------
            def popup_continue():
                btn = self.main_window.child_window(
                    title="Continue",
                    auto_id="ReactPCContextAware.DeleteProfileModal.ContinueButton",
                    control_type="Button"
                )
                if btn.exists(timeout=4):
                    time.sleep(1)
                    btn.click_input()
                    time.sleep(1)
                    self._log_result("Popup Continue", True, "Continue clicked")
                    return True

                self._log_result("Popup Continue", False, "Continue not found")
                return False

            def popup_checkbox_continue():
                checkbox = self.main_window.child_window(
                    title="Do not show again",
                    auto_id="ReactPCContextAware.DeleteProfileModal.ConfirmationCheckbox__checkbox",
                    control_type="CheckBox"
                )

                if checkbox.exists(timeout=4):
                    checkbox.click_input()
                    time.sleep(0.5)
                    self._log_result("Popup Checkbox", True, "Checkbox selected")
                else:
                    self._log_result("Popup Checkbox", False, "Checkbox not found")

                return popup_continue()

            # ===================================================================
            # WORKFLOW
            # ===================================================================

            # Step 1: Click ANY app → Delete → Continue
            app_name = click_any_app()
            if app_name and click_delete_button():
                popup_continue()

            # Step 3: Click ANY app → Delete → Checkbox + Continue
            app_name = click_any_app()
            if app_name and click_delete_button():
                popup_checkbox_continue()

            # Step 4: AGAIN Click ANY app → Delete → VERIFY NO POPUP APPEARS
            app_name = click_any_app()
            if app_name and click_delete_button():
                time.sleep(2)
                popup = self.main_window.child_window(title="Delete Profile", control_type="Window")

                if popup.exists(timeout=1):
                    self._log_result("Popup Verification", False, "Popup appeared again! Not expected.")
                else:
                    self._log_result("Popup Verification", True, "No popup appeared as expected.")

            # Step 5: After workflow, delete any remaining apps in carousel (TITLE-ONLY)
            self._log_debug("Checking for remaining apps to delete...")
            for app_name in app_titles:
                app_item = self.main_window.child_window(
                    title=carousel_title_for(app_name),
                    control_type="ListItem"
                )
                if app_item.exists(timeout=2) and app_item.is_visible():
                    app_item.click_input()
                    time.sleep(1)
                    if click_delete_button():
                        popup_continue()  # Use Continue for cleanup
                        self._log_result("Cleanup Delete", True, f"Deleted remaining app: {app_name}")
                    else:
                        self._log_result("Cleanup Delete", False, f"Cannot delete app: {app_name}")

            # Optional: attempt cleanup for any other visible carousel items not in app_titles
            # (still TITLE-ONLY; helps if new apps appear dynamically)
            any_item = self.main_window.child_window(
                title_re=r"(?i)^carousel-item-",
                control_type="ListItem"
            )
            tries = 0
            while tries < 10 and any_item.exists(timeout=2) and any_item.is_visible():
                txt = (any_item.window_text() or "").strip()
                m = re.match(r"(?i)^carousel-item-(.+)$", txt)
                extra_name = m.group(1).strip() if m else txt or "<Unnamed>"
                any_item.click_input()
                time.sleep(1)
                if click_delete_button():
                    popup_continue()
                    self._log_result("Cleanup Delete", True, f"Deleted remaining app: {extra_name}")
                else:
                    self._log_result("Cleanup Delete", False, f"Cannot delete app: {extra_name}")
                tries += 1
                # refresh for next iteration
                any_item = self.main_window.child_window(
                    title_re=r"(?i)^carousel-item-",
                    control_type="ListItem"
                )

            return True

        except Exception as e:
            self._log_result("Select Any App for Focus", False, str(e))
            return False




    # ---------------- Navigate to CA module/Add button click ----------------

    def navigate_to_CA(self):
        """Navigate to the CA module and open Add Application modal, then cancel"""

        print("\nTEST CASE 2: Navigate to CA module and Click Add button")
        print("-" * 60)

        if not self.main_window:
            self._log_result("CA", False, "Application not connected")
            return False
        try:
            time.sleep(3)  # wait for CA page to load

            # ---------- CLICK ADD APPLICATION BUTTON ----------
            add_btn = self.main_window.child_window(
                title="Add Application",
                auto_id="ReactPCContextAware.Carousel.AddButton",
                control_type="Button"
            )

            if add_btn.exists(timeout=10):
                add_btn.click_input()
                time.sleep(1)  # wait 1 second after opening modal
                self._log_result("Custom app Button clicked", True)
                
                # ---------- CLICK CANCEL BUTTON IN MODAL ----------
                cancel_btn = self.main_window.child_window(
                    title="Cancel",
                    control_type="Button"
                )
                if cancel_btn.exists(timeout=5) and cancel_btn.is_enabled():
                    cancel_btn.click_input()
                    time.sleep(1)
                    self._log_result("Add Application modal cancelled", True)
                    print("\nOverall Test results  : PASS")
                    print("-" * 60)
                    return True
                else:
                    self._log_result("Cancel button", False, "Cancel button not found or disabled")
                    print("\nOverall Test results  : FAIL")
                    print("-" * 60)
                    return False
            else:
                self._log_result("Add button exist", False, "Add Application button failed to click")
                print("\nOverall Test results  : FAIL")
                print("-" * 60)
                return False

        except Exception as e:
            self._log_result("Add button clicking", False, str(e))
            print("\nOverall Test results  : FAIL")
            print("-" * 60)
            return False



#    # ---------------- Click Next button to scroll the apps in carousel/Appbar ----------------

    def click_carousel_next(self):
        """Click the carousel Next button to scroll apps"""
        print("\nTEST CASE 6: Click Carousel Next Button")
        print("-" * 60)
        if not self.main_window:
            self._log_result("Carousel Next Button", False, "Application not connected")
            return False

        try:
            # Locate the Next button in Audio carousel
            next_btn = self.main_window.child_window(
                title="Next",
                auto_id="ReactPCContextAware.Carousel.NextButton",
                control_type="Button"
            )

            if not next_btn.exists(timeout=5):
                self._log_result("Carousel Next Button", False, "Next button not found")
                print("\nOverall Test results  : FAIL")
                print("-" * 60)
                return False
            
            # Click Next button 10 times
            for _ in range(10):
                next_btn.click_input()
                time.sleep(1)

            self._log_result("Carousel Next Button clicked", True)
            print("\nOverall Test results  : PASS")
            print("-" * 60)
            return True

        except Exception as e:
            self._log_result("Carousel Next Button", False, str(e))
            print("\nOverall Test results  : FAIL")
            print("-" * 60)
            return False





# ---------------- Verify tooltip for each carousel app ----------------
            
    def verify_carousel_app_tooltips(self):
        """
        Verify tooltip for each carousel app.
        """
        print("\nTEST CASE 8: Verify Carousel App Tooltips in app bar")
        print("-" * 60)

        if not self.main_window:
            self._log_result("Carousel Tooltip Check", False, "Application not connected")
            print("OVERALL TEST RESULT : FAIL")
            print("-" * 60)
            return False

        overall_pass = True   

        app_names = [
            "Administrative Tools",
            "Calculator",
            "Disney+",
            "爱奇艺",
            "腾讯视频",
            "Calendar",
            "Command Prompt",
            "Copilot",
            "HP System Information",
        ]

        def get_app_item(name):
            return self.main_window.child_window(
                title=f"carousel-item-{name}",
                control_type="ListItem"
            )

        def reset_carousel_focus():
            try:
                all_apps = self.main_window.child_window(
                    title="For all applications",
                    auto_id="ReactPCContextAware.Carousel.AllAppsButton",
                    control_type="ListItem"
                )
                if all_apps.exists(timeout=1):
                    time.sleep(0.5)
            except:
                pass

        def get_tooltip_text():
            try:
                for tip in self.main_window.descendants(control_type="ToolTip"):
                    text = tip.window_text().strip()
                    if text:
                        return text
            except:
                pass
            return None

        try:
            for expected_name in app_names:

                app_item = get_app_item(expected_name)

                if not app_item.exists(timeout=1):
                    reset_carousel_focus()
                    if not self.click_carousel_next():
                        self._log_result(expected_name, False, "Next button not available")
                        overall_pass = False
                        continue

                    time.sleep(3)
                    app_item = get_app_item(expected_name)

                if not app_item.exists(timeout=1):
                    self._log_result(expected_name, False, "App not found after one Next click")
                    overall_pass = False
                    continue

                reset_carousel_focus()
                previous_tooltip = get_tooltip_text()

                try:
                    app_item.click_input()
                    app_item.set_focus()
                    time.sleep(0.6)
                except Exception as e:
                    self._log_result(expected_name, False, f"Click failed: {str(e)}")
                    overall_pass = False
                    continue

                tooltip_text = None
                for _ in range(15):
                    current_tooltip = get_tooltip_text()
                    if current_tooltip and current_tooltip != previous_tooltip:
                        tooltip_text = current_tooltip
                        break
                    time.sleep(0.3)

                if not tooltip_text:
                    self._log_result(expected_name, False, "Tooltip not visible after click")
                    overall_pass = False
                    reset_carousel_focus()
                    continue

                if expected_name.lower() in tooltip_text.lower():
                    self._log_result(
                        expected_name, True, f"Tooltip matched: {tooltip_text}"
                    )
                else:
                    self._log_result(
                        expected_name, False, f"Tooltip mismatched: {tooltip_text}"
                    )
                    overall_pass = False

                reset_carousel_focus()

            #  PRINT OVERALL RESULT ONCE
            print("-" * 60)
            print(f"OVERALL TEST RESULT : {'PASS' if overall_pass else 'FAIL'}")
            print("-" * 60)

            return overall_pass

        except Exception as e:
            self._log_result("Carousel Tooltip Check", False, str(e))
            print("-" * 60)
            print("OVERALL TEST RESULT : FAIL")
            print("-" * 60)
            return False









    # ---------------- Verify application is present in carousel or not ----------------


    def verify_carousel_apps(self):
        """
        Verify that required apps exist in the carousel (title-based check only).
        Continues verification even if one or more apps are missing.
        """
        print("\nTEST CASE 7: Verify added Apps are existing in Appbar/Carousel")
        print("-" * 60)

        if not self.main_window:
            self._log_result("Carousel Verification", False, "Application not connected")
            print("OVERALL TEST RESULT : FAIL")
            print("-" * 60)
            self.available_carousel_apps = []
            return True   # Non-blocking

        apps = [
            "Administrative Tools",
            "Calculator",
            "Disney+",
            "爱奇艺",
            "腾讯视频",
            "Calendar",
            "Command Prompt",
            "Copilot",
            "Disk Cleanup",
            "HP System Information",
            "LinkedIn",
        ]

        self.available_carousel_apps = []
        overall_pass = True   # single overall flag

        try:
            for app_name in apps:
                item = self.main_window.child_window(
                    title=f"carousel-item-{app_name}",
                    control_type="ListItem"
                )

                if item.exists(timeout=10):
                    self._log_result(
                        app_name, True, f"'{app_name}' present in carousel/Appbar"
                    )
                    self.available_carousel_apps.append(app_name)
                else:
                    self._log_result(
                        app_name, False, f"'{app_name}' NOT found in carousel/Appbar"
                    )
                    overall_pass = False

            #  PRINT OVERALL RESULT ONCE
            print("-" * 60)
            print(f"OVERALL TEST RESULT : {'PASS' if overall_pass else 'FAIL'}")
            print("-" * 60)

            return True   # Non-blocking

        except Exception as e:
            self._log_result("Carousel Verification", False, str(e))
            self.available_carousel_apps = []
            print("-" * 60)
            print("OVERALL TEST RESULT : FAIL")
            print("-" * 60)
            return True







    # ---------------- Add Multiple Apps (IMPROVED SCROLLING) ----------------

    def add_multiple_apps2(self):
        """
        Flow enforced:
        Add (+) → Find app → Scroll → Select app → Continue → Add (+)
        If app not visible, select Administrative Tools first to enable scrolling.
        """
        print("\nTEST CASE 4: Add Multiple Apps to carosel/Appbar")
        print("-" * 60)

        try:
            self._log_result("Add Apps", True, "Starting process for multiple apps")

            apps_to_add = [
                ("Administrative Tools", "ReactPCContextAware.InstalledAppsModal.AppItem2328013EC67257A5EFF59B60098FEB2B"),
                ("Calculator", "ReactPCContextAware.InstalledAppsModal.AppItem2399C925B35566234AB600C70B12C40E"),
                ("Calendar", "ReactPCContextAware.InstalledAppsModal.AppItemC24AD5F1F800ED5D431B6E23DAB94B1B"),
                ("Command Prompt", "ReactPCContextAware.InstalledAppsModal.AppItem638D987E05CF5DE7460A01837C024F19"),
                ("Copilot", "ReactPCContextAware.InstalledAppsModal.AppItem5256B9B8FF48BCECD8077FC44CBF239E"),
                ("HP System Information", "ReactPCContextAware.InstalledAppsModal.AppItem9C026CA7D49ECD66C934D6F700F17501"),
                ("Disk Cleanup", "ReactPCContextAware.InstalledAppsModal.AppItemCECE0E77E37C64AEE9DB38229F0D72C7"),
                ("LinkedIn", "ReactPCContextAware.InstalledAppsModal.AppItem554B1A3213ECA0D51534E50B794A4C09"),
            ]

            for index, (app_name, app_id) in enumerate(apps_to_add):

                # ---------- STEP 1: CLICK ADD (+) ----------
                add_btn = self.main_window.child_window(
                    auto_id="ReactPCContextAware.Carousel.AddButton",
                    control_type="Button"
                )

                if not add_btn.exists(timeout=5):
                    self._log_result("Add Apps", False, "Add (+) button not found")
                    return False

                add_btn.click_input()
                time.sleep(1)
                self._log_result("Add Apps", True, "Add (+) clicked")

                # ---------- STEP 2: FIND TARGET APP ----------
                app_btn = self.main_window.child_window(
                    auto_id=app_id,
                    control_type="Button"
                )

                found = False

                # If target app is already visible, no scroll needed
                if app_btn.exists() and app_btn.is_visible():
                    found = True
                    self._log_result("Add Apps", True, f"{app_name} found without scrolling")
                else:
                    # Select Administrative Tools first to enable scrolling
                    admin_tool_btn = self.main_window.child_window(
                        auto_id="ReactPCContextAware.InstalledAppsModal.AppItem2328013EC67257A5EFF59B60098FEB2B",
                        control_type="Button"
                    )
                    if admin_tool_btn.exists() and admin_tool_btn.is_visible():
                        admin_tool_btn.click_input()
                        time.sleep(0.3)
                        self._log_result("Add Apps", True, "Administrative Tools selected to enable scrolling")

                    # Scroll down to find target app
                    for _ in range(15):
                        if app_btn.exists() and app_btn.is_visible():
                            found = True
                            break
                        self.main_window.type_keys("{PGDN}")
                        time.sleep(0.4)

                if not found:
                    self._log_result("Add Apps", False, f"{app_name} not found, skipping")
                    continue

                # ---------- STEP 3: SELECT TARGET APP ----------
                app_btn.click_input()
                time.sleep(0.5)
                self._log_result("Add Apps", True, f"{app_name} selected")

                # ---------- STEP 4: CLICK CONTINUE ----------
                continue_btn = self.main_window.child_window(
                    title="Continue",
                    control_type="Button"
                )

                for _ in range(5):
                    if continue_btn.exists() and continue_btn.is_enabled():
                        break
                    time.sleep(0.5)

                if not continue_btn.exists() or not continue_btn.is_enabled():
                    self._log_result("Add Apps", False, f"Continue not enabled for {app_name}")
                    continue

                continue_btn.click_input()
                time.sleep(1)
                self._log_result("Add Apps", True, f"Continue clicked for {app_name}")

                # ---------- STEP 5: READY FOR NEXT APP ----------
                if index < len(apps_to_add) - 1:
                    self._log_result("Add Apps", True, "Preparing to add next app")
                else:
                    self._log_result("Add Apps", True, f"Last app {app_name} added")
                    print("\nOverall Test results  : PASS")
                    print("-" * 60)

            return True

        except Exception as e:
            self._log_result("Add Apps", False, f"Exception occurred: {str(e)}")
            print("\nOverall Test results  : FAIL")
            print("-" * 60)
            return False








    # ---------------- Launch & verify multiple apps are focus in Appbar ----------------

    def launch_and_verify_multiple_apps_appbar(self):
        """
        Launch apps from Windows search and verify each one becomes
        selected / highlighted in HP Audio App Bar.
        """

        if not self.main_window:
            self._log_result("Audio Selection", False, "Application not connected")
            return True   # Non-blocking

        # Use only apps that exist in carousel
        apps = getattr(self, "available_carousel_apps", [])

        if not apps:
            self._log_result("Audio Selection", False, "No carousel apps available to verify")
            return True

        for app_name in apps:
            try:
                pyautogui.press('winleft')
                time.sleep(1)
                pyautogui.write(app_name)
                time.sleep(2)
                pyautogui.press('enter')
                time.sleep(4)

                windows = gw.getWindowsWithTitle(app_name)
                if not windows:
                    self._log_result(app_name, False, "App window not found")
                    continue

                windows[0].activate()
                time.sleep(2)

                self.main_window.set_focus()
                time.sleep(3)

                carousel_item = self.main_window.child_window(
                    title=f"carousel-item-{app_name}",
                    control_type="ListItem"
                )

                if not carousel_item.exists(timeout=10):
                    self._log_result(app_name, False, "application not found")
                    continue

                if carousel_item.is_selected():
                    self._log_result(app_name, True, "Application launched and highlighted in App Bar")
                else:
                    self._log_result(app_name, False, "App launched but not selected in App Bar")

                time.sleep(3)

            except Exception as e:
                self._log_result(app_name, False, str(e))

        return True   # Never block execution







# ----------------  Verify Global Appbar is higlight by Launch Notepad/click time and date in taskbar &----------------

    def launch_notepad_and_verify_global_appbar(self):
        """
        Launch Notepad and verify:
        1. If Notepad is not in the carousel → check 'For all applications' is selected.
        2. If Notepad is in the carousel → click taskbar clock and verify 'For all applications' persists.
        """

        if not self.main_window:
            self._log_result("Notepad", False, "Application not connected")
            return True   # Non-blocking

        try:
            app_name = "Notepad"

            # -------- Launch Notepad --------
            pyautogui.press('winleft')
            time.sleep(1)
            pyautogui.write(app_name)
            time.sleep(2)
            pyautogui.press('enter')
            time.sleep(4)

            # Bring HP app back to focus
            self.main_window.set_focus()
            time.sleep(2)

            # -------- Check carousel --------
            carousel_item = self.main_window.child_window(
                title=f"carousel-item-{app_name}",
                control_type="ListItem"
            )

            if carousel_item.exists(timeout=5):
                self._log_result(
                    app_name,
                    True,
                    "Application launched and highlighted in carousel"
                )

                # -------- Click Windows Taskbar Clock --------
                try:
                    taskbar = Desktop(backend="uia").window(class_name="Shell_TrayWnd")
                    clock_btn = taskbar.child_window(title_re="Clock.*", control_type="Button")

                    if clock_btn.exists(timeout=5):
                        clock_btn.click_input()
                        time.sleep(2)

                        # Verify 'For all applications' highlight persists
                        global_item = self.main_window.child_window(
                            title="For all applications",
                            auto_id="ReactPCContextAware.Carousel.AllAppsButton",
                            control_type="ListItem"
                        )
                        if global_item.exists(timeout=5):
                            if global_item.is_selected():
                                self._log_result(
                                    "For all applications",
                                    True,
                                    "Global application still SELECTED after opening calendar"
                                )
                            else:
                                self._log_result(
                                    "For all applications",
                                    False,
                                    "Global application NOT selected after opening calendar"
                                )
                        else:
                            self._log_result("For all applications", False, "Global application item not found")

                    else:
                        self._log_result("Taskbar Clock", False, "Clock button not found")

                except Exception as e:
                    self._log_result("Taskbar Clock", False, f"Error: {e}")

                return True

            else:
                # -------- Notepad NOT in carousel --------
                self._log_result(
                    app_name,
                    False,
                    "Application launched but not found in carousel so global app slected (Expected)"
                )

                # Verify 'For all applications'
                global_item = self.main_window.child_window(
                    title="For all applications",
                    auto_id="ReactPCContextAware.Carousel.AllAppsButton",
                    control_type="ListItem"
                )

                if not global_item.exists(timeout=10):
                    self._log_result(
                        "For all applications",
                        False,
                        "Global application item not found"
                    )
                    return True

                if global_item.is_selected():
                    self._log_result(
                        "For all applications",
                        True,
                        "Global application SELECTED for Notepad"
                    )
                else:
                    self._log_result(
                        "For all applications",
                        False,
                        "Global application NOT selected for Notepad"
                    )

                return True   # Never block execution

        except Exception as e:
            self._log_result("Notepad", False, str(e))
            return True



# ---------------- Verify IMAX apps are visible in carousel ----------------

    def verify_imax_apps_in_carousel(self):
        """Verify IMAX apps are visible in carousel"""
        print("TEST CASE 2: Verify IMAX apps are visible in carousel")
        print("-" * 60)
        try:
            # Ensure main window is active
            self.main_window.set_focus()
            time.sleep(3)

            # Define expected IMAX apps
            imax_apps = [
                "carousel-item-Disney+",
                "carousel-item-腾讯视频",
                "carousel-item-爱奇艺"
            ]

            missing_apps = []

            # Check each app in carousel
            for app in imax_apps:
                app_item = self.main_window.child_window(
                    title=app,
                    control_type="ListItem"
                )
                if not app_item.exists(timeout=5):
                    missing_apps.append(app)

            # Log result
            if missing_apps:
                if len(missing_apps) == 1:
                    self._log_result("Verify IMAX apps in carousel", False,
                                    f"1 IMAX app not found: {missing_apps[0]}")
                    print("\nOverall Test results  : FAIL")
                    print("-" * 60)
                else:
                    self._log_result("Verify IMAX apps in carousel", False,
                                    f"{len(missing_apps)} IMAX apps not found: {', '.join(missing_apps)}")
                    print("\nOverall Test results  : FAIL")
                    print("-" * 60)
                return False
            else:
                self._log_result("IMAX apps are present in carousel", True)
                print("\nOverall Test results  : PASS")
                print("-" * 60)
                return True

        except Exception as e:
            self._log_result("IMAX apps are present in carousel", False, str(e))
            print("\nOverall Test results  : FAIL")
            print("-" * 60)
            return False



    # ---------------- Search and Add Application ----------------

    def search_and_add_application(self):

        """
        Open Add Application modal, search Calculator, select it and click Continue
        """
        print("\nTEST CASE 5: Search and Add Application to carosel/Appbar")
        print("-" * 60)

        if not self.main_window:
            self._log_result("Add App", False, "Application not connected")
            return False

        try:
            # -------- CONFIG (INSIDE FUNCTION) --------
            search_text = "Link"
            app_title = "LinkedIn"

            time.sleep(3)  # wait for CA page to load

            # ---------- CLICK ADD APPLICATION ----------
            add_btn = self.main_window.child_window(
                title="Add Application",
                auto_id="ReactPCContextAware.Carousel.AddButton",
                control_type="Button"
            )

            if not add_btn.exists(timeout=10):
                self._log_result("Add Application", False, "Add Application button not found")
                return False

            add_btn.click_input()
            time.sleep(1)
            self._log_result("Add Application", True, "Add Application modal opened")

            # ---------- SEARCH APPLICATION ----------
            search_box = self.main_window.child_window(
                auto_id="ReactPCContextAware.InstalledAppsModal.SearchApplication__text-box",
                control_type="Edit"
            )

            if not search_box.exists(timeout=10):
                self._log_result("Search App", False, "Search box not found")
                return False

            search_box.click_input()
            time.sleep(0.5)
            search_box.type_keys("^a{BACKSPACE}")
            search_box.type_keys(search_text, with_spaces=True)
            time.sleep(2)

            self._log_result("Search App", True, f"Searched for {search_text}")

            # ---------- SELECT APPLICATION ----------
            app_btn = self.main_window.child_window(
                title=app_title,
                control_type="Button"
            )

            if not app_btn.exists(timeout=10):
                self._log_result("Select App", False, f"{app_title} not found")
                return False

            app_btn.click_input()
            time.sleep(1)
            self._log_result("Select App", True, f"{app_title} selected")

            # ---------- CLICK CONTINUE ----------
            continue_btn = self.main_window.child_window(
                title="Continue",
                auto_id="ReactPCContextAware.InstalledAppsModal.ContinueButton",
                control_type="Button"
            )

            if continue_btn.exists(timeout=5) and continue_btn.is_enabled():
                continue_btn.click_input()
                self._log_result("Continue", True, "Continue button clicked")
                print("\nOverall Test results  : PASS")
                print("-" * 60)
                return True
            else:
                self._log_result("Continue", False, "Continue button not enabled")
                print("\nOverall Test results  : FAIL")
                print("-" * 60)
                return False

        except Exception as e:
            self._log_result("Add Application", False, str(e))
            print("\nOverall Test results  : FAIL")
            print("-" * 60)
            return False





# ---------------- Verify Back button navigation from PC Device page to L1 page ----------------

    def device_page_backbutton(self):
        """
        TEST CASE 9: Verify Back button navigation from PC Device page
        """

        print("\nTEST CASE 9: Verify Back button navigation from PC Device page")
        print("-" * 60)

        # if not self.connect_to_application():
        #     print("OVERALL TEST RESULT : FAIL")
        #     print("-" * 60)
        #     return False

        try:
            back_button = self.main_window.child_window(
                auto_id="NavBar.NavBarView.BackButton",
                control_type="Button"
            ).wait('enabled', timeout=2)

            if back_button:
                time.sleep(2)
                back_button.click_input()
                time.sleep(3)

                self._log_result(
                    "Back Button",
                    True,
                    "Back button clicked and navigated to L1 page"
                )

                print("OVERALL TEST RESULT : PASS")
                print("-" * 60)
                return True

            else:
                self._log_result(
                    "Back Button",
                    False,
                    "Back button not clickable"
                )

                print("OVERALL TEST RESULT : FAIL")
                print("-" * 60)
                return False

        except Exception as e:
            self._log_result(
                "Back Button",
                False,
                f"Back button not found: {e}"
            )

            print("OVERALL TEST RESULT : FAIL")
            print("-" * 60)
            return False





 
# ---------------- Main ----------------
if __name__ == "__main__":
    hp_app = MyHP()
    if hp_app.open_hp_application():
        if hp_app.connect_to_application():
            if hp_app.navigate_to_Audio():
                if hp_app.verify_imax_apps_in_carousel():
                    if hp_app.navigate_to_CA():
                        if hp_app.add_multiple_apps2():
                            if hp_app.search_and_add_application():
                                if hp_app.click_carousel_next():
                                    if hp_app.verify_carousel_apps():
                                        if hp_app.verify_carousel_app_tooltips():
                                            if hp_app.device_page_backbutton():
                                            
                        #                         if hp_app.dump_ui_tree_to_file():
                                                  print("All tests completed.")
                               