import pyautogui
import pygetwindow as gw
from pywinauto import Application
import os
import sys
import io
import time
from pywinauto.timings import Timings
from robot.libraries.BuiltIn import BuiltIn
from pywinauto.timings import wait_until
import datetime
from pywinauto.timings import wait_until_passes
from pywinauto import Desktop
from Screenshot import capture_failure_screenshot  
from datetime import datetime 
import pyperclip
import subprocess
from pywinauto.keyboard import send_keys


 
class MyHP:
    TIMEOUT = 5
 
    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"
        self.baseline_folder = r"C:\Users\CanopyR\Documents\Robot\Libraries\Identifiers"
        # if not os.path.exists(self.baseline_folder):
        #     os.makedirs(self.baseline_folder)

    def _log_result(self, test_name, status, message=""):
            """
            Central logger.
            Automatically captures screenshot on FAILURE.
            Logs to console and Robot Framework.
            """
            result = "PASS" if status else "FAIL"
            screenshot_path = None

            if not status:
                # Capture screenshot
                try:
                    screenshot_dir = os.path.join(os.getcwd(), "screenshots")
                    os.makedirs(screenshot_dir, exist_ok=True)

                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    safe_name = test_name.replace(" ", "_").replace("/", "_")
                    screenshot_path = os.path.join(screenshot_dir, f"{safe_name}_{timestamp}.png")

                    pyautogui.screenshot(screenshot_path)
                    print(f"[SCREENSHOT] Saved: {screenshot_path}")

                    # Log to Robot Framework
                    try:
                        BuiltIn().log(
                            f"{result}: {test_name} - {message}<br>"
                            f"Screenshot: <a href='{screenshot_path}'>{screenshot_path}</a>",
                            html=True
                        )
                    except Exception as e:
                        print(f"[ROBOT LOGGING FAILED] {e}")

                except Exception as e:
                    print(f"[SCREENSHOT ERROR] {e}")

            # Console output
            if screenshot_path:
                print(f"[{result}] {test_name}: {message} | Screenshot: {screenshot_path}")
            else:
                print(f"[{result}] {test_name}: {message}")

    def _log_debug(self, message):
                """
                Debug logger.
                Prints debug messages to console and Robot Framework log.
                """
                print(f"[DEBUG] {message}")
                try:
                    BuiltIn().log(f"[DEBUG] {message}")
                except Exception:
                    pass


 

            # ---------------- Open HP Application ----------------
    def open_hp_application(self):
        try:
            pyautogui.press("winleft")
            time.sleep(1)
            pyautogui.write(self.app_title)
            time.sleep(1)
            pyautogui.press("enter")
            time.sleep(5)

            self._log_result("Open Application", True)
            return True

        except Exception as e:
            self._log_result("Open Application", False, str(e))
            return False
    
    # # ---------------- Wait Until HP Fully Loaded ----------------
    # def wait_for_hp_ready(self):
    #     try:
    #         timeout=60
    #         start_time = time.time()
    #         while time.time() - start_time < timeout:
    #             windows = gw.getWindowsWithTitle(self.app_title)
    #             if windows:
    #                 win = windows[0]
    #                 if win.visible:
    #                     win.maximize()
    #                     self._log_result("Wait for HP Ready", True)
    #                     return
    #             time.sleep(1)
 
    #         self._log_result("Wait for HP Ready", False, "HP not ready within timeout")
    #     except Exception as e:
    #         self._log_result("Wait for HP Ready", False, str(e))
 


    def connect_to_application(self):

            try:
                windows = Desktop(backend="uia").windows(title="HP")

                if not windows:
                    raise Exception("HP window not found")

                print(f"DEBUG: Found {len(windows)} HP windows")

                selected = None
                max_area = 0

                for win in windows:
                    try:
                        if win.is_visible():
                            rect = win.rectangle()
                            area = rect.width() * rect.height()

                            if area > max_area:
                                max_area = area
                                selected = win
                    except:
                        pass

                if not selected:
                    raise Exception("No valid window found")

        
                self.main_window = Desktop(backend="uia").window(handle=selected.handle)

                # Wait properly
                self.main_window.wait("visible", timeout=10)

                self.main_window.set_focus()

                print(f"DEBUG: Connected to window = {self.main_window.window_text()}")

                self._log_result("Connect to Application", True)
                return True

            except Exception as e:
                self.main_window = None
                self._log_result("Connect to Application", False, str(e))
                return False



    # ---------------- Handle Location Permission ----------------

    def handle_location_permission_popup(self):
        """Handle location popup only if it appears"""

        try:
            time.sleep(2)

            active_window = gw.getActiveWindow()

            # Check if any active window exists
            if active_window and active_window.title:
                title = active_window.title.lower()

                # Check if location permission popup is active
                if "location" in title:
                    self._log_debug(f"Location popup detected: {title}")

                    # Default focus = No → move to Yes
                    pyautogui.press("tab")
                    time.sleep(0.5)
                    pyautogui.press("enter")
                    time.sleep(2) 

                    self._log_result("Location Permission", True, "Clicked YES")
                    return True

            # Popup not present → continue
            self._log_debug("Location popup not present - continuing test")
            return True

        except Exception as e:
            self._log_result("Location Permission", False, str(e))
            return False

        

    # ---------------- Click Accept All ----------------

    def click_accept_all_button(self):
        """Click Accept all consent button if popup appears"""
        try:
            if not self.main_window:
                self._log_result("Accept All", True, "HP window not connected - skipping")
                return True

            btn = self.main_window.child_window(
                auto_id="FuFConsents.FuFConsents.AcceptAllButton",
                control_type="Button"
            )

            if btn.wait("exists enabled visible ready", timeout=4):
                btn.set_focus()
                btn.click_input()
                time.sleep(2)
                self._log_result("Accept All", True, "Clicked Accept All")
            else:
                self._log_result("Accept All", True, "Popup not present - skipped")

            return True

        except Exception as e:
            self._log_result("Accept All", True, f"Skipped due to exception: {e}")
            return True
        

    # ---------------- Continue As Guest ----------------

    def click_continue_as_guest_button(self):
        """Click Continue as guest button if popup appears"""
        try:
            if not self.main_window:
                self._log_result("Continue As Guest", True, "HP window not connected - skipping")
                return True

            btn = self.main_window.child_window(
                title="Continue as guest",
                auto_id="WelcomeScreen.WelcomeScreenView.ContinueAsGuestButton",
                control_type="Button"
            )

            # Check if popup exists
            if btn.exists(timeout=5):
                btn.click_input()
                time.sleep(3)
                self._log_result("Continue As Guest", True, "Clicked")
            else:
                self._log_result("Continue As Guest", True, "Popup not present - skipped")

            return True

        except Exception as e:
            self._log_result("Continue As Guest", True, f"Skipped due to exception: {e}")
            return True


    # ---------------- Maximize HP Application ----------------

    def maximize_hp_application(self):
        try:
            windows = gw.getWindowsWithTitle(self.app_title)

            if windows:
                win = windows[0]
                win.activate()
                win.maximize()
                time.sleep(2)

                self._log_result("Maximize Application", True)
                return True

            self._log_result("Maximize Application", False, "HP window not found")
            return False

        except Exception as e:
            self._log_result("Maximize Application", False, str(e))
            return False
        
    def navigate_to_pc_device(self):
        pc_device = self.main_window.child_window(
            auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname",
            control_type="Text"
        )

        if pc_device.exists(timeout=5):
            time.sleep(3)
            pc_device.click_input()
            time.sleep(3)
            return True
        return False


    # ---------------- Handle Startup Conditions ----------------

    def handle_startup_conditions(self):

        try:

            self.handle_location_permission_popup()
            self.maximize_hp_application()
            self.click_accept_all_button()
            self.click_continue_as_guest_button()
            self.navigate_to_pc_device()

            self._log_result("Startup Handling", True)
            return True

        except Exception as e:
            self._log_result("Startup Handling", False, str(e))
            return False

    
    
   
   
    # ---------------- Dump UI Tree to File ----------------

    def dump_ui_tree_to_file(self):
        """Dump the full UI tree of the current main window to a text file."""
        if not self.main_window:
            self._log_result("Dump UI Tree", False, "Application not connected")
            return False
        try:
            dump_path = os.path.join(self.baseline_folder, "ui_dump.txt")
            with open(dump_path, "w", encoding="utf-8") as f:
                buffer = io.StringIO()
                sys.stdout = buffer
                self.main_window.print_control_identifiers()
                sys.stdout = sys.__stdout__  # Reset stdout
                f.write(buffer.getvalue())
                buffer.close()
            self._log_result("Dump UI Tree", True, f"Saved to {dump_path}")
            return True
        except Exception as e:
            sys.stdout = sys.__stdout__  # Ensure stdout is reset
            self._log_result("Dump UI Tree", False, str(e))
            return False
 

            
        # ---------------- Navigate to Audio control ----------------         

    
  # ---------------- Navigate to Audio control ----------------         
       
            
    def navigate_to_Audio(self):
        """Navigate to the Audio module inside PC Device page"""

        # ---------- Print Test Case Header ----------
        print("\nTEST CASE 1: Navigate to Audio for CA module")
        print("-" * 60)

        if not self.main_window:
            self._log_result("Navigate to Audio", False, "Application not connected")
            print("Test case 'Navigate to Audio' completed : FAIL")
            print("-" * 60)
            return False

        try:
            self.main_window.set_focus()
            time.sleep(7) 

            audio_btn = self.main_window.child_window(
                # title_re=".*Display.*",
                auto_id="PcDeviceCards.PcDeviceActionCards.PcaudioXCoreCard",
                control_type="Button"
            )

            # ---------- Step 1: Page Down ----------
            self.main_window.type_keys("{PGDN}") 
            time.sleep(2)

            # ---------- Step 2: Two UP nudges ----------
            for _ in range(8):
                self.main_window.type_keys("{UP}")
                time.sleep(1)

            # ---------- Step 3: Click Audio ----------
            if audio_btn.exists(timeout=3): 
                time.sleep(2)
                audio_btn.click_input()
                time.sleep(8)
                self._log_result("Navigate to audio page", True)
                print("\nOverall test results : PASS")
                print("-" * 60)
                return True

            self._log_result(
                "Navigate to audio page",
                False,
                "Audio card not visible after PGDN + UP UP"
            )
            print("\nOverall test results : FAIL")
            print("-" * 60)
            return False 

        except Exception as e:
            self._log_result("Navigate to audio page", False, str(e))
            print("\nOverall test results : FAIL")
            print("-" * 60)
            return False





        # ---------------- Delete the apps from app bar----------------
                            
            

    def TC_ID_C51570661_Delete_Custom_OOB_App(self):
        
        """
        Delete Custom OOB Apps workflow with popup verification and cleanup
        Always returns True/False (never None)
        """

        print("\nTEST CASE: Delete Custom OOB Apps")
        print("-" * 60)

        if not self.main_window:
            self._log_result("Delete Custom OOB App", False, "Application not connected")
            print("\nOverall Test results  : FAIL")
            print("-" * 60)
            return False

        success = True  

        try:
            import time
            time.sleep(3)

            # ------------------------------
            # GET CAROUSEL ITEMS (UPDATED ONLY HERE)
            # ------------------------------
            def get_carousel_items():
                all_items = self.main_window.descendants(control_type="ListItem")
                items = []
                for item in all_items:
                    try:
                        txt = item.window_text().strip()

                        # UPDATED: New UI (removed carousel-item- logic)
                        if txt and txt not in ["For all applications", "Add Application"]:
                            items.append(item)

                    except:
                        pass
                return items

            # ------------------------------
            # CLICK ANY APP (UPDATED 1 LINE ONLY)
            # ------------------------------
            def click_any_app():
                items = get_carousel_items()
                for item in items:
                    if item.is_visible():
                        app_name = item.window_text().strip()   # ✅ UPDATED
                        item.click_input()
                        time.sleep(1)
                        self._log_result("Clicked App", True, f"App: {app_name}")
                        return True
                self._log_result("Clicked App", False, "No visible app found")
                return False

            # ------------------------------
            # CLICK DELETE
            # ------------------------------
            def click_delete():
                delete_btn = self.main_window.child_window(
                    title="Delete profile",
                    auto_id="ReactPCContextAware.Carousel.DeleteProfileButton",
                    control_type="Button"
                )

                if delete_btn.exists(timeout=5) and delete_btn.is_enabled():
                    delete_btn.click_input()
                    time.sleep(1)
                    self._log_result("Delete Profile", True, "Delete profile clicked")
                    return True

                self._log_result("Delete Profile", False, "Delete button not available")
                return False

            # ------------------------------
            # CLICK CONTINUE
            # ------------------------------
            def click_continue(optional=False):
                cont = self.main_window.child_window(
                    title="Continue",
                    auto_id="ReactPCContextAware.DeleteProfileModal.ContinueButton",
                    control_type="Button"
                )

                if cont.exists(timeout=2):
                    cont.click_input()
                    time.sleep(1)
                    self._log_result("Popup Continue", True, "Continue clicked")
                    return True

                if optional:
                    self._log_result("Popup Continue", True, "Popup skipped (expected)")
                    return True

                self._log_result("Popup Continue", False, "Continue not found")
                return False

            # ------------------------------
            # CHECKBOX + CONTINUE
            # ------------------------------
            
            def checkbox_continue():
                checkbox = self.main_window.child_window(
                    title="Do not show again",
                    control_type="CheckBox"
                )

                label = self.main_window.child_window(
                    title="Do not show again",
                    control_type="Text"
                )

                if checkbox.exists(timeout=3):
                    try:
                        # Step 1: click label (main trigger)
                        if label.exists():
                            label.click_input()
                        else:
                            checkbox.click_input()

                        time.sleep(1)

                        # Step 2: VERIFY + FORCE TOGGLE (IMPORTANT)
                        state = checkbox.get_toggle_state()

                        if state == 0:
                            checkbox.toggle()   #  force toggle using UIA
                            time.sleep(1)

                        self._log_result("Popup Checkbox", True, "Checkbox selected")

                    except Exception as e:
                        self._log_result("Popup Checkbox", False, str(e))
                        return False

                return click_continue()

            # =====================================================
            # STEP 1
            # =====================================================
            if not (click_any_app() and click_delete() and click_continue()):
                success = False

            # =====================================================
            # STEP 2
            # =====================================================
            if not (click_any_app() and click_delete() and checkbox_continue()):
                success = False

            # =====================================================
            # STEP 3 - VERIFY POPUP DOES NOT REAPPEAR
            # =====================================================
            if click_any_app() and click_delete():

                time.sleep(2)

                popup = self.main_window.child_window(
                    title="Delete Profile",
                    control_type="Window"
                )

                if popup.exists(timeout=1):
                    self._log_result("Popup Verification", False, "Popup appeared again")
                    success = False
                else:
                    self._log_result("Popup Verification", True, "No popup appeared as expected")

            # =====================================================
            # CLEANUP LOOP
            # =====================================================
            self._log_debug("Cleaning remaining apps...")

            tries = 0
            while tries < 20:
                items = get_carousel_items()
                if not items:
                    self._log_debug("No more carousel apps found.")
                    break

                items[0].click_input()
                time.sleep(1)

                if click_delete():
                    click_continue(optional=True)
                    self._log_result("Cleanup Delete", True, "Remaining app deleted")
                else:
                    success = False

                tries += 1
                time.sleep(1)

            # =====================================================
            # FINAL RESULT
            # =====================================================
            if success:
                print("\nOverall Test results  : PASS")
            else:
                print("\nOverall Test results  : FAIL")

            print("-" * 60)

            return bool(success) 

        except Exception as e:
            self._log_result("Delete Custom OOB App", False, str(e))
            print("\nOverall Test results  : FAIL")
            print("-" * 60)
            return False





    # ---------------- Navigate to CA module/Add button click ----------------

    def TC_ID_C77290501_navigate_to_CA_and_click_Add_button(self):
        """Navigate to the CA module and open Add Application modal, then cancel"""

        print("\nTEST CASE 2: Navigate to CA module and Click Add button")
        print("-" * 60)

        if not self.main_window:
            self._log_result("CA", False, "Application not connected")
            return False
        try:
            time.sleep(3)  # wait for CA page to load

            # ---------- CLICK ADD APPLICATION BUTTON ----------
            add_btn = self.main_window.child_window(
                title="Add Application",
                auto_id="ReactPCContextAware.Carousel.AddButton",
                control_type="Button"
            )

            if add_btn.exists(timeout=10):
                add_btn.click_input()
                time.sleep(5)  # wait 1 second after opening modal
                self._log_result("Custom app Button clicked", True)
                # ---------- CLICK CANCEL BUTTON IN MODAL ----------
                cancel_btn = self.main_window.child_window(
                    title="Cancel",
                    control_type="Button"
                )
                if cancel_btn.exists(timeout=15) and cancel_btn.is_enabled():
                    cancel_btn.click_input()
                    time.sleep(1)
                    self._log_result("Add Application modal cancelled", True)
                    print("\nOverall Test results  : PASS")
                    print("-" * 60)
                    return True
                else:
                    self._log_result("Cancel button", False, "Cancel button not found or disabled")
                    print("\nOverall Test results  : FAIL")
                    print("-" * 60)
                    return False
            else:
                self._log_result("Add button exist", False, "Add Application button failed to click")
                print("\nOverall Test results  : FAIL")
                print("-" * 60)
                return False

        except Exception as e:
            self._log_result("Add button clicking", False, str(e))
            print("\nOverall Test results  : FAIL")
            print("-" * 60)
            return False



#    # ---------------- Click Next button to scroll the apps in carousel/Appbar ----------------

    def TC_ID_C51570652_click_carousel_next(self):

        """Click the carousel Next button to scroll apps"""
        print("\nTEST CASE 6: Click Carousel Next Button")
        print("-" * 60)
        if not self.main_window:
            self._log_result("Carousel Next Button", False, "Application not connected")
            return False

        try:
            # Locate the Next button in Audio carousel
            next_btn = self.main_window.child_window(
                title="Next",
                auto_id="ReactPCContextAware.Carousel.NextButton",
                control_type="Button"
            )

            if not next_btn.exists(timeout=5):
                self._log_result("Carousel Next Button", False, "Next button not found")
                print("\nOverall Test results  : FAIL")
                print("-" * 60)
                return False
            
            # Click Next button 10 times
            for _ in range(4):
                next_btn.click_input()
                time.sleep(1)

            self._log_result("Carousel Next Button clicked", True)
            print("\nOverall Test results  : PASS")
            print("-" * 60)
            return True

        except Exception as e:
            self._log_result("Carousel Next Button", False, str(e))
            print("\nOverall Test results  : FAIL")
            print("-" * 60)
            return False



    def click_carousel_next(self):
        """
        Click carousel Next button once (reliable)
        """
        try:
            next_btn = self.main_window.child_window(
                title="Next",
                auto_id="ReactPCContextAware.Carousel.NextButton",
                control_type="Button"
            )

            if next_btn.exists(timeout=2) and next_btn.is_enabled():
                next_btn.click_input()
                time.sleep(1)
                return True

        except Exception as e:
            print("Error clicking Next:", str(e))

        return False





            # ---------------- Verify tooltip for each carousel app ----------------
    def TC_ID_C60424978_verify_carousel_app_tooltips(self):
        
        """
        Verify tooltip for each carousel app.
        """
        print("\nTEST CASE 8: Verify Carousel App Tooltips in app bar")
        print("-" * 60)

        if not self.main_window:
            self._log_result("Carousel Tooltip Check", False, "Application not connected")
            print("OVERALL TEST RESULT : FAIL")
            print("-" * 60)
            return False

        overall_pass = True   

        app_names = [
            "Calculator",
            "LiveCaptions",
            "Clock",
            "Command Prompt",
        ]

        def get_app_item(name):
            try:
                items = self.main_window.descendants(control_type="ListItem")
                for item in items:
                    try:
                        text = item.window_text().strip()
                        if text and name.lower() in text.lower():
                            return item
                    except:
                        continue
            except:
                pass
            return None

        def get_tooltip_text(expected_name):
            """
            Improved tooltip detection (retry + match specific app)
            """
            for _ in range(20):
                try:
                    for tip in self.main_window.descendants(control_type="ToolTip"):
                        text = tip.window_text().strip()
                        if text and expected_name.lower() in text.lower():
                            return text
                except:
                    pass
                time.sleep(0.3)
            return None

        try:
            for expected_name in app_names:

                found = False

                # Scroll until app is found
                for _ in range(15):
                    app_item = get_app_item(expected_name)

                    if app_item:
                        found = True
                        break

                    if not self.click_carousel_next():
                        break

                    time.sleep(1)

                if not found:
                    self._log_result(expected_name, False, "App not found after scrolling")
                    overall_pass = False
                    continue

                # Re-fetch element
                app_item = get_app_item(expected_name)

                try:
                    if app_item is None:
                        raise Exception("Element not found")

                    if not app_item.is_visible():
                        raise Exception("Element not visible")

                    # FINAL FIX: click + proper wait
                    app_item.click_input()
                    time.sleep(1.5)

                except Exception as e:
                    self._log_result(expected_name, False, f"Interaction failed: {str(e)}")
                    overall_pass = False
                    continue

                # FINAL FIX: improved tooltip detection
                tooltip_text = get_tooltip_text(expected_name)

                if not tooltip_text:
                    self._log_result(expected_name, False, "Tooltip not visible after click")
                    overall_pass = False
                    continue

                if expected_name.lower() in tooltip_text.lower():
                    self._log_result(
                        expected_name, True, f"Tooltip matched: {tooltip_text}"
                    )
                else:
                    self._log_result(
                        expected_name, False, f"Tooltip mismatched: {tooltip_text}"
                    )
                    overall_pass = False

            print("-" * 60)
            print(f"OVERALL TEST RESULT : {'PASS' if overall_pass else 'FAIL'}")
            print("-" * 60)

            return True

        except Exception as e:
            self._log_result("Carousel Tooltip Check", False, str(e))
            print("-" * 60)
            print("OVERALL TEST RESULT : FAIL")
            print("-" * 60)
            return False






    # ---------------- Verify application is present in carousel or not ----------------


    def TC_ID_C77291045_verify_carousel_apps(self):
        """
        Verify that required apps exist in the carousel (title-based check only).
        Continues verification even if one or more apps are missing.
        """
        print("\nTEST CASE 7: Verify added Apps are existing in Appbar/Carousel")
        print("-" * 60)

        if not self.main_window:
            self._log_result("Carousel Verification", False, "Application not connected")
            print("OVERALL TEST RESULT : FAIL")
            print("-" * 60)
            self.available_carousel_apps = []
            return True   # Non-blocking

        apps = [
            "Administrative Tools",
            "Calculator",
            "Feedback Hub",
            "LiveCaptions",
            "Magnify",
            "Clock",
            "Command Prompt",
            "Microsoft 365 Copilot",
            "Access",
            "Character Map",
            "LinkedIn",
        ]

        self.available_carousel_apps = []
        overall_pass = True   # single overall flag

        try:
            for app_name in apps:
                item = self.main_window.child_window(
                    title=app_name,
                    control_type="ListItem"
                )

                if item.exists(timeout=10):
                    self._log_result(
                        app_name, True, f"'{app_name}' present in carousel/Appbar"
                    )
                    self.available_carousel_apps.append(app_name)
                else:
                    self._log_result(
                        app_name, False, f"'{app_name}' NOT found in carousel/Appbar"
                    )
                    overall_pass = False

            #  PRINT OVERALL RESULT ONCE
            print("-" * 60)
            print(f"OVERALL TEST RESULT : {'PASS' if overall_pass else 'FAIL'}")
            print("-" * 60)

            return True   # Non-blocking

        except Exception as e:
            self._log_result("Carousel Verification", False, str(e))
            self.available_carousel_apps = []
            print("-" * 60)
            print("OVERALL TEST RESULT : FAIL")
            print("-" * 60)
            return True







    # ---------------- Add Multiple Apps (IMPROVED SCROLLING) ----------------

    def TC_ID_C51570654_add_multiple_apps(self):
        """
        Flow enforced:
        Add (+) → Find app → Scroll → Select app → Continue → Add (+)
        If app not visible, select Administrative Tools first to enable scrolling.
        """
        print("\nTEST CASE 4: Add Multiple Apps to carosel/Appbar")
        print("-" * 60)

        try:
            self._log_result("Add Apps", True, "Starting process for multiple apps")

            apps_to_add = [

                ("Administrative Tools", "ReactPCContextAware.InstalledAppsModal.AppItem2328013EC67257A5EFF59B60098FEB2B"),
                ("Feedback Hub", "ReactPCContextAware.InstalledAppsModal.AppItem35754CE70FD833D49339A02421C97007"),
                ("LiveCaptions","ReactPCContextAware.InstalledAppsModal.AppItem0129D1E7D7570F8D575B759EAE255B33"),
                ("Magnify","ReactPCContextAware.InstalledAppsModal.AppItem1CB79190ED90A2079EB37225A66350F0"),
                ("Calculator", "ReactPCContextAware.InstalledAppsModal.AppItem2399C925B35566234AB600C70B12C40E"),
                ("Clock", "ReactPCContextAware.InstalledAppsModal.AppItem394766A9BD87112DA3EF0663591D0A21"),
                ("Command Prompt", "ReactPCContextAware.InstalledAppsModal.AppItem638D987E05CF5DE7460A01837C024F19"),
                ("Microsoft 365 Copilot", "ReactPCContextAware.InstalledAppsModal.AppItem42094310962BE8E1E01DBAED09C6C88A"),
                ("Character Map", "ReactPCContextAware.InstalledAppsModal.AppItem4D07EFF018A4F67FC6A3F21DA817AFAB"),
                ("Access", "ReactPCContextAware.InstalledAppsModal.AppItem52598671F3C527E9CC5C802D45A048C8"),
                ("LinkedIn", "ReactPCContextAware.InstalledAppsModal.AppItem554B1A3213ECA0D51534E50B794A4C09"),
            ]

            for index, (app_name, app_id) in enumerate(apps_to_add):

                # ---------- STEP 1: CLICK ADD (+) ----------
                add_btn = self.main_window.child_window(
                    auto_id="ReactPCContextAware.Carousel.AddButton",
                    control_type="Button"
                )

                if not add_btn.exists(timeout=5):
                    self._log_result("Add Apps", False, "Add (+) button not found")
                    return False

                add_btn.click_input()
                time.sleep(1)
                self._log_result("Add Apps", True, "Add (+) clicked")

                # ---------- STEP 2: FIND TARGET APP ----------
                app_btn = self.main_window.child_window(
                    auto_id=app_id,
                    control_type="Button"
                )

                found = False

                # If target app is already visible, no scroll needed
                if app_btn.exists() and app_btn.is_visible():
                    found = True
                    self._log_result("Add Apps", True, f"{app_name} found without scrolling")
                else:
                    # Select Administrative Tools first to enable scrolling
                    admin_tool_btn = self.main_window.child_window(
                        auto_id="ReactPCContextAware.InstalledAppsModal.AppItem2328013EC67257A5EFF59B60098FEB2B",
                        control_type="Button"
                    )
                    if admin_tool_btn.exists() and admin_tool_btn.is_visible():
                        admin_tool_btn.click_input()
                        time.sleep(0.3)
                        self._log_result("Add Apps", True, "Administrative Tools selected to enable scrolling")

                    # Scroll down to find target app
                    for _ in range(15):
                        if app_btn.exists() and app_btn.is_visible():
                            found = True
                            break
                        self.main_window.type_keys("{PGDN}")
                        time.sleep(0.4)

                if not found:
                    self._log_result("Add Apps", False, f"{app_name} not found, skipping")
                    continue

                # ---------- STEP 3: SELECT TARGET APP ----------
                app_btn.click_input()
                time.sleep(0.5)
                self._log_result("Add Apps", True, f"{app_name} selected")

                # ---------- STEP 4: CLICK CONTINUE ----------
                continue_btn = self.main_window.child_window(
                    title="Continue",
                    control_type="Button"
                )

                for _ in range(5):
                    if continue_btn.exists() and continue_btn.is_enabled():
                        break
                    time.sleep(0.5)

                if not continue_btn.exists() or not continue_btn.is_enabled():
                    self._log_result("Add Apps", False, f"Continue not enabled for {app_name}")
                    continue

                continue_btn.click_input()
                time.sleep(1)
                self._log_result("Add Apps", True, f"Continue clicked for {app_name}")

                # ---------- STEP 5: READY FOR NEXT APP ----------
                if index < len(apps_to_add) - 1:
                    self._log_result("Add Apps", True, "Preparing to add next app")
                else:
                    self._log_result("Add Apps", True, f"Last app {app_name} added")
                    print("\nOverall Test results  : PASS")
                    print("-" * 60)

            return True

        except Exception as e:
            self._log_result("Add Apps", False, f"Exception occurred: {str(e)}")
            print("\nOverall Test results  : FAIL")
            print("-" * 60)
            return False









    # ---------------- Launch & verify multiple apps are focus in Appbar ----------------

    def launch_and_verify_multiple_apps_appbar(self):
        """
        Launch apps from Windows search and verify each one becomes
        selected / highlighted in HP Audio App Bar.
        """

        if not self.main_window:
            self._log_result("Audio Selection", False, "Application not connected")
            return True   # Non-blocking

        # Use only apps that exist in carousel
        apps = getattr(self, "available_carousel_apps", [])

        if not apps:
            self._log_result("Audio Selection", False, "No carousel apps available to verify")
            return True

        for app_name in apps:
            try:
                pyautogui.press('winleft')
                time.sleep(1)
                pyautogui.write(app_name)
                time.sleep(2)
                pyautogui.press('enter')
                time.sleep(4)

                windows = gw.getWindowsWithTitle(app_name)
                if not windows:
                    self._log_result(app_name, False, "App window not found")
                    continue

                windows[0].activate()
                time.sleep(2)

                self.main_window.set_focus()
                time.sleep(3)

                carousel_item = self.main_window.child_window(
                    title=app_name,
                    control_type="ListItem"
                )

                if not carousel_item.exists(timeout=10):
                    self._log_result(app_name, False, "application not found")
                    continue

                if carousel_item.is_selected():
                    self._log_result(app_name, True, "Application launched and highlighted in App Bar")
                else:
                    self._log_result(app_name, False, "App launched but not selected in App Bar")

                time.sleep(3)

            except Exception as e:
                self._log_result(app_name, False, str(e))

        return True   # Never block execution







# ----------------  Verify Global Appbar is higlight by Launch Notepad/click time and date in taskbar &----------------

    def launch_notepad_and_verify_global_appbar(self):
        """
        Launch Notepad and verify:
        1. If Notepad is not in the carousel → check 'For all applications' is selected.
        2. If Notepad is in the carousel → click taskbar clock and verify 'For all applications' persists.
        """

        if not self.main_window:
            self._log_result("Notepad", False, "Application not connected")
            return True   # Non-blocking

        try:
            app_name = "Notepad"

            # -------- Launch Notepad --------
            pyautogui.press('winleft')
            time.sleep(1)
            pyautogui.write(app_name)
            time.sleep(2)
            pyautogui.press('enter')
            time.sleep(4)

            # Bring HP app back to focus
            self.main_window.set_focus()
            time.sleep(2)

            # -------- Check carousel --------
            carousel_item = self.main_window.child_window(
                title=app_name,
                control_type="ListItem"
            )

            if carousel_item.exists(timeout=5):
                self._log_result(
                    app_name,
                    True,
                    "Application launched and highlighted in carousel"
                )

                # -------- Click Windows Taskbar Clock --------
                try:
                    taskbar = Desktop(backend="uia").window(class_name="Shell_TrayWnd")
                    clock_btn = taskbar.child_window(title_re="Clock.*", control_type="Button")

                    if clock_btn.exists(timeout=5):
                        clock_btn.click_input()
                        time.sleep(2)

                        # Verify 'For all applications' highlight persists
                        global_item = self.main_window.child_window(
                            title="For all applications",
                            auto_id="ReactPCContextAware.Carousel.AllAppsButton",
                            control_type="ListItem"
                        )
                        if global_item.exists(timeout=5):
                            if global_item.is_selected():
                                self._log_result(
                                    "For all applications",
                                    True,
                                    "Global application still SELECTED after opening calendar"
                                )
                            else:
                                self._log_result(
                                    "For all applications",
                                    False,
                                    "Global application NOT selected after opening calendar"
                                )
                        else:
                            self._log_result("For all applications", False, "Global application item not found")

                    else:
                        self._log_result("Taskbar Clock", False, "Clock button not found")

                except Exception as e:
                    self._log_result("Taskbar Clock", False, f"Error: {e}")

                return True

            else:
                # -------- Notepad NOT in carousel --------
                self._log_result(
                    app_name,
                    False,
                    "Application launched but not found in carousel so global app slected (Expected)"
                )

                # Verify 'For all applications'
                global_item = self.main_window.child_window(
                    title="For all applications",
                    auto_id="ReactPCContextAware.Carousel.AllAppsButton",
                    control_type="ListItem"
                )

                if not global_item.exists(timeout=10):
                    self._log_result(
                        "For all applications",
                        False,
                        "Global application item not found"
                    )
                    return True

                if global_item.is_selected():
                    self._log_result(
                        "For all applications",
                        True,
                        "Global application SELECTED for Notepad"
                    )
                else:
                    self._log_result(
                        "For all applications",
                        False,
                        "Global application NOT selected for Notepad"
                    )

                return True   # Never block execution

        except Exception as e:
            self._log_result("Notepad", False, str(e))
            return True



# ---------------- Verify IMAX apps are visible in carousel ----------------

    def TC_ID_C51570659_verify_imax_apps_in_carousel(self):

        """Verify IMAX apps are visible in carousel"""
        print("TEST CASE 2: Verify IMAX apps are visible in carousel")
        print("-" * 60)
        try:
            # Ensure main window is active
            self.main_window.set_focus()
            time.sleep(3)

            # Define expected IMAX apps
            imax_apps = [
                "Disney",
                "腾讯视频",
                "爱奇艺"
            ]

            missing_apps = []

            # Check each app in carousel
            for app in imax_apps:
                app_item = self.main_window.child_window(
                    title_re=f".*{app}.*",
                    control_type="ListItem"
                )
                if not app_item.exists(timeout=5):
                    missing_apps.append(app)

            # Log result
            if missing_apps:
                if len(missing_apps) == 1:
                    self._log_result("Verify IMAX apps in carousel", False,
                                    f"1 IMAX app not found: {missing_apps[0]}")
                    print("\nOverall Test results  : FAIL")
                    print("-" * 60)
                else:
                    self._log_result("Verify IMAX apps in carousel", False,
                                    f"{len(missing_apps)} IMAX apps not found: {', '.join(missing_apps)}")
                    print("\nOverall Test results  : FAIL")
                    print("-" * 60)
                return False
            else:
                self._log_result("IMAX apps are present in carousel", True)
                print("\nOverall Test results  : PASS")
                print("-" * 60)
                return True

        except Exception as e:
            self._log_result("IMAX apps are present in carousel", False, str(e))
            print("\nOverall Test results  : FAIL")
            print("-" * 60)
            return False



    # ---------------- Search and Add Application ----------------

    def TC_ID_C52986236_search_and_add_application(self):

        """
        Open Add Application modal, search Calculator, select it and click Continue
        """
        print("\nTEST CASE 5: Search and Add Application to carosel/Appbar")
        print("-" * 60)

        if not self.main_window:
            self._log_result("Add App", False, "Application not connected")
            return False

        try:
            # -------- CONFIG (INSIDE FUNCTION) --------
            search_text = "Link"
            app_title = "LinkedIn"

            time.sleep(3)  # wait for CA page to load

            # ---------- CLICK ADD APPLICATION ----------
            add_btn = self.main_window.child_window(
                title="Add Application",
                auto_id="ReactPCContextAware.Carousel.AddButton",
                control_type="Button"
            )

            if not add_btn.exists(timeout=10):
                self._log_result("Add Application", False, "Add Application button not found")
                return False

            add_btn.click_input()
            time.sleep(1)
            self._log_result("Add Application", True, "Add Application modal opened")

            # ---------- SEARCH APPLICATION ----------
            search_box = self.main_window.child_window(
                auto_id="ReactPCContextAware.InstalledAppsModal.SearchApplication__text-box",
                control_type="Edit"
            )

            if not search_box.exists(timeout=10):
                self._log_result("Search App", False, "Search box not found")
                return False

            search_box.click_input()
            time.sleep(0.5)
            search_box.type_keys("^a{BACKSPACE}")
            search_box.type_keys(search_text, with_spaces=True)
            time.sleep(2)

            self._log_result("Search App", True, f"Searched for {search_text}")

            # ---------- SELECT APPLICATION ----------
            app_btn = self.main_window.child_window(
                title=app_title,
                control_type="Button"
            )

            if not app_btn.exists(timeout=10):
                self._log_result("Select App", False, f"{app_title} not found")
                return False

            app_btn.click_input()
            time.sleep(1)
            self._log_result("Select App", True, f"{app_title} selected")

            # ---------- CLICK CONTINUE ----------
            continue_btn = self.main_window.child_window(
                title="Continue",
                auto_id="ReactPCContextAware.InstalledAppsModal.ContinueButton",
                control_type="Button"
            )

            if continue_btn.exists(timeout=5) and continue_btn.is_enabled():
                continue_btn.click_input()
                self._log_result("Continue", True, "Continue button clicked")
                print("\nOverall Test results  : PASS")
                print("-" * 60)
                return True
            else:
                self._log_result("Continue", False, "Continue button not enabled")
                print("\nOverall Test results  : FAIL")
                print("-" * 60)
                return False

        except Exception as e:
            self._log_result("Add Application", False, str(e))
            print("\nOverall Test results  : FAIL")
            print("-" * 60)
            return False





# ---------------- Verify Back button navigation from PC Device page to L1 page ----------------

    def device_page_backbutton(self):
        """
        TEST CASE 9: Verify Back button navigation from PC Device page
        """

        print("\nTEST CASE 9: Verify Back button navigation from PC Device page")
        print("-" * 60)

        # ---------- Check Application Connection ----------
        if not self.main_window:
            self._log_result(
                "Back Button",
                False,
                "Application not connected"
            )

            print("OVERALL TEST RESULT : FAIL")
            print("-" * 60)
            return False

        try:
            self.main_window.set_focus()
            self.main_window.wait("exists ready", timeout=10)

            back_button = self.main_window.child_window(
                auto_id="NavBar.NavBarView.BackButton",
                control_type="Button"
            )

            # ---------- Verify Back Button ----------
            if back_button.exists(timeout=5):

                back_button.wait("enabled", timeout=5)
                time.sleep(2)

                back_button.click_input()
                time.sleep(5)

                self._log_result(
                    "Back Button",
                    True,
                    "Back button clicked and navigated to L1 page"
                )

                print("OVERALL TEST RESULT : PASS")
                print("-" * 60)
                return True

            else:

                self._log_result(
                    "Back Button",
                    False,
                    "Back button not found on screen"
                )

                print("OVERALL TEST RESULT : FAIL")
                print("-" * 60)
                return False

        except Exception as e:

            self._log_result(
                "Back Button",
                False,
                f"Back button error: {e}"
            )

            print("OVERALL TEST RESULT : FAIL")
            print("-" * 60)
            return False



    # ---------------- Verify default state of CA Apps in Audio page ----------------

    def TC_ID_C51570650_verify_default_state_of_CA_apps(self):
        
        """Verify default state of CA Apps in Audio page"""

        print("\nTEST CASE 1: Verify Default State of CA Apps")
        print("-" * 80)

        if not self.main_window:
            self._log_result("CA Apps Default State", False, "Application not connected")
            print("Overall test results : FAIL")
            print("-" * 80)
            return False

        try:
            self.main_window.set_focus()
            time.sleep(3)

            overall_status = True
            missing_oob_apps = []

            # --------------------------------------------------
            # 1. Verify ALL OOB apps are visible by default
            # --------------------------------------------------
            oob_apps = ["Disney+", "爱奇艺", "腾讯视频"]

            # Get all carousel items once (faster & stable)
            all_items = self.main_window.descendants(control_type="ListItem")
            available_titles = [item.window_text() for item in all_items]

            for app_name in oob_apps:
                if app_name in available_titles:
                    self._log_result(f"OOB app visible by default - {app_name}", True)
                else:
                    self._log_result(f"OOB app visible by default - {app_name}", False)
                    missing_oob_apps.append(app_name)
                    overall_status = False

            if missing_oob_apps:
                self._log_result(
                    "OOB apps missing",
                    False,
                    f"Missing OOB apps: {', '.join(missing_oob_apps)}"
                )

            # --------------------------------------------------
            # 2. Verify Add Application option is available
            # --------------------------------------------------
            add_app_btn = self.main_window.child_window(
                title="Add Application",
                control_type="Button"
            )

            if add_app_btn.exists(timeout=3):
                self._log_result("Add Application option available", True)
            else:
                self._log_result("Add Application option available", False)
                overall_status = False

            # --------------------------------------------------
            # 3. Verify "For all applications" default state
            # --------------------------------------------------
            all_apps = self.main_window.child_window(
                title="For all applications",
                control_type="ListItem"
            )

            if all_apps.exists(timeout=3) and all_apps.is_enabled():
                self._log_result(
                    "For all applications selected by default",
                    True,
                    "Default is selected state"
                )
            else:
                self._log_result(
                    "For all applications selected by default",
                    False,
                    "Default is not selected state"
                )
                overall_status = False

            # --------------------------------------------------
            # Final Result
            # --------------------------------------------------
            if overall_status:
                print("\nOverall test results : PASS")
            else:
                print("\nOverall test results : FAIL")

            print("-" * 80)
            return overall_status

        except Exception as e:
            self._log_result("CA Apps Default State", False, str(e))
            print("\nOverall test results : FAIL")
            print("-" * 80)
            return False

        # ---------------- Verify Delete Profile Button Enable/Disable ----------------

    def TC_ID_C51570658_verify_delete_profile_button_enable_disable(self):

            print("\nTEST CASE: Verify Delete Profile Button State")
            print("-" * 60)

            overall_pass = True

            try:
                delete_btn = self.main_window.child_window(
                    title="Delete profile",
                    control_type="Button"
                )

                # CASE 1: Delete profile already visible
                if delete_btn.exists(timeout=1):
                    self._log_result(
                        "Initial Delete Profile State",
                        True,
                        "Delete profile button is visible"
                    )

                # CASE 2: Not visible → click Disney+
                else:
                    self._log_result(
                        "Initial Delete Profile State",
                        False,
                        "Delete profile button not visible initially, clicking Disney+"
                    )

                    disney_app = self.main_window.child_window(
                        title="Calculator",
                        control_type="ListItem"
                    )

                    if disney_app.exists(timeout=2):
                        disney_app.click_input()
                        time.sleep(2)

                        if delete_btn.exists(timeout=2):
                            self._log_result(
                                "Delete Profile After Calculator",
                                True,
                                "Delete profile button visible after selecting Calculator"
                            )
                        else:
                            self._log_result(
                                "Delete Profile After Calculator Click",
                                False,
                                "Delete profile button NOT visible after selecting Calculator"
                            )
                            overall_pass = False
                    else:
                        self._log_result(
                            "Disney+ App",
                            False,
                            "Disney+ app not found in carousel"
                        )
                        overall_pass = False

                print("-" * 60)
                print(f"OVERALL TEST RESULT : {'PASS' if overall_pass else 'FAIL'}")
                print("-" * 60)

                # VERY IMPORTANT: DO NOT BLOCK EXECUTION
                return overall_pass

            except Exception as e:
                self._log_result("Delete Profile State", False, str(e))
                print("-" * 60)
                print("OVERALL TEST RESULT : FAIL")
                print("-" * 60)

                # Soft fail
                return False






     # verify application is sleceted in app bar

    def TC_ID_C51570655_verify_application_selected_in_app_bar(self):
        """
        Test Case 1:
        Verify application is selected in app bar
        
        """

        print("\nTEST CASE: Verify application selected in app bar")
        print("-" * 60)

        if not self.main_window:
            self._log_result("CA", False, "Application not connected")
            return False

        try:
            applications = [
                "Administrative Tools",
                "Command Prompt",
                "Clock"
            ]

            for app_name in applications:

                print(f"\nChecking selection for: {app_name}")

                # ---- Find carousel item ----
                carousel_item = self.main_window.child_window(
                    title=app_name,
                    control_type="ListItem"
                )

                if not carousel_item.exists(timeout=10):
                    self._log_result(app_name, False, "Carousel item not found")
                    return False

                # ---- Click carousel item ----
                carousel_item.click_input()
                time.sleep(1)

                # ---- Verify it is selected (app bar = carousel) ----
                if carousel_item.is_selected() or carousel_item.has_keyboard_focus():
                    self._log_result(
                        f"{app_name} selected",
                        True,
                        "Application is selected (carousel/app bar)"
                    )
                else:
                    self._log_result(
                        f"{app_name} selected",
                        False,
                        "Application is not selected"
                    )
                    return False

                time.sleep(2)

            print("\nOverall Test results  : PASS")
            print("-" * 60)
            return True

        except Exception as e:
            self._log_result("Selection verification", False, str(e))
            print("\nOverall Test results  : FAIL")
            print("-" * 60)
            return False






    #  ---------------- Verify selected application name and focus state----------------

    def TC_ID_C51570657_verify_selected_application_name_and_focus(self):
        
        """
        Test Case:
        Verify selected application name visibility and focus state
        (Only for mentioned apps: Administrative Tools, Calculator, Clock)
        """

        print("\nTEST CASE: Verify selected application name and focus")
        print("-" * 60)

        if not self.main_window:
            self._log_result("CA", False, "Application not connected")
            return False

        try:
            expected_apps = {
                "Administrative Tools",
                "Command Prompt",
                "Clock"
            }

            # ---- Get ALL ListItems ----
            all_list_items = self.main_window.descendants(control_type="ListItem")

            # ✅ UPDATED: removed old carousel-item filter
            carousel_items = [
                item for item in all_list_items
                if item.window_text().strip()
            ]

            if not carousel_items:
                self._log_result(
                    "Carousel",
                    False,
                    "No carousel items found"
                )
                return False

            verified_apps = set()

            for item in carousel_items:
                raw_title = item.window_text().strip()

                # UPDATED: no prefix removal
                app_name = raw_title

                # ---- CLICK ONLY EXPECTED APPS ----
                if app_name in expected_apps:
                    item.click_input()
                    time.sleep(1)

                    # ---- VERIFY NAME ----
                    self._log_result(
                        f"{app_name} name",
                        True,
                        "Application name is visible"
                    )

                    # ---- VERIFY FOCUS ----
                    if item.is_selected() or item.has_keyboard_focus():
                        self._log_result(
                            f"{app_name} focus",
                            True,
                            "Application is in focus state"
                        )
                    else:
                        self._log_result(
                            f"{app_name} focus",
                            False,
                            "Application is not in focus"
                        )
                        return False

                    verified_apps.add(app_name)
                    time.sleep(2)

                    # ---- STOP EARLY IF ALL FOUND ----
                    if verified_apps == expected_apps:
                        break

            # ---- FINAL CHECK ----
            missing = expected_apps - verified_apps
            if missing:
                self._log_result(
                    "Name & focus verification",
                    False,
                    f"Apps not verified: {', '.join(missing)}"
                )
                return False

            print("\nOverall Test results  : PASS")
            print("-" * 60)
            return True

        except Exception as e:
            self._log_result(
                "Name & focus verification",
                False,
                str(e)
            )
            print("\nOverall Test results  : FAIL")
            print("-" * 60)
            return False



#    # ---------------- Launch & verify OOB apps ----------------

    def TC_ID_C51570660_launch_and_verify_oob_apps(self):
        """
        TEST CASE : Verify OOB apps launch and carousel focus state
        """

        print("\nTEST CASE : Verify OOB apps launch and carousel focus state")
        print("-" * 60)

        import pyperclip

        try:
            oob_apps = [
                ("Disney+", "ReactPCContextAware.Carousel.CarouselItemA07DDB88965F20AE0E1C2E89F36F5B07"),
                ("爱奇艺", "ReactPCContextAware.Carousel.CarouselItem96D443B8FDA8B07AAB692A8F386CF8C0"),
                ("腾讯视频", "ReactPCContextAware.Carousel.CarouselItem41A61336B059C3F8CEB51A343050E228"),
            ]

            not_focused_apps = []

            for app_name, carousel_id in oob_apps:

                # -------- Launch from Windows (Clipboard paste supports Chinese) --------
                print(f"{app_name} launching from Windows...")

                pyautogui.press('winleft')
                time.sleep(1)

                pyperclip.copy(app_name)
                pyautogui.hotkey('ctrl', 'v')
                time.sleep(2)

                pyautogui.press('enter')
                time.sleep(11)

                # Handle "Let this app access your location?" popup (if shown)
                print("Checking for location permission popup...")
                time.sleep(2)
                pyautogui.press("tab")
                time.sleep(1)
                pyautogui.press("enter")
                time.sleep(2)

                print(f"{app_name} launched")

                # -------- Close App --------
                pyautogui.hotkey('alt', 'f4')
                time.sleep(3)

                # -------- Focus HP App --------
                self.main_window.set_focus()
                self.main_window.click_input()
                time.sleep(3)

                # -------- Locate Carousel Item --------
                carousel_item = self.main_window.child_window(
                    auto_id=carousel_id,
                    control_type="ListItem"
                )

                if carousel_item.exists(timeout=10):

                    wrapper = carousel_item.wrapper_object()
                    is_focused = False

                    # Check keyboard focus
                    try:
                        if wrapper.has_keyboard_focus():
                            is_focused = True
                    except:
                        pass

                    #  React carousel fallback (focused = selected)
                    try:
                        if wrapper.is_selected():
                            is_focused = True
                    except:
                        pass

                    if is_focused:
                        print(f"{app_name} is focused in carousel")
                    else:
                        print(f"{app_name} is NOT focused in carousel")
                        not_focused_apps.append(app_name)

                else:
                    print(f"{app_name} not found in carousel")
                    not_focused_apps.append(app_name)

            # -------- Final Result --------
            if not_focused_apps:
                self._log_result(
                    "Verify OOB apps focus state",
                    False,
                    f"{len(not_focused_apps)} apps not in focus: {', '.join(not_focused_apps)}"
                )

                print("OVERALL TEST RESULT : FAIL")
                print("-" * 60)
                return False

            else:
                self._log_result(
                    "OOB apps focus state",
                    True,
                    "All apps returned focused in carousel after launch"
                )

                print("OVERALL TEST RESULT : PASS")
                print("-" * 60)
                return True

        except Exception as e:
            self._log_result(
                "Verify OOB apps focus state",
                False,
                str(e)
            )

            print("OVERALL TEST RESULT : FAIL")
            print("-" * 60)
            return False





    # ---------------- Verify Global App focus after HP relaunch ----------------



    def TC_ID_C51570664_verify_global_app_focus_after_hp_relaunch(self):
        """
        TEST CASE ID : C51570664
        TEST CASE    : Verify Global Apps focus after HP relaunch
        """

        print("\nTEST CASE ID : C51570664 - Verify Global Apps focus after HP relaunch")
        print("-" * 60)

        try:
            # ---------------------------------------------------
            # STEP 1 : Select Administrative Tools
            # ---------------------------------------------------
            admin_tools_item = self.main_window.child_window(
                title="Administrative Tools",
                control_type="ListItem"
            ).wait('exists enabled visible', timeout=10)

            admin_tools_item.click_input()
            time.sleep(2)

            #  admin_tools_item is already a wrapper
            is_selected = False

            try:
                if admin_tools_item.has_keyboard_focus():
                    is_selected = True
            except:
                pass

            try:
                if admin_tools_item.is_selected():
                    is_selected = True
            except:
                pass

            if not is_selected:
                self._log_result(
                    " Administrative Tools Focus",
                    False,
                    "Administrative Tools not focused"
                )
                print("OVERALL TEST RESULT : FAIL")
                print("-" * 60)
                return False

            print("Administrative Tools is focused in carousel")

            # ---------------------------------------------------
            # STEP 2 : Close HP
            # ---------------------------------------------------
            print("Closing HP application...")
            pyautogui.hotkey('alt', 'f4')
            time.sleep(3)

            # ---------------------------------------------------
            # STEP 3 : Launch Notepad
            # ---------------------------------------------------
            print("Launching Notepad...")
            pyautogui.press('winleft')
            time.sleep(1)
            pyautogui.write("Notepad")
            time.sleep(2)
            pyautogui.press('enter')
            time.sleep(3)

            # ---------------------------------------------------
            # STEP 4 : Relaunch HP
            # ---------------------------------------------------
            print("Relaunching HP application...")
            self.relaunch_hp()
            time.sleep(5)

            # ---------------------------------------------------
            # STEP 5 : Verify Global Apps Focus
            # ---------------------------------------------------
            global_apps_item = self.main_window.child_window(
                title="For all applications",
                control_type="ListItem"
            ).wait('exists enabled visible', timeout=10)

            is_focused = False

            try:
                if global_apps_item.has_keyboard_focus():
                    is_focused = True
            except:
                pass

            try:
                if global_apps_item.is_selected():
                    is_focused = True
            except:
                pass

            if is_focused:
                self._log_result(
                    "Global Apps Focus After Relaunch",
                    True,
                    "For all applications is focused after HP relaunch"
                )

                print("For all applications is focused in carousel")
                print("OVERALL TEST RESULT : PASS")
                print("-" * 60)
                return True
            else:
                self._log_result(
                    "C51570664 - Global Apps Focus After Relaunch",
                    False,
                    "For all applications not focused after HP relaunch"
                )

                print("OVERALL TEST RESULT : FAIL")
                print("-" * 60)
                return False

        except Exception as e:
            self._log_result(
                "C51570664 - Global Apps Focus After Relaunch",
                False,
                str(e)
            )

            print("OVERALL TEST RESULT : FAIL")
            print("-" * 60)
            return False




    
# ---------------- Verify application Select Unselect enables disables Continue button ----------------


    def TC_ID_C53033386_verify_aapplication_Select_Unselect(self):
        """
        TEST CASE : Verify Calculator toggle selection enables/disables Continue button
        """

        print("\nTEST CASE : Verify Calculator toggle selection enables/disables Continue button")
        print("-" * 60)

        try:
            # ---------------------------------------------------
            # STEP 1 : Click Add Application button
            # ---------------------------------------------------
            add_btn = self.main_window.child_window(
                title="Add Application",
                auto_id="ReactPCContextAware.Carousel.AddButton",
                control_type="Button"
            ).wait('exists enabled visible', timeout=10)

            add_btn.click_input()
            time.sleep(3)

            print("Add Application modal opened")

            # ---------------------------------------------------
            # STEP 2 : Locate Calculator + Continue button
            # ---------------------------------------------------
            calculator_btn = self.main_window.child_window(
                title="Calculator",
                control_type="Button"
            ).wait('exists enabled visible', timeout=10)

            continue_btn = self.main_window.child_window(
                title="Continue",
                control_type="Button"
            ).wait('exists visible', timeout=10)

            # ---------------------------------------------------
            # STEP 3 : VERIFY INITIAL UNSELECTED STATE
            # ---------------------------------------------------
            print("Verifying INITIAL UNSELECTED state...")

            if continue_btn.is_enabled():
                self._log_result(
                    "Calculator Initial State",
                    False,
                    "Continue button should be disabled initially"
                )
            else:
                self._log_result(
                    "Calculator Initial State",
                    True,
                    "Continue button not disabled initially"
                )

            # ---------------------------------------------------
            # STEP 4 : CLICK CALCULATOR → SELECTED
            # ---------------------------------------------------
            print("Clicking Calculator (SELECT)...")
            calculator_btn.click_input()
            time.sleep(3)

            if continue_btn.is_enabled():
                self._log_result(
                    "Calculator Selected State",
                    True,
                    "Continue button enabled after selecting Calculator"
                )
                print("Continue button ENABLED (Expected)")
                
            else:
                self._log_result(
                    "Calculator Selected State",
                    False,
                    "Continue button not enabled after selecting Calculator"
                )

            # ---------------------------------------------------
            # STEP 5 : CLICK AGAIN → UNSELECTED
            # ---------------------------------------------------
            print("Clicking Calculator again (UNSELECT)...")
            calculator_btn.click_input()
            time.sleep(3)

            if not continue_btn.is_enabled():
                self._log_result(
                    "Calculator Unselected State",
                    True,
                    "Continue button disabled after unselecting Calculator"
                )
                print("Continue button DISABLED (Expected)")
            else:
                self._log_result(
                    "Calculator Unselected State",
                    False,
                    "Continue button still enabled after unselecting Calculator"
                )

            # ---------------------------------------------------
            # STEP 6 : Click Cancel
            # ---------------------------------------------------
            cancel_btn = self.main_window.child_window(
                title="Cancel",
                control_type="Button"
            ).wait('exists enabled visible', timeout=10)

            cancel_btn.click_input()
            time.sleep(2)

            print("Cancel button clicked")

            print("OVERALL TEST RESULT : PASS")
            print("-" * 60)
            return True

        except Exception as e:
            self._log_result(
                "Calculator Toggle Validation",
                False,
                str(e)
            )

            print("OVERALL TEST RESULT : FAIL")
            print("-" * 60)
            return False




        # ----------------Re launch ------------------------------
    def relaunch_hp(self):
        """Reusable HP relaunch method"""
        try:
            if not self.open_hp_application():
                raise Exception("Open HP failed")

            if not self.connect_to_application():
                raise Exception("Connect failed")

            if not self.handle_startup_conditions():
                raise Exception("Startup failed")

            if not self.navigate_to_Audio():
                raise Exception("Navigation to Audio failed")

            self._log_result("HP Relaunch", True)
            return True

        except Exception as e:
            self._log_result("HP Relaunch", False, str(e))
            return False


        
     
    # ---------------------------------- Uninstall OOB apps and reset HPX APP ----------------------------------------


    def TC_ID_C53046320_Uninstall_OOB_apps_and_Reset_HPX_application(self):

        print("\nTEST CASE: Verify IMAX uninstall, tooltip error and HP reset")
        print("-" * 60)

        overall_result = True

        if not self.main_window:
            self._log_result("CA", False, "Application not connected")
            return False

        try:
            # =====================================================
            # TEST DATA
            # =====================================================
            oob_apps = [
                ("Disney+", "ReactPCContextAware.Carousel.CarouselItemA07DDB88965F20AE0E1C2E89F36F5B07"),
                ("爱奇艺", "ReactPCContextAware.Carousel.CarouselItem96D443B8FDA8B07AAB692A8F386CF8C0"),
                ("腾讯视频", "ReactPCContextAware.Carousel.CarouselItem41A61336B059C3F8CEB51A343050E228"),
            ]

            tooltip_text = "App not found. Try adding it again using the + to restore this profile."

            # =====================================================
            # STEP 1: UNINSTALL OOB APPS
            # =====================================================
            for app_name, _ in oob_apps:
                print(f"\nUninstalling {app_name}")

                pyautogui.press("winleft")
                time.sleep(1)

                pyperclip.copy(app_name)
                pyautogui.hotkey("ctrl", "v")
                time.sleep(2)

                try:
                    search_win = Desktop(backend="uia").window(title="Search")
                    search_win.wait("visible", timeout=10)

                    best_match = search_win.child_window(control_type="ListItem", found_index=0)
                    best_match.wait("visible", timeout=5)
                    best_match.click_input()

                    uninstall_item = search_win.child_window(
                        title="Uninstall",
                        control_type="ListItem"
                    )

                    if uninstall_item.exists(timeout=5):
                        uninstall_item.click_input()
                        self._log_result(app_name, True, "Clicked Uninstall")
                    else:
                        self._log_result(app_name, False, "Uninstall option not found")
                        overall_result = False
                        continue

                    # ✅ ONE TAB + ENTER
                    time.sleep(2)
                    pyautogui.press("tab")
                    time.sleep(1)
                    pyautogui.press("enter")

                    self._log_result(app_name, True, "Uninstall confirmed")

                    time.sleep(10)
                    pyautogui.hotkey("alt", "f4")

                except Exception as e:
                    self._log_result(app_name, False, f"Uninstall failed: {e}")
                    overall_result = False

            # =====================================================
            # STEP 2: CLOSE HP
            # =====================================================
            print("\nClosing HP before relaunch...")

            try:
                if self.main_window and self.main_window.exists(timeout=5):
                    self.main_window.set_focus()
                    self.main_window.close()
                    time.sleep(5)

                    if self.main_window.exists(timeout=3):
                        pyautogui.hotkey("alt", "f4")
                        time.sleep(5)

                self.main_window = None

            except Exception as e:
                self._log_debug(f"HP close failed: {e}")

            # =====================================================
            # STEP 3: RELAUNCH & VERIFY TOOLTIP
            # =====================================================
            print("\nRelaunching HP to verify tooltips...")

            if not self.relaunch_hp():
                overall_result = False

            for app_name, auto_id in oob_apps:
                try:
                    print(f"Checking tooltip for {app_name}")

                    carousel_item = self.main_window.child_window(
                        auto_id=auto_id,
                        control_type="ListItem"
                    )

                    if not carousel_item.exists(timeout=5):
                        self._log_result(app_name, True, "App not present (expected)")
                        continue

                    # ✅ CLICK (not focus)
                    carousel_item.click_input()
                    time.sleep(1.5)

                    # Try inside main window
                    tooltip = self.main_window.child_window(
                        title=tooltip_text,
                        control_type="ToolTip"
                    )

                    if not tooltip.exists(timeout=2):
                        # Fallback
                        tooltip = Desktop(backend="uia").window(
                            title=tooltip_text,
                            control_type="ToolTip"
                        )

                    if tooltip.exists(timeout=5):
                        self._log_result(f"{app_name} Tooltip", True)
                    else:
                        self._log_result(f"{app_name} Tooltip", False, "Tooltip missing")
                        overall_result = False

                except Exception as e:
                    self._log_debug(f"{app_name} check failed: {e}")
                    overall_result = False

            # =====================================================
            # STEP 4: RESET HP APPLICATION
            # =====================================================
            print("\nResetting HP Application...")

            pyautogui.press("winleft")
            time.sleep(1)

            pyperclip.copy("HP")
            pyautogui.hotkey("ctrl", "v")
            time.sleep(3)

            search_win = Desktop(backend="uia").window(title="Search")
            search_win.wait("visible", timeout=10)

            best_match = search_win.child_window(control_type="ListItem", found_index=0)
            best_match.wait("visible", timeout=5)
            best_match.click_input()

            #  App Settings (fixed)
            app_settings = search_win.child_window(
                title="App settings",
                control_type="ListItem"
            )

            if app_settings.exists(timeout=5):
                app_settings.click_input()
                self._log_result("HP Settings", True)
            else:
                self._log_result("HP Settings", False)
                return False

            time.sleep(10)

            settings_win = Desktop(backend="uia").window(title="Settings")
            settings_win.wait("visible", timeout=20)
            settings_win.set_focus()

            pyautogui.press("PGDN")
            pyautogui.press("PGDN")
            pyautogui.press("up")
            time.sleep(2)

            reset_btn = settings_win.child_window(title="Reset", control_type="Button")
            reset_btn.wait("enabled", timeout=20)
            reset_btn.click_input()

            time.sleep(2)

            pyautogui.press("tab")
            pyautogui.press("enter")
            pyautogui.press("enter")

            self._log_result("HP Reset", True)
            time.sleep(80)

            pyautogui.hotkey("alt", "f4")
            time.sleep(3)

            # =====================================================
            # STEP 5: RELAUNCH & VERIFY APPS NOT PRESENT
            # =====================================================
            print("\nRelaunching HP after reset...")

            self.relaunch_hp()
            time.sleep(6)

            print("\nVerifying IMAX OOB apps are NOT present after reset...")

            found_oob_apps = []

            all_items = self.main_window.descendants(control_type="ListItem")

            for item in all_items:
                try:
                    auto_id = item.element_info.automation_id or ""

                    for app_name, imax_auto_id in oob_apps:
                        if imax_auto_id in auto_id:
                            found_oob_apps.append(app_name)
                except:
                    pass

            if len(found_oob_apps) == 0:
                self._log_result("HP Reset Validation", True)
                print("\nOverall Test results  : PASS")
                print("-" * 60)
                return True
            else:
                self._log_result("HP Reset Validation", False, f"{found_oob_apps}")
                print("\nOverall Test results  : FAIL")
                print("-" * 60)
                return False

        except Exception as e:
            self._log_result("IMAX Flow", False, str(e))
            print("\nOverall Test results  : FAIL")
            print("-" * 60)
            return False





    # ---------------- Delete profile with 'Do not show again' and verify deletion from carousel ----------------
    
    def TC_ID_C53045345_Delete_app_without_delete_profile_page(self):

        print("\nTEST CASE: Add Admin Tool and Delete From Carousel")
        print("-" * 60)

        if not self.main_window:
            self._log_result("Test Setup", False, "Application not connected")
            return False

        try:
            import time

            ADD_BUTTON_AUTO_ID = "ReactPCContextAware.Carousel.AddButton"
            ADMIN_TOOLS_MODAL_ID = "ReactPCContextAware.InstalledAppsModal.AppItem2328013EC67257A5EFF59B60098FEB2B"
            ADMIN_TOOLS_CAROUSEL_ID = "ReactPCContextAware.Carousel.CarouselItem2328013EC67257A5EFF59B60098FEB2B"

            # ---------------------------------------------------------
            # STEP 1 → CLICK ADD
            # ---------------------------------------------------------
            add_btn = self.main_window.child_window(
                auto_id=ADD_BUTTON_AUTO_ID,
                control_type="Button"
            )

            if not add_btn.exists(timeout=5):
                self._log_result("Add Button", False, "Add button not found")
                return False

            add_btn.click_input()
            time.sleep(1)
            self._log_result("Add Button", True, "Add clicked")

            # ---------------------------------------------------------
            # STEP 2 → SELECT ADMINISTRATIVE TOOLS
            # ---------------------------------------------------------
            admin_btn = self.main_window.child_window(
                auto_id=ADMIN_TOOLS_MODAL_ID,
                control_type="Button"
            )

            if not admin_btn.exists(timeout=5):
                self._log_result("Select Admin", False, "Administrative Tools not found")
                return False

            admin_btn.click_input()
            time.sleep(1)
            self._log_result("Select Admin", True, "Administrative Tools selected")

            # ---------------------------------------------------------
            # STEP 3 → CLICK CONTINUE
            # ---------------------------------------------------------
            continue_btn = self.main_window.child_window(
                title="Continue",
                control_type="Button"
            )

            if not continue_btn.exists(timeout=5) or not continue_btn.is_enabled():
                self._log_result("Continue", False, "Continue not enabled")
                return False

            continue_btn.click_input()
            time.sleep(2)
            self._log_result("Continue", True, "Continue clicked")

            # ---------------------------------------------------------
            # STEP 4 → WAIT & VERIFY ADMIN TOOL ADDED TO CAROUSEL
            # ---------------------------------------------------------
            time.sleep(2)

            carousel_item = self.main_window.child_window(
                auto_id=ADMIN_TOOLS_CAROUSEL_ID,
                control_type="ListItem"
            )

            if not carousel_item.exists(timeout=5):
                self._log_result("Carousel Add Verification", False,
                                "Administrative Tools not added to carousel")
                return False

            self._log_result("Carousel Add Verification", True,
                            "Administrative Tools added to carousel")

            # ---------------------------------------------------------
            # STEP 5 → CLICK ADMIN TOOL IN CAROUSEL
            # ---------------------------------------------------------
            carousel_item.click_input()
            time.sleep(1)
            self._log_result("Carousel Click", True, "Admin tool clicked")

            # ---------------------------------------------------------
            # STEP 6 → CLICK DELETE PROFILE
            # ---------------------------------------------------------
            delete_btn = self.main_window.child_window(
                auto_id="ReactPCContextAware.Carousel.DeleteProfileButton",
                title="Delete profile",
                control_type="Button"
            )

            if not delete_btn.exists(timeout=5):
                self._log_result("Delete Button", False, "Delete button not found")
                return False

            delete_btn.click_input()
            time.sleep(2)
            self._log_result("Delete Button", True, "Delete clicked")

            # ---------------------------------------------------------
            # STEP 7 → VERIFY ADMIN TOOL REMOVED FROM CAROUSEL
            # ---------------------------------------------------------
            time.sleep(2)

            if carousel_item.exists(timeout=3):
                self._log_result("Carousel Deletion Verification", False,
                                "Administrative Tools still present in carousel")
                print("\nOverall Test results  : FAIL")
                print("-" * 60)
                return False

            self._log_result("Carousel Deletion Verification", True,
                            "Administrative Tools successfully removed from carousel")

            print("\nOverall Test results  : PASS")
            print("-" * 60)
            return True

        except Exception as e:
            self._log_result("Test Exception", False, str(e))
            print("\nOverall Test results  : FAIL")
            print("-" * 60)
            return False




#----------------- Verify Netflix uninstall shows warning icon in carousel ----------------

    def TC_ID_C51570647_netflix_uninstal_Apperror_Icon_validation(self):

        """TC: Add Netflix (if not present), Uninstall and validate warning icon"""

        # ---------- Print Test Case Header ----------
        print("\nTEST CASE: Netflix Uninstall Warning Validation")
        print("-" * 60)

        if not self.main_window:
            self._log_result("Netflix Validation", False, "Application not connected")
            print("Test case 'Netflix Validation' completed : FAIL")
            print("-" * 60)
            return False

        app_name = "Netflix"
        tooltip_text = "App not found. Try adding it again using the + to restore this profile."

        try:
            self.main_window.set_focus()
            time.sleep(5)

            netflix_item = self.main_window.child_window(
                title="Netflix",
                control_type="ListItem"
            )

            # ==================================================
            # STEP 0: ADD NETFLIX USING SEARCH (IF NOT PRESENT)
            # ==================================================
            if not netflix_item.exists(timeout=5):

                print("Netflix not in carousel → Adding via Search")

                # ---------- CLICK ADD APPLICATION ----------
                add_btn = self.main_window.child_window(
                    title="Add Application",
                    auto_id="ReactPCContextAware.Carousel.AddButton",
                    control_type="Button"
                )

                if not add_btn.exists(timeout=10):
                    self._log_result("Add Application", False, "Add button not found")
                    return False

                add_btn.click_input()
                time.sleep(2)

                # ---------- SEARCH NETFLIX ----------
                search_box = self.main_window.child_window(
                    auto_id="ReactPCContextAware.InstalledAppsModal.SearchApplication__text-box",
                    control_type="Edit"
                )

                if not search_box.exists(timeout=10):
                    self._log_result("Search App", False, "Search box not found")
                    return False

                search_box.click_input()
                time.sleep(0.5)
                search_box.type_keys("^a{BACKSPACE}")
                search_box.type_keys("Netflix", with_spaces=True)
                time.sleep(2)

                self._log_result("Search App", True, "Searched for Netflix")

                # ---------- SELECT NETFLIX ----------
                app_btn = self.main_window.child_window(
                    title="Netflix",
                    control_type="Button"
                )

                if not app_btn.exists(timeout=10):
                    self._log_result("Select App", False, "Netflix not found in search result")
                    return False

                app_btn.click_input()
                time.sleep(1)

                # ---------- CLICK CONTINUE ----------
                continue_btn = self.main_window.child_window(
                    title="Continue",
                    auto_id="ReactPCContextAware.InstalledAppsModal.ContinueButton",
                    control_type="Button"
                )

                if continue_btn.exists(timeout=5) and continue_btn.is_enabled():
                    continue_btn.click_input()
                    time.sleep(5)
                    self._log_result("Add Netflix", True, "Netflix added to carousel")
                else:
                    self._log_result("Continue", False, "Continue button not enabled")
                    return False

            # ==================================================
            # STEP 1: CHECK INSTALL STATUS
            # ==================================================
            netflix_item = self.main_window.child_window(
                title="Netflix",
                control_type="ListItem"
            )

            netflix_item.click_input()
            time.sleep(2)

            tooltip = self.main_window.child_window(
                title=tooltip_text,
                control_type="ToolTip"
            )

            # ==================================================
            # STEP 2: IF INSTALLED → UNINSTALL
            # ==================================================
            if not tooltip.exists(timeout=2):

                print("Netflix installed → Proceeding with uninstall")

                try:
                    self.main_window.close()
                    time.sleep(3)
                except Exception:
                    pyautogui.hotkey("alt", "f4")
                    time.sleep(2)

                pyautogui.press("winleft")
                time.sleep(1)
                pyautogui.write(app_name)
                time.sleep(3)

                search_win = Desktop(backend="uia").window(title_re=".*Search.*")
                search_win.wait("visible", timeout=10)

                uninstall_item = search_win.child_window(
                    title="Uninstall",
                    control_type="ListItem"
                )
                uninstall_item.wait("enabled", timeout=10)
                uninstall_item.invoke()
                time.sleep(3)

                pyautogui.press("tab")
                time.sleep(1)
                pyautogui.press("enter")
                time.sleep(10)

                self._log_result("Uninstall Netflix", True, "Uninstall completed")

            # ==================================================
            # STEP 3: RELAUNCH HP
            # ==================================================
                print("Relaunching HP application...")
                self.relaunch_hp()
                time.sleep(3)

            # ==================================================
            # STEP 4: VALIDATE WARNING ICON
            # ==================================================
            self.main_window.set_focus()
            time.sleep(5)

            netflix_item = self.main_window.child_window(
                title="Netflix",
                control_type="ListItem"
            )

            netflix_item.click_input()
            time.sleep(2)

            tooltip = self.main_window.child_window(
                title=tooltip_text,
                control_type="ToolTip"
            )

            if tooltip.exists(timeout=3):
                self._log_result("Warning Icon Validation", True, "Warning icon present as expected")
                print("\nOverall test results : PASS")
                print("-" * 60)
                return True
            else:
                self._log_result("Warning Icon Validation", False, "Warning icon NOT present")
                print("\nOverall test results : FAIL")
                print("-" * 60)
                return False

        except Exception as e:
            self._log_result("Netflix Validation", False, str(e))
            print("\nOverall test results : FAIL")
            print("-" * 60)
            return False


#----------------- Verify Netflix uninstall shows tooltip in carousel and validates tooltip message ----------------


    def TC_ID_C51570648_netflix_uninstalled_Apperror_message_validation(self):
                
                """TC2: Click Netflix and verify the tooltip message only"""

                # ---------- Print Test Case Header ----------
                print("\nTEST CASE 2: Netflix Uninstalled Tooltip Validation")
                print("-" * 60)

                tooltip_text = "App not found. Try adding it again using the + to restore this profile."

                try:
                    # 🔹 If main_window is None, try reconnect instead of relaunch
                    if not self.main_window:
                        if not self.connect_to_application():
                            self._log_result("Reconnect HP", False, "Unable to connect to existing HP session")
                            print("\nOverall test results : FAIL")
                            print("-" * 60)
                            return False

                    self.main_window.set_focus()
                    time.sleep(3)

                    # ---------- Step 1: Locate Netflix ----------
                    netflix_item = self.main_window.child_window(
                        title="Netflix",
                        control_type="ListItem"
                    )

                    if not netflix_item.exists(timeout=5):
                        self._log_result("Locate Netflix", False, "Netflix not found in carousel")
                        print("\nOverall test results : FAIL")
                        print("-" * 60)
                        return False

                    # ---------- Step 2: Click Netflix ----------
                    netflix_item.click_input()
                    time.sleep(2)

                    # ---------- Step 3: Validate Tooltip ----------
                    tooltip = self.main_window.child_window(
                        title=tooltip_text,
                        control_type="ToolTip"
                    )

                    if tooltip.exists(timeout=3):

                        # Optional: verify exact text
                        actual_text = tooltip.window_text()

                        if actual_text == tooltip_text:
                            self._log_result(
                                "Tooltip Validation",
                                True,
                                "Correct tooltip message displayed → App is uninstalled"
                            )
                            print("\nOverall test results : PASS")
                            print("-" * 60)
                            return True
                        else:
                            self._log_result(
                                "Tooltip Validation",
                                False,
                                f"Tooltip text mismatch: {actual_text}"
                            )
                    else:
                        self._log_result(
                            "Tooltip Validation",
                            False,
                            "Tooltip not displayed"
                        )

                    print("\nOverall test results : FAIL")
                    print("-" * 60)
                    return False

                except Exception as e:
                    self._log_result("Netflix Tooltip Validation", False, str(e))
                    print("\nOverall test results : FAIL")
                    print("-" * 60)
                    return False





# verify Netflix uninstall shows tooltip in carousel, then install Netflix from MS Store and verify tooltip goes away



        # ---------------- Install Netflix from Microsoft Store --------------


    def install_netflix_from_ms_store(self):
        """
        End-to-end Microsoft Store Netflix installation automation
        """

        try:

            print("\n--------------------------------------------------")
            print("STEP: install_netflix_from_ms_store")
            print("--------------------------------------------------")

            # ---------------------------------------------------
            # OPEN MICROSOFT STORE
            # ---------------------------------------------------
            print("Launching Microsoft Store...")

            pyautogui.press("winleft")

            time.sleep(2)

            pyautogui.write(
                "Microsoft Store",
                interval=0.1
            )

            time.sleep(3)

            pyautogui.press("enter")

            time.sleep(10)

            # ---------------------------------------------------
            # CONNECT MICROSOFT STORE WINDOW
            # ---------------------------------------------------
            desktop = Desktop(backend="uia")

            store_win = None

            for _ in range(30):

                windows = desktop.windows()

                for win in windows:

                    try:

                        title = win.window_text()

                        if "Microsoft Store" in title:

                            if win.is_visible():

                                store_win = win
                                break

                    except Exception:
                        pass

                if store_win:
                    break

                time.sleep(1)

            if store_win is None:
                raise Exception("Microsoft Store window not found")

            store_win.set_focus()

            time.sleep(5)

            print("Microsoft Store opened")

            # ---------------------------------------------------
            # OPEN SEARCH
            # ---------------------------------------------------
            print("Opening Microsoft Store search...")

            pyautogui.hotkey("ctrl", "e")

            time.sleep(3)

            # ---------------------------------------------------
            # TYPE NETFLIX
            # ---------------------------------------------------
            pyautogui.write(
                "Netflix",
                interval=0.1
            )

            print("Typed Netflix")

            time.sleep(2)

            pyautogui.press("enter")

            print("Searching Netflix...")

            time.sleep(10)

            # ---------------------------------------------------
            # CLICK NETFLIX APP USING UIA
            # ---------------------------------------------------
            print("Finding Netflix app tile...")

            netflix_card = None

            controls = store_win.descendants()

            for ctrl in controls:

                try:

                    text = ctrl.window_text()

                    control_type = ctrl.element_info.control_type

                    # Match Netflix card/button
                    if (
                        text
                        and "Netflix" in text
                        and control_type == "Button"
                    ):

                        netflix_card = ctrl
                        break

                except Exception:
                    pass

            if netflix_card is None:

                self._log_result(
                    "Install Netflix",
                    False,
                    "Netflix card not found"
                )

                return False

            # Focus + Click
            netflix_card.set_focus()

            time.sleep(1)

            netflix_card.click_input()

            print("Clicked Netflix app card")

            time.sleep(8)

            # ---------------------------------------------------
            # CLICK INSTALL BUTTON
            # ---------------------------------------------------
            print("Finding Install button...")

            install_clicked = False

            for _ in range(20):

                controls = store_win.descendants()

                for ctrl in controls:

                    try:

                        text = ctrl.window_text()

                        if text:

                            if (
                                text.strip() == "Install"
                                or text.strip() == "Get"
                                or text.strip() == "Free"
                            ):

                                try:

                                    ctrl.click_input()

                                    print(f"Clicked: {text}")

                                    install_clicked = True
                                    break

                                except Exception:
                                    pass

                    except Exception:
                        pass

                if install_clicked:
                    break

                time.sleep(2)

            if not install_clicked:

                self._log_result(
                    "Install Netflix",
                    False,
                    "Install button not found"
                )

                return False

            # ---------------------------------------------------
            # WAIT FOR INSTALL COMPLETE
            # ---------------------------------------------------
            print("Waiting for installation...")

            install_completed = False

            for _ in range(60):

                controls = store_win.descendants()

                for ctrl in controls:

                    try:

                        text = ctrl.window_text()

                        if text:

                            if (
                                text.strip() == "Open"
                                or text.strip() == "Launch"
                                or text.strip() == "Play"
                            ):

                                install_completed = True
                                break

                    except Exception:
                        pass

                if install_completed:
                    break

                time.sleep(5)

            if install_completed:

                self._log_result(
                    "Install Netflix",
                    True,
                    "Netflix installed successfully"
                )

                print("Netflix installed successfully")

                return True

            else:

                self._log_result(
                    "Install Netflix",
                    False,
                    "Open button not detected"
                )

                return False

        except Exception as e:

            self._log_result(
                "Install Netflix",
                False,
                str(e)
            )

            print(f"ERROR: {e}")

            return False



#     ---------------- Full end-to-end Netflix uninstall/install validation and tool tip verification ----------------

    def TC_ID_C51570649_netflix_app_error_resolve(self):

        """
        FULL END-TO-END FLOW
        """

        overall_result = True
        app_name = "Netflix"

        tooltip_text = (
            "App not found. Try adding it again using the + to restore this profile."
        )

        uninstall_required = False

        # --------------------------------------------------
        # HELPER: FORCE CLOSE HP
        # --------------------------------------------------
        def close_hp():
            try:
                if self.main_window:
                    self.main_window.close()
                    time.sleep(3)
            except Exception:
                try:
                    pyautogui.hotkey("alt", "f4")
                    time.sleep(2)
                except Exception:
                    pass

        # --------------------------------------------------
        # STEP 1: PRE-CHECK
        # --------------------------------------------------
        try:
            if self.main_window:
                self.main_window.set_focus()
                time.sleep(2)

                netflix_item = self.main_window.child_window(
                    title="Netflix",
                    control_type="ListItem"
                )

                if not netflix_item.exists(timeout=5):
                    self._log_result("Netflix Pre-check", True,
                                    "Netflix not in carousel → treated as UNINSTALLED")
                else:
                    netflix_item.click_input()
                    time.sleep(1.5)

                    tooltip = self.main_window.child_window(
                        title=tooltip_text,
                        control_type="ToolTip"
                    )

                    if tooltip.exists(timeout=2):
                        self._log_result("Netflix Pre-check", True,
                                        "Tooltip present → already UNINSTALLED")
                    else:
                        uninstall_required = True

        except Exception as e:
            self._log_result("Netflix Pre-check", False, str(e))
            overall_result = False

        # --------------------------------------------------
        # STEP 2: UNINSTALL
        # --------------------------------------------------
        if uninstall_required:
            try:
                close_hp()

                pyautogui.press("winleft")
                time.sleep(1)
                pyautogui.write(app_name)
                time.sleep(3)

                search_win = Desktop(backend="uia").window(title_re=".*Search.*")
                search_win.wait("visible", timeout=10)

                uninstall_item = search_win.child_window(
                    title="Uninstall",
                    control_type="ListItem"
                )
                uninstall_item.wait("enabled", timeout=10)
                uninstall_item.invoke()
                time.sleep(1)
                pyautogui.press("tab")
                pyautogui.press("enter")

                time.sleep(10)

                self._log_result("Uninstall Netflix", True, "Uninstall executed")

            except Exception as e:
                self._log_result("Uninstall Netflix", False, str(e))
                overall_result = False

        # --------------------------------------------------
        # STEP 3: RELAUNCH → TOOLTIP MUST EXIST
        # --------------------------------------------------
        try:
    
            close_hp()
            
            print("Relaunching HP application...")
            self.relaunch_hp()
            time.sleep(2)

            self.main_window.set_focus()
            time.sleep(2)

            netflix_item = self.main_window.child_window(
                title="Netflix",   # fixed (removed carousel-item-)
                control_type="ListItem"
            )

            if netflix_item.exists(timeout=5):
                netflix_item.click_input()
                time.sleep(1.5)

                tooltip = self.main_window.child_window(
                    title=tooltip_text,
                    control_type="ToolTip"
                )

                if tooltip.exists(timeout=2):
                    self._log_result("Post-Uninstall Tooltip Check", True,
                                    "Tooltip present as expected")
                else:
                    self._log_result("Post-Uninstall Tooltip Check", False,
                                    "Tooltip NOT found (unexpected)")
                    overall_result = False
            else:
                self._log_result("Post-Uninstall Carousel Check", False,
                                "Netflix not found in carousel")
                overall_result = False

        except Exception as e:
            self._log_result("Post-Uninstall Validation", False, str(e))
            overall_result = False

        # --------------------------------------------------
        # STEP 4: INSTALL NETFLIX
        # --------------------------------------------------
        try:
            

            install_success = self.install_netflix_from_ms_store()

            if not install_success:
                self._log_result("Install Netflix", False, "Installation failed")
                overall_result = False

        except Exception as e:
            self._log_result("Install Netflix", False, str(e))
            overall_result = False

        # --------------------------------------------------
        # STEP 5: RELAUNCH → TOOLTIP MUST NOT EXIST
        # --------------------------------------------------
        try:
            close_hp()

            print("Relaunching HP application...")
            self.relaunch_hp()
            time.sleep(2)

            self.main_window.set_focus()
            time.sleep(2)

            netflix_item = self.main_window.child_window(
                title="Netflix",
                control_type="ListItem"
            )

            if not netflix_item.exists(timeout=5):
                self._log_result("Post-Install Carousel Check", False,
                                "Netflix not found in carousel")
                overall_result = False
            else:
                netflix_item.click_input()
                time.sleep(1.5)

                tooltip = self.main_window.child_window(
                    title=tooltip_text,
                    control_type="ToolTip"
                )

                if tooltip.exists(timeout=2):
                    self._log_result("Post-Install Tooltip Check", False,
                                    "Tooltip present after install (unexpected)")
                    overall_result = False
                else:
                    self._log_result("Post-Install Tooltip Check", True,
                                    "Tooltip not present as expected")

        except Exception as e:
            self._log_result("Post-Install Validation", False, str(e))
            overall_result = False

        # --------------------------------------------------
        # FINAL
        # --------------------------------------------------
        if not overall_result:
            raise AssertionError("TC_ID_C51570649_netflix_app_error_resolve FAILED")

        return True 


#--------------------------------------------launnch multiple apps----------------------------------------------

    def TC_ID_C51570662_launch_multiple_apps(self):

        print("\nTEST CASE: Calculator & Netflix Carousel Focus Validation")
        print("-" * 60)

        if not self.main_window:
            self._log_result("Carousel Validation", False, "Application not connected")
            return False

        test_passed = True

        try:

            self.main_window.set_focus()
            time.sleep(3)

            # -------------------------------------------------
            # ADD APP
            # -------------------------------------------------
            def add_app(app_name):

                add_btn = self.main_window.child_window(
                    title="Add Application",
                    auto_id="ReactPCContextAware.Carousel.AddButton",
                    control_type="Button"
                )

                add_btn.click_input()
                time.sleep(1)

                search_box = self.main_window.child_window(
                    auto_id="ReactPCContextAware.InstalledAppsModal.SearchApplication__text-box",
                    control_type="Edit"
                )

                search_box.click_input()
                search_box.type_keys("^a{BACKSPACE}")
                search_box.type_keys(app_name, with_spaces=True)
                time.sleep(2)

                app_btn = self.main_window.child_window(
                    title=app_name,
                    control_type="Button"
                )

                if not app_btn.exists(timeout=10):
                    self._log_result("Add App", False, f"{app_name} not found")
                    return False

                app_btn.click_input()
                time.sleep(1)

                continue_btn = self.main_window.child_window(
                    title="Continue",
                    auto_id="ReactPCContextAware.InstalledAppsModal.ContinueButton",
                    control_type="Button"
                )

                continue_btn.click_input()
                time.sleep(3)

                self._log_result("Add App", True, f"{app_name} added to carousel")
                return True

            # -------------------------------------------------
            # LAUNCH APP
            # -------------------------------------------------
            def launch_app(app_name):

                pyautogui.press("win")
                time.sleep(1)

                pyautogui.write(app_name)
                time.sleep(2)

                pyautogui.press("enter")

                self._log_result("Launch App", True, f"{app_name} launched from Windows")
                time.sleep(5)

            # -------------------------------------------------
            # HANDLE NETFLIX WINDOW
            # -------------------------------------------------
            def handle_netflix_window():

                try:
                    windows = Desktop(backend="uia").windows(
                        title_re=".*Netflix.*",
                        top_level_only=True
                    )

                    if not windows:
                        raise Exception("Netflix window not found")

                    print(f"DEBUG: Found {len(windows)} Netflix windows")

                    netflix_window = windows[0]

                    for win in windows:
                        try:
                            if win.is_visible():
                                netflix_window = win
                                break
                        except:
                            pass

                    netflix_window.restore()
                    time.sleep(1)

                    netflix_window.set_focus()
                    time.sleep(2)

                    self._log_result("Netflix Resize", True)
                    return True

                except Exception as e:
                    self._log_result("Netflix Resize", False, str(e))
                    return False

            # -------------------------------------------------
            # VERIFY CAROUSEL FOCUS
            # -------------------------------------------------
            def verify_focus(control, step_name):

                for _ in range(5):
                    try:
                        if control.is_selected():
                            self._log_result(step_name, True)
                            return True
                    except:
                        pass

                    time.sleep(1)

                self._log_result(step_name, False)
                return False

            # -------------------------------------------------
            # ADD APPS
            # -------------------------------------------------
            if not add_app("Calculator"):
                return False

            if not add_app("Netflix"):
                return False

            calc_item = self.main_window.child_window(
                title="Calculator",
                control_type="ListItem"
            )

            netflix_item = self.main_window.child_window(
                title="Netflix",
                control_type="ListItem"
            )

            # -------------------------------------------------
            # CALCULATOR 1
            # -------------------------------------------------
            launch_app("Calculator")

            if not verify_focus(calc_item, "Calculator Focus 1"):
                test_passed = False

            # -------------------------------------------------
            # NETFLIX 1
            # -------------------------------------------------
            launch_app("Netflix")

            if not handle_netflix_window():
                test_passed = False

            if not verify_focus(netflix_item, "Netflix Focus 1"):
                test_passed = False

            # -------------------------------------------------
            # CALCULATOR 2
            # -------------------------------------------------
            launch_app("Calculator")

            if not verify_focus(calc_item, "Calculator Focus 2"):
                test_passed = False

            # -------------------------------------------------
            # NETFLIX 2
            # -------------------------------------------------
            launch_app("Netflix")

            if not handle_netflix_window():
                test_passed = False

            if not verify_focus(netflix_item, "Netflix Focus 2"):
                test_passed = False

            # -------------------------------------------------
            # FINAL RESULT
            # -------------------------------------------------
            if test_passed:
                print("\nOverall Test results : PASS")
                print("-" * 60)
                return True
            else:
                print("\nOverall Test results : FAIL")
                print("-" * 60)
                return False

        except Exception as e:
            self._log_result("Carousel Validation", False, str(e))
            print("\nOverall Test results : FAIL")
            print("-" * 60)
            return False




    #--------------------------Application close and launch-----------------------

    def TC_ID_C51570663_Application_Setting_Close_launch(self):

        """Verify Calculator highlight persists in carousel after relaunch"""

        overall_result = True
        app_name = "Calculator"

        # --------------------------------------------------
        # STEP 1: Add Calculator to carousel
        # --------------------------------------------------
        try:

            calc_item = self.main_window.child_window(
                title="Calculator",
                control_type="ListItem"
            )

            if calc_item.exists(timeout=5):
                self._log_result("Add Calculator", True, "Calculator already present")

            else:

                add_btn = self.main_window.child_window(
                    title="Add Application",
                    auto_id="ReactPCContextAware.Carousel.AddButton",
                    control_type="Button"
                )

                add_btn.click_input()
                time.sleep(1)

                search_box = self.main_window.child_window(
                    auto_id="ReactPCContextAware.InstalledAppsModal.SearchApplication__text-box",
                    control_type="Edit"
                )

                search_box.click_input()
                search_box.type_keys("^a{BACKSPACE}")
                search_box.type_keys(app_name, with_spaces=True)
                time.sleep(2)

                app_btn = self.main_window.child_window(
                    title=app_name,
                    control_type="Button"
                )

                if not app_btn.exists(timeout=10):
                    self._log_result("Add Calculator", False, "Calculator not found")
                    overall_result = False
                else:
                    app_btn.click_input()
                    time.sleep(1)

                    continue_btn = self.main_window.child_window(
                        title="Continue",
                        auto_id="ReactPCContextAware.InstalledAppsModal.ContinueButton",
                        control_type="Button"
                    )

                    continue_btn.click_input()
                    time.sleep(3)

                    self._log_result("Add Calculator", True)

        except Exception as e:
            self._log_result("Add Calculator", False, str(e))
            overall_result = False


        # --------------------------------------------------
        # STEP 2: Launch Calculator
        # --------------------------------------------------
        try:
            pyautogui.press("winleft")
            time.sleep(1)

            pyautogui.write(app_name)
            time.sleep(2)

            pyautogui.press("enter")
            time.sleep(5)

            self._log_result("Launch Calculator", True)

        except Exception as e:
            self._log_result("Launch Calculator", False, str(e))
            overall_result = False


        # --------------------------------------------------
        # STEP 3: Verify Calculator highlighted
        # --------------------------------------------------
        try:
            self.main_window.set_focus()
            time.sleep(2)

            calc_item = self.main_window.child_window(
                title="Calculator",
                control_type="ListItem"
            )

            if calc_item.exists(timeout=5) and calc_item.is_selected():
                self._log_result("Calculator highlight check", True)
            else:
                self._log_result("Calculator highlight check", False, "Calculator not highlighted")
                overall_result = False

        except Exception as e:
            self._log_result("Calculator highlight check", False, str(e))
            overall_result = False


        # --------------------------------------------------
        # STEP 4: Close HP
        # --------------------------------------------------
        try:
            self.main_window.close()
            time.sleep(3)
            self._log_result("Close HP", True)

        except Exception:
            pyautogui.hotkey("alt", "f4")
            time.sleep(3)
            self._log_result("Close HP", True)


        # --------------------------------------------------
        # STEP 5: Relaunch HP
        # --------------------------------------------------
        try:
            try:
                self.relaunch_hp()
                time.sleep(2)
                self._log_result("Open HP", True)
            except Exception as e:
                self._log_result("Open HP", False, str(e))
                overall_result = False

        except Exception as e:
            self._log_result("HP Relaunch Flow", False, str(e))
            overall_result = False


        # --------------------------------------------------
        # STEP 6: Verify Calculator still highlighted
        # --------------------------------------------------
        try:
            self.main_window.set_focus()
            time.sleep(2)

            calc_item = self.main_window.child_window(
                title="Calculator",
                control_type="ListItem"
            )

            if calc_item.exists(timeout=5) and calc_item.is_selected():
                self._log_result("Post-relaunch highlight check", True)
            else:
                self._log_result(
                    "Post-relaunch highlight check",
                    False,
                    "Calculator not highlighted after relaunch"
                )
                overall_result = False

        except Exception as e:
            self._log_result("Post-relaunch highlight check", False, str(e))
            overall_result = False


        # --------------------------------------------------
        # FINAL RESULT (UPDATED)
        # --------------------------------------------------
        if not calc_item.exists(timeout=5) or not calc_item.is_selected():
            self._log_result(
                "Final Result",
                False,
                "Calculator highlight verification FAILED"
            )
            return False

        self._log_result(
            "Final Result",
            True,
            "Calculator highlight verification PASSED"
        )

        return True






# ----------------application close and launch with different app that is not in appbar-----------------------------

    def TC_ID_C51570664_application_close_and_launch_with_different_app(self):
        

        print("\nTEST CASE: Verify 'For all applications' remains selected after launching Notepad and relaunching HP")
        print("-" * 60)

        overall_result = True
        app_name = "Notepad"

        # --------------------------------------------------
        # STEP 1: Close HP
        
        try:
                self.main_window.close()
                time.sleep(3)
                self._log_result("Close HP", True)

        except Exception as e:
                self._log_result("Close HP", False, str(e))
                overall_result = False


        # --------------------------------------------------
        # STEP 2: Launch Notepad
        # --------------------------------------------------
        try:
            pyautogui.press("winleft")
            time.sleep(1)

            pyautogui.write(app_name)
            time.sleep(2)

            pyautogui.press("enter")
            time.sleep(5)

            self._log_result("Launch Notepad", True)

        except Exception as e:
            self._log_result("Launch Notepad", False, str(e))
            overall_result = False


        # --------------------------------------------------
        # STEP 3: Relaunch HP (FIXED)
        # --------------------------------------------------
        try:
            if (
                self.relaunch_hp()
            ):
                self._log_result("HP Relaunch", True)
            else:
                self._log_result("HP Relaunch", False, "Failed to relaunch HP")
                overall_result = False

        except Exception as e:
            self._log_result("HP Relaunch", False, str(e))
            overall_result = False


        # --------------------------------------------------
        # STEP 4: Verify Global App (FIXED LOCATOR)
        # --------------------------------------------------
        try:
            self.main_window.set_focus()
            time.sleep(2)

            global_item = self.main_window.child_window(
                title="For all applications",
                control_type="ListItem"
            )

            if global_item.exists(timeout=5) and global_item.is_enabled():

                self._log_result("For all applications is selected/Focused", True)

            else:
                self._log_result(
                    "Global application selected",
                    False,
                    "Global application NOT selected"
                )
                overall_result = False

        except Exception as e:
            self._log_result("Global application selected", False, str(e))
            overall_result = False


        # --------------------------------------------------
        # FINAL
        # --------------------------------------------------
        print("-" * 60)

        return overall_result





            # ---------------- Delete Calculator and verify it is removed after relaunch ----------------

    def TC_ID_C51570665_Delete_App_and_verify_after_relunch(self):

        print("\nTEST CASE: Delete Calculator and verify it is removed after HP relaunch")
        print("-" * 60)

        overall_result = True

        try:

            # --------------------------------------------------
            # STEP 1: Click Calculator
            # --------------------------------------------------
            try:
                calc_item = self.main_window.child_window(
                    title="Calculator",
                    control_type="ListItem"
                )

                if calc_item.exists(timeout=5):
                    calc_item.click_input()
                    time.sleep(2)
                    self._log_result("Click Calculator", True)
                else:
                    self._log_result("Click Calculator", False, "Calculator not found in carousel")
                    overall_result = False

            except Exception as e:
                self._log_result("Click Calculator", False, str(e))
                overall_result = False


            # --------------------------------------------------
            # STEP 2: Click Delete Profile
            # --------------------------------------------------
            try:
                delete_btn = self.main_window.child_window(
                    title="Delete profile",
                    auto_id="ReactPCContextAware.Carousel.DeleteProfileButton",
                    control_type="Button"
                )

                if delete_btn.exists(timeout=5) and delete_btn.is_enabled():
                    delete_btn.click_input()
                    time.sleep(2)
                    self._log_result("Delete Profile", True)
                else:
                    self._log_result("Delete Profile", False, "Delete button not available")
                    overall_result = False

            except Exception as e:
                self._log_result("Delete Profile", False, str(e))
                overall_result = False


            # --------------------------------------------------
            # STEP 3: Click Continue (Optional Popup)
            # --------------------------------------------------
            try:
                continue_btn = self.main_window.child_window(
                    title="Continue",
                    auto_id="ReactPCContextAware.DeleteProfileModal.ContinueButton",
                    control_type="Button"
                )

                if continue_btn.exists(timeout=5):
                    continue_btn.click_input()
                    time.sleep(3)
                    self._log_result("Popup Continue", True, "Popup handled")
                else:
                    # Do NOT fail test — just log and continue
                    self._log_result("Popup Continue", True, "Popup not displayed, skipping")

            except Exception as e:
                # Even if error occurs, don't fail execution
                self._log_result("Popup Continue", True, f"Issue ignored: {str(e)}")


            # --------------------------------------------------
            # STEP 4: Close HP
            # --------------------------------------------------
            try:
                self.main_window.close()
                time.sleep(3)
                self._log_result("Close HP", True)

            except Exception as e:
                self._log_result("Close HP", False, str(e))
                overall_result = False


            # --------------------------------------------------
            # STEP 5: Relaunch HP (UPDATED)
            # --------------------------------------------------
            try:
                if not self.relaunch_hp():
                    overall_result = False

            except Exception as e:
                self._log_result("HP Relaunch", False, str(e))
                overall_result = False


            # --------------------------------------------------
            # STEP 6: Verify Calculator NOT in carousel
            # --------------------------------------------------
            try:
                calc_item = self.main_window.child_window(
                    title="Calculator",
                    control_type="ListItem"
                )

                if calc_item.exists(timeout=5):
                    self._log_result(
                        "Calculator Verification",
                        False,
                        "Calculator still appears in carousel"
                    )
                    overall_result = False
                else:
                    self._log_result(
                        "Calculator Verification",
                        True,
                        "Calculator successfully removed"
                    )

            except Exception as e:
                self._log_result("Calculator Verification", False, str(e))
                overall_result = False


            print("-" * 60)
            return overall_result


        except Exception as e:
            self._log_result("Delete Calculator Test", False, str(e))
            print("-" * 60)
            return False




#------Uninstall application and check in carosle after relaunch-----------------------------

    def TC_ID_C51570666_Application_Setting_Uninstall_Application(self):

        print("\nTEST CASE: Verify Netflix exists in carousel after uninstall and HP relaunch")
        print("-" * 60)

        overall_result = True
        app_name = "Netflix"

        try:

            # --------------------------------------------------
            # STEP 1: Check Netflix in Carousel
            # --------------------------------------------------
            try:
                netflix_item = self.main_window.child_window(
                    title="Netflix",
                    control_type="ListItem"
                )

                if netflix_item.exists(timeout=5):
                    self._log_result("Netflix Exists in Carousel", True)

                else:

                    self._log_result("Netflix Exists in Carousel", True, "Netflix not present, adding")

                    add_btn = self.main_window.child_window(
                        auto_id="ReactPCContextAware.Carousel.AddButton",
                        control_type="Button"
                    )

                    add_btn.wait("enabled", timeout=10)
                    add_btn.click_input()
                    time.sleep(1)

                    # ---------------- Search Netflix ----------------

                    search_box = self.main_window.child_window(
                        auto_id="ReactPCContextAware.InstalledAppsModal.SearchApplication__text-box",
                        control_type="Edit"
                    )

                    search_box.wait("visible", timeout=10)
                    search_box.click_input()
                    search_box.type_keys("^a{BACKSPACE}")
                    search_box.type_keys(app_name, with_spaces=True)
                    time.sleep(2)

                    # ---------------- Select Netflix ----------------

                    app_btn = self.main_window.child_window(
                        title=app_name,
                        control_type="Button"
                    )

                    if not app_btn.exists(timeout=5):
                        app_btn = self.main_window.child_window(
                            title=app_name,
                            control_type="ListItem"
                        )

                    if not app_btn.exists(timeout=10):
                        self._log_result("Add Netflix", False, "Netflix not found in search results")
                        return False

                    app_btn.wait("enabled", timeout=10)
                    app_btn.click_input()
                    time.sleep(1)

                    # ---------------- Continue ----------------

                    continue_btn = self.main_window.child_window(
                        title="Continue",
                        auto_id="ReactPCContextAware.InstalledAppsModal.ContinueButton",
                        control_type="Button"
                    )

                    continue_btn.wait("enabled", timeout=10)
                    continue_btn.click_input()
                    time.sleep(3)

                    self._log_result("Add Netflix", True)

            except Exception as e:
                self._log_result("Add Netflix", False, str(e))
                overall_result = False


            # --------------------------------------------------
            # STEP 2: Close HP
            # --------------------------------------------------
            try:
                self.main_window.close()
                time.sleep(3)
                self._log_result("Close HP", True)

            except Exception:
                pyautogui.hotkey("alt", "f4")
                time.sleep(2)
                self._log_result("Close HP", True)


            # --------------------------------------------------
            # STEP 3: Uninstall Netflix (Windows Search)
            # --------------------------------------------------
            try:

                pyautogui.press("winleft")
                time.sleep(1)

                pyautogui.write(app_name)
                time.sleep(3)

                search_win = Desktop(backend="uia").window(title_re=".*Search.*")
                search_win.wait("visible", timeout=10)

                uninstall_item = search_win.child_window(
                    title="Uninstall",
                    control_type="ListItem"
                )

                uninstall_item.wait("enabled", timeout=10)
                uninstall_item.invoke()
                time.sleep(3)

                pyautogui.press("tab")
                time.sleep(1)

                pyautogui.press("enter")
                time.sleep(10)

                self._log_result("Uninstall Netflix", True)

            except Exception as e:
                self._log_result("Uninstall Netflix", False, str(e))
                overall_result = False


            # --------------------------------------------------
            # STEP 4: Relaunch HP
            # --------------------------------------------------
            try:
                if (
                    self.relaunch_hp()
                ):
                    self._log_result("HP Relaunch", True)

                else:
                    self._log_result("HP Relaunch", False)
                    overall_result = False

            except Exception as e:
                self._log_result("HP Relaunch", False, str(e))
                overall_result = False


            # --------------------------------------------------
            # STEP 5: Verify Netflix exists in carousel
            # --------------------------------------------------
            try:

                netflix_item = self.main_window.child_window(
                    title="Netflix",
                    control_type="ListItem"
                )

                if netflix_item.exists(timeout=5):

                    self._log_result("Netflix Carousel Verification _>Netflix found in carosel", True)

                else:

                    self._log_result(
                        "Netflix exist in carosel",
                        False,
                        "Netflix not found in carousel after uninstall"
                    )

                    overall_result = False

            except Exception as e:
                self._log_result("Netflix Carousel Verification", False, str(e))
                overall_result = False


            print("-" * 60)
            return overall_result

        except Exception as e:
            self._log_result("Netflix Test", False, str(e))
            print("-" * 60)
            return False



# ---------------------------Appsetting default UI---------------------------------------------------

    def TC_ID_C51570671_Appsetting_default_UI(self):
        
        """Validate CA UI: presence, selection, apps, add button, visual"""

        import time
        import os
        from PIL import Image, ImageChops

        print("\nTEST CASE: Validate CA UI (Full Validation)")
        print("-" * 60)

        if not self.main_window:
            self._log_result("Validate CA UI", False, "Application not connected")
            return False

        try:
            self.main_window.set_focus()
            time.sleep(5)

            all_ok = True

            # =========================================================
            # 1. CA (All Apps)
            # =========================================================
            ca_item = self.main_window.child_window(
                title="For all applications",
                auto_id="ReactPCContextAware.Carousel.AllAppsButton",
                control_type="ListItem"
            )

            if ca_item.exists(timeout=5):
                self._log_result("CA Presence", True)
            else:
                self._log_result("CA Presence", False)
                return False

            # =========================================================
            # 2. CA Default Selected (BEST METHOD)
            # =========================================================
            if ca_item.exists(timeout=5) and ca_item.is_selected():
                self._log_result("CA Default Selected", True)
            else:
                self._log_result(
                    "CA Default Selected",
                    False,
                    "CA not selected by default"
                )
                all_ok = False

            # =========================================================
            # 3. IMAX Apps (Flexible Locator)
            # =========================================================
            imax_apps = [
                "Disney",
                "腾讯视频",
                "爱奇艺"
            ]

            for app in imax_apps:
                app_item = self.main_window.child_window(
                    title_re=f".*{app}.*",
                    control_type="ListItem"
                )

                if app_item.exists(timeout=5):
                    self._log_result(f"{app} Presence", True)
                else:
                    self._log_result(f"{app} Presence", False)
                    all_ok = False

            # =========================================================
            # 4. Add Button
            # =========================================================
            add_btn = self.main_window.child_window(
                auto_id="ReactPCContextAware.Carousel.AddButton",
                control_type="Button"
            )

            if add_btn.exists(timeout=5):
                self._log_result("Add Button Presence", True)
            else:
                self._log_result("Add Button Presence", False)
                all_ok = False

            # =========================================================
            # 5. Visual Validation (Improved + Stable)
            # =========================================================
            baseline_img = "baseline_ca_ui.png"
            current_img = "current_ca_ui.png"

            # Capture current UI
            self.main_window.capture_as_image().save(current_img)

            if not os.path.exists(baseline_img):
                # First run → create baseline
                self.main_window.capture_as_image().save(baseline_img)
                self._log_result("Baseline Image", True, "Baseline created (first run)")
            else:
                img1 = Image.open(baseline_img)
                img2 = Image.open(current_img)

                diff = ImageChops.difference(img1, img2)

                # FIXED (no deprecation)
                diff_pixels = sum(
                    diff.convert("L").point(bool).get_flattened_data()
                )

                # Increased tolerance for real UI stability
                if diff_pixels < 8000:
                    self._log_result("UI Visual Validation", True)
                else:
                    self._log_result(
                        "UI Visual Validation",
                        False,
                        f"UI changed (diff pixels: {diff_pixels})"
                    )
                    all_ok = False

            # =========================================================
            # FINAL RESULT
            # =========================================================
            if all_ok:
                print("\nOverall test results : PASS")
                print("-" * 60)
                return True
            else:
                print("\nOverall test results : FAIL")
                print("-" * 60)
                return True

        except Exception as e:
            self._log_result("Validate CA UI", False, str(e))
            print("\nOverall test results : FAIL")
            print("-" * 60)
            return False





#-------------------------------Add_Application_UI--------------------------------------------------------------

    def TC_ID_C51570672_Add_Application_UI(self):
    
        """Validate Add Application modal UI and button states + Cancel action"""


        print("\nTEST CASE: Validate Add Application Modal")
        print("-" * 60)

        if not self.main_window:
            self._log_result("Add Application Modal", False, "Application not connected")
            return False

        try:
            self.main_window.set_focus()
            time.sleep(3)

            all_ok = True

            # =========================================================
            # 1. Click Add Button
            # =========================================================
            add_btn = self.main_window.child_window(
                auto_id="ReactPCContextAware.Carousel.AddButton",
                control_type="Button"
            )

            if add_btn.exists(timeout=5):
                add_btn.click_input()
                self._log_result("Click Add Button", True)
                time.sleep(2)
            else:
                self._log_result("Click Add Button", False)
                return False

            # =========================================================
            # 2. Modal Open Check
            # =========================================================
            modal = self.main_window.child_window(
                title="Add Application",
                control_type="Text"
            )

            if modal.exists(timeout=5):
                self._log_result("Add Application Modal Opened", True)
            else:
                self._log_result("Add Application Modal Opened", False)
                return False

            # =========================================================
            # 3. Search Box
            # =========================================================
            search_box = self.main_window.child_window(
                title_re=".*Search.*"
            )

            if search_box.exists(timeout=5):
                self._log_result("Search Box Presence", True)
            else:
                self._log_result("Search Box Presence", False)
                all_ok = False

            # =========================================================
            # 4. Continue Button (DISABLED)
            # =========================================================
            continue_btn = self.main_window.child_window(
                title="Continue",
                auto_id="ReactPCContextAware.InstalledAppsModal.ContinueButton",
                control_type="Button"
            )

            if continue_btn.exists(timeout=5):
                if not continue_btn.is_enabled():
                    self._log_result("Continue Button Disabled", True)
                else:
                    self._log_result("Continue Button Disabled", False)
                    all_ok = False
            else:
                self._log_result("Continue Button Presence", False)
                all_ok = False

            # =========================================================
            # 5. Cancel Button (ENABLED)
            # =========================================================
            cancel_btn = self.main_window.child_window(
                title="Cancel",
                control_type="Button"
            )

            if cancel_btn.exists(timeout=5):
                if cancel_btn.is_enabled():
                    self._log_result("Cancel Button Enabled", True)
                else:
                    self._log_result("Cancel Button Enabled", False)
                    all_ok = False
            else:
                self._log_result("Cancel Button Presence", False)
                all_ok = False


            # =========================================================
            # 7. Scrollbar Presence  FINAL FIX (HANDLE WRAPPER)
            # =========================================================
            try:
                scrollbar_spec = self.main_window.child_window(
                    auto_id="clientos-ui-toolkit-scrollbar-9m5vteq__scrollbar",
                    control_type="Group"
                )

                if scrollbar_spec.exists(timeout=3):
                    self._log_result("Scrollbar Presence", True)

                else:
                    # fallback → find dynamically
                    scrollbar_wrapper = None
                    all_groups = self.main_window.descendants(control_type="Group")

                    for g in all_groups:
                        try:
                            if "scrollbar" in str(g.element_info.automation_id).lower():
                                scrollbar_wrapper = g
                                break
                        except:
                            pass

                    if scrollbar_wrapper:
                        # wrapper found → no .exists()
                        self._log_result("Scrollbar Presence", True)
                    else:
                        self._log_result("Scrollbar Presence", False, "Not found after selection")
                        all_ok = False

            except Exception as e:
                self._log_result("Scrollbar Presence", False, str(e))
                all_ok = False

            # =========================================================
            # 8. Click Cancel Button
            # =========================================================
            cancel_btn.click_input()
            self._log_result("Click Cancel Button", True)
            time.sleep(2)

            # =========================================================
            # 9. Verify Modal Closed
            # =========================================================
            if not modal.exists(timeout=3):
                self._log_result("Modal Closed After Cancel", True)
            else:
                self._log_result("Modal Closed After Cancel", False)
                all_ok = False

            # =========================================================
            # FINAL RESULT
            # =========================================================
            if all_ok:
                print("\nOverall test results : PASS")
                print("-" * 60)
                return True
            else:
                print("\nOverall test results : FAIL")
                print("-" * 60)
                return False

        except Exception as e:
            self._log_result("Add Application Modal", False, str(e))
            print("\nOverall test results : FAIL")
            print("-" * 60)
            return False




    #--------------------------Delete profile Page UI validation ----------------------------------------------------------------------------------------------


    def TC_ID_C51570673_verify_delete_profile_popup_ui(self):

        print("\nTEST CASE: Verify Delete Profile UI (FINAL STABLE)")
        print("-" * 80)

        overall_pass = True

        try:
            # =====================================================
            # STEP 0: ENSURE CALCULATOR PRESENT
            # =====================================================
            calculator_app = self.main_window.child_window(
                title="Calculator",
                control_type="ListItem"
            )

            if not calculator_app.exists(timeout=5):
                self._log_result("Calculator Presence", True, "Not found → Adding Calculator")

                try:
                    # ---------- STEP 1: CLICK ADD (+) ----------
                    add_btn = self.main_window.child_window(
                        auto_id="ReactPCContextAware.Carousel.AddButton",
                        control_type="Button"
                    )

                    if not add_btn.exists(timeout=5):
                        self._log_result("Add Apps", False, "Add (+) button not found")
                        return False

                    add_btn.click_input()
                    time.sleep(1)
                    self._log_result("Add Apps", True, "Add (+) clicked")

                    # ---------- STEP 2: FIND CALCULATOR ----------
                    calc_btn = self.main_window.child_window(
                        auto_id="ReactPCContextAware.InstalledAppsModal.AppItem2399C925B35566234AB600C70B12C40E",
                        control_type="Button"
                    )

                    found = False

                    # If already visible
                    if calc_btn.exists() and calc_btn.is_visible():
                        found = True
                        self._log_result("Add Apps", True, "Calculator found without scrolling")

                    else:
                        # Click Administrative Tools to enable scroll
                        admin_tool_btn = self.main_window.child_window(
                            auto_id="ReactPCContextAware.InstalledAppsModal.AppItem2328013EC67257A5EFF59B60098FEB2B",
                            control_type="Button"
                        )

                        if admin_tool_btn.exists() and admin_tool_btn.is_visible():
                            admin_tool_btn.click_input()
                            time.sleep(0.3)
                            self._log_result("Add Apps", True, "Administrative Tools selected")

                        # Scroll to find Calculator
                        for _ in range(15):
                            if calc_btn.exists() and calc_btn.is_visible():
                                found = True
                                break
                            self.main_window.type_keys("{PGDN}")
                            time.sleep(0.4)

                    # ---------- STEP 3: SELECT CALCULATOR ----------
                    if found:
                        calc_btn.click_input()
                        time.sleep(1)
                        self._log_result("Add Apps", True, "Calculator selected")
                    else:
                        self._log_result("Add Apps", False, "Calculator not found")
                        overall_pass = False

                    # ---------- STEP 4: CLICK CONTINUE ----------
                    continue_btn = self.main_window.child_window(
                        title="Continue",
                        control_type="Button"
                    )

                    for _ in range(5):
                        if continue_btn.exists() and continue_btn.is_enabled():
                            break
                        time.sleep(0.5)

                    if continue_btn.exists() and continue_btn.is_enabled():
                        continue_btn.click_input()
                        time.sleep(2)
                        self._log_result("Add Apps", True, "Continue clicked")
                    else:
                        self._log_result("Add Apps", False, "Continue button not enabled")
                        overall_pass = False

                except Exception as e:
                    self._log_result("Calculator Flow", False, str(e))
                    overall_pass = False

            else:
                self._log_result("Calculator Presence", True)

            # =====================================================
            # STEP 1: CLICK CALCULATOR
            # =====================================================
            calc_click = False

            try:
                calculator_app = self.main_window.child_window(
                    title="Calculator",
                    control_type="ListItem"
                )

                if calculator_app.exists():
                    calculator_app.click_input()
                    time.sleep(2)
                    calc_click = True

            except:
                pass

            self._log_result("Calculator Click", calc_click)
            if not calc_click:
                overall_pass = False

            # =====================================================
            # STEP 2: CLICK DELETE PROFILE
            # =====================================================
            delete_click = False

            try:
                delete_btn = self.main_window.child_window(
                    auto_id="ReactPCContextAware.Carousel.DeleteProfileButton",
                    control_type="Button"
                )

                if delete_btn.exists() and delete_btn.is_enabled():
                    delete_btn.click_input()
                    time.sleep(3)
                    delete_click = True

            except:
                pass

            self._log_result("Delete Profile Click", delete_click)
            if not delete_click:
                overall_pass = False

            # =====================================================
            # STEP 3: POPUP DETECTION
            # =====================================================
            popup_found = False

            try:
                self.main_window.set_focus()
                time.sleep(1)

                for _ in range(10):
                    continue_btn = self.main_window.child_window(
                        auto_id="ReactPCContextAware.DeleteProfileModal.ContinueButton",
                        control_type="Button"
                    )

                    if continue_btn.exists():
                        popup_found = True
                        break

                    time.sleep(1)

            except Exception as e:
                self._log_result("Popup Detection Error", False, str(e))

            self._log_result("Popup Presence", popup_found)

            if not popup_found:
                overall_pass = False

            # =====================================================
            # STEP 4: VALIDATE UI
            # =====================================================
            if popup_found:

                title_ok = self.main_window.child_window(
                    title="Delete profile",
                    control_type="Text"
                ).exists()
                self._log_result("Title Validation", title_ok)

                desc_ok = self.main_window.child_window(
                    title="Are you sure you want to remove this app configuration? This application will be removed from all modules.",
                    control_type="Text"
                ).exists()
                self._log_result("Description Text", desc_ok)

                checkbox = self.main_window.child_window(
                    auto_id="ReactPCContextAware.DeleteProfileModal.ConfirmationCheckbox__checkbox",
                    control_type="CheckBox"
                )

                checkbox_ok = checkbox.exists()
                self._log_result("Checkbox Presence", checkbox_ok)

                if checkbox_ok:
                    try:
                        if checkbox.get_toggle_state() == 0:
                            self._log_result("Checkbox Default State", True)
                        else:
                            overall_pass = False
                    except:
                        overall_pass = False
                else:
                    overall_pass = False

                cancel_ok = self.main_window.child_window(
                    auto_id="ReactPCContextAware.DeleteProfileModal.CancelButton",
                    control_type="Button"
                ).exists()
                self._log_result("Cancel Button", cancel_ok)

                continue_ok = self.main_window.child_window(
                    auto_id="ReactPCContextAware.DeleteProfileModal.ContinueButton",
                    control_type="Button"
                ).exists()
                self._log_result("Continue Button", continue_ok)

            # =====================================================
            # STEP 5: CLOSE POPUP
            # =====================================================
            try:
                self.main_window.type_keys("{ESC}")
                time.sleep(1)
                self._log_result("Close Popup (ESC)", True)
            except Exception as e:
                self._log_result("Close Popup (ESC)", False, str(e))
                overall_pass = False

            # =====================================================
            # FINAL RESULT
            # =====================================================
            print("\n" + "-" * 80)
            print(f"OVERALL TEST RESULT : {'PASS' if overall_pass else 'FAIL'}")
            print("-" * 80)

            return overall_pass

        except Exception as e:
            self._log_result("Test Execution", False, str(e))
            print("\nOVERALL TEST RESULT : FAIL")
            print("-" * 80)
            return False





# ------------------------------------------------------------------------------------------------------------------------------------- 


    def get_tooltip_text(self, tooltip):
        """
        Extract text from tooltip children (fix for empty window_text)
        """
        try:
            # 1️⃣ Try direct text
            text = tooltip.window_text().strip()
            if text:
                return text

            # 2️⃣ Get from children (IMPORTANT FIX)
            for child in tooltip.descendants():
                try:
                    child_text = child.window_text().strip()
                    if child_text:
                        return child_text
                except:
                    continue

        except:
            pass

        return ""




    def TC_ID_C60424979_verify_add_button_tooltip(self):
        """
        Verify tooltip for Add Application button using hover (no click, no coordinates)
        """
        print("\nTEST CASE: Verify Add Application Button Tooltip (Hover)")
        print("-" * 60)

        if not self.main_window:
            self._log_result("Add Button", False, "Application not connected")
            return False

        import time
        overall_pass = True

        def get_add_button():
            try:
                return self.main_window.child_window(
                    title="Add Application",
                    control_type="Button"
                )
            except:
                return None

        def get_tooltip():
            """
            Find tooltip using dynamic auto_id
            """
            try:
                for elem in self.main_window.descendants(control_type="Group"):
                    try:
                        auto_id = elem.element_info.automation_id
                        if auto_id and auto_id.startswith("clientos-ui-toolkit-tooltip"):
                            if elem.is_visible():
                                return elem
                    except:
                        continue
            except:
                pass
            return None

        def extract_tooltip_text(tooltip):
            """
            Extract text from tooltip children
            """
            try:
                text = tooltip.window_text().strip()
                if text:
                    return text

                for child in tooltip.descendants():
                    try:
                        child_text = child.window_text().strip()
                        if child_text:
                            return child_text
                    except:
                        continue
            except:
                pass
            return ""

        try:
            add_button = get_add_button()

            if not add_button or not add_button.exists(timeout=2):
                self._log_result("Add Button", False, "Add button not found")
                return False

            #  IMPORTANT: Ensure window active
            self.main_window.set_focus()
            time.sleep(0.5)

            #  HOVER (NO coordinates)
            try:
                add_button.wrapper_object().hover_input()
            except Exception as e:
                self._log_result("Add Button", False, f"Hover failed: {str(e)}")
                return False

            time.sleep(1)

            #  Wait for tooltip
            tooltip = None
            timeout = time.time() + 5

            while time.time() < timeout:
                tip = get_tooltip()
                if tip:
                    tooltip = tip
                    break
                time.sleep(0.3)

            if not tooltip:
                self._log_result("Add Button", False, "Tooltip not visible on hover")
                return False

            tooltip_text = extract_tooltip_text(tooltip)

            print("Tooltip text:", tooltip_text)

            if "Add Application".lower() in tooltip_text.lower():
                self._log_result("Add Button", True, f"Tooltip matched: {tooltip_text}")
            else:
                self._log_result("Add Button", False, f"Tooltip mismatch: {tooltip_text}")
                overall_pass = False

            print("-" * 60)
            print(f"OVERALL TEST RESULT : {'PASS' if overall_pass else 'FAIL'}")
            print("-" * 60)

            return True

        except Exception as e:
            self._log_result("Add Button", False, str(e))
            return False






    def TC_ID_C52928452_delete_application_TAB(self):

        """
        TEST CASE:
        1. Click Netflix
        2. Verify Delete Profile button enabled
        3. TAB 2 times → focus Delete button
        4. Press ENTER
        5. Verify Netflix removed from carousel/app bar
        """

        print("\nTEST CASE: Delete Netflix Profile via Keyboard")
        print("-" * 60)

        import time
        import pyautogui

        try:
            # --------------------------------------------------
            # STEP 1: Click Netflix
            # --------------------------------------------------
            netflix_item = self.main_window.child_window(
                title_re=".*Netflix.*",
                control_type="ListItem",
                visible_only=True,
                found_index=0
            )

            if not netflix_item.exists(timeout=5):
                self._log_result("Netflix Presence", False, "Netflix not found")
                return False

            netflix_item.click_input()
            time.sleep(2)
            self._log_result("Click Netflix", True)

            # --------------------------------------------------
            # STEP 2: Verify Delete Profile Button Enabled
            # --------------------------------------------------
            delete_btn = self.main_window.child_window(
                title="Delete profile",
                control_type="Button"
            )

            if not delete_btn.exists(timeout=5):
                self._log_result("Delete Button Presence", False)
                return False

            delete_wrapper = delete_btn.wrapper_object()

            if delete_wrapper.is_enabled():
                self._log_result("Delete Button Enabled", True)
            else:
                self._log_result("Delete Button Enabled", False)
                return False

            # --------------------------------------------------
            # STEP 3: TAB Navigation (3 times)
            # --------------------------------------------------
            pyautogui.press("tab")
            time.sleep(1)

            pyautogui.press("tab")
            time.sleep(1)
            
            pyautogui.press("tab")
            time.sleep(1)

            # Verify focus reached Delete button
            is_focused = False

            try:
                if delete_wrapper.has_keyboard_focus():
                    is_focused = True
            except:
                pass

            if is_focused:
                print("Delete button is focused ")
            else:
                print("Delete button NOT focused ")
                self._log_result("Delete Button Focus", False)
                return False

            # --------------------------------------------------
            # STEP 4: Press ENTER
            # --------------------------------------------------
            pyautogui.press("enter")
            time.sleep(3)

            self._log_result("Delete Profile Action", True)

            # --------------------------------------------------
            # STEP 5: Verify Netflix NOT visible
            # --------------------------------------------------
            netflix_after = self.main_window.child_window(
                title_re=".*Netflix.*",
                control_type="ListItem",
                visible_only=True,
                found_index=0
            )

            if netflix_after.exists(timeout=5):
                self._log_result(
                    "Netflix Removal Verification",
                    False,
                    "Netflix still visible after delete"
                )

                print("\nOVERALL TEST RESULT : FAIL")
                print("-" * 60)
                return False

            else:
                self._log_result(
                    "Netflix Removal Verification",
                    True,
                    "Netflix removed successfully"
                )

                print("\nOVERALL TEST RESULT : PASS")
                print("-" * 60)
                return True

        except Exception as e:
            self._log_result("Delete Netflix Profile", False, str(e))

            print("\nOVERALL TEST RESULT : FAIL")
            print("-" * 60)
            return False







    def TC_ID_C52928009_Add_application_TAB(self):

        """
        TEST CASE:
        1. Click Global App (For all applications)
        2. TAB once → ENTER
        3. TAB twice → ENTER
        4. Click Continue
        5. Verify app visible in carousel
        """

        print("\nTEST CASE: Global App TAB Flow + Carousel Verification")
        print("-" * 60)

        import time
        import pyautogui

        try:
            # --------------------------------------------------
            # STEP 1: Click Global App (For all applications)
            # --------------------------------------------------
            global_apps_item = self.main_window.child_window(
                title="For all applications",
                control_type="ListItem"
            )

            if not global_apps_item.exists(timeout=5):
                self._log_result("Global App Presence", False)
                return False

            global_apps_item.click_input()
            time.sleep(2)

            self._log_result("Click Global App", True)

            # --------------------------------------------------
            # # STEP 2: TAB once → ENTER
            # # --------------------------------------------------
            # pyautogui.press("tab")
            # time.sleep(1)

            # pyautogui.press("enter")
            # time.sleep(3)

            self._log_result("TAB 1 + ENTER", True)

            # --------------------------------------------------
            # STEP 3: TAB twice → ENTER
            # --------------------------------------------------
            pyautogui.press("tab")
            time.sleep(1)

            pyautogui.press("tab")
            time.sleep(1)

            pyautogui.press("enter")
            time.sleep(3)

            self._log_result("TAB 2 + ENTER", True)
            
            calculator_btn = self.main_window.child_window(
                title="Calculator",
                control_type="Button"
            ).wait('exists enabled visible', timeout=10)

            print("Clicking Calculator (SELECT)...")
            calculator_btn.click_input()
            time.sleep(3)

            # --------------------------------------------------
            # STEP 4: Click Continue Button (stable)
            # --------------------------------------------------
            continue_btn = self.main_window.child_window(
                title="Continue",
                control_type="Button"
            )

            if not continue_btn.exists(timeout=10):
                self._log_result("Continue Button", False, "Not found")
                return False

            continue_btn.wait("visible", timeout=10)
            continue_btn.wait("enabled", timeout=10)

            time.sleep(2)

            continue_wrapper = continue_btn.wrapper_object()

            try:
                continue_wrapper.set_focus()
                time.sleep(1)
            except:
                pass

            try:
                continue_wrapper.click_input()
            except:
                print("click failed → trying invoke")
                try:
                    continue_wrapper.invoke()
                except:
                    self._log_result("Continue Button", False, "Click failed")
                    return False

            time.sleep(3)

            self._log_result("Click Continue", True)

            # --------------------------------------------------
            # STEP 5: Verify any app visible in carousel
            # --------------------------------------------------
            apps = self.main_window.descendants(control_type="ListItem")

            visible_apps = [
                e for e in apps
                if e.is_visible() and e.window_text().strip() != ""
            ]

            if visible_apps:
                print("Apps visible in carousel ")
                self._log_result("Carousel App Visibility", True)

                print("\nOVERALL TEST RESULT : PASS")
                print("-" * 60)
                return True
            else:
                print("No apps visible ")
                self._log_result("Carousel App Visibility", False)

                print("\nOVERALL TEST RESULT : FAIL")
                print("-" * 60)
                return False

        except Exception as e:
            self._log_result("Global App Flow", False, str(e))

            print("\nOVERALL TEST RESULT : FAIL")
            print("-" * 60)
            return False



#    # ---------------- Run all steps in sequence ----------------

    def run_steps(self):
        steps = [
            
            self.open_hp_application,
            self.connect_to_application,
            self.handle_startup_conditions,
            self.navigate_to_Audio,
            self.dump_ui_tree_to_file,
            # self.TC_ID_C51570671_Appsetting_default_UI,
            # self.TC_ID_C51570650_verify_default_state_of_CA_apps,
            # self.TC_ID_C51570672_Add_Application_UI,
            # self.TC_ID_C51570673_verify_delete_profile_popup_ui,
            # self.TC_ID_C51570659_verify_imax_apps_in_carousel,
            # self.TC_ID_C51570660_launch_and_verify_oob_apps,
            # self.TC_ID_C53046320_Uninstall_OOB_apps_and_Reset_HPX_application,
            # self.TC_ID_C77290501_navigate_to_CA_and_click_Add_button,
            # self.TC_ID_C51570654_add_multiple_apps, 
            # self.TC_ID_C51570657_verify_selected_application_name_and_focus,
            # self.TC_ID_C51570655_verify_application_selected_in_app_bar,
            # self.TC_ID_C52986236_search_and_add_application, 
            # self.TC_ID_C51570652_click_carousel_next,
            # self.TC_ID_C77291045_verify_carousel_apps,
            # self.TC_ID_C51570658_verify_delete_profile_button_enable_disable,
            # self.TC_ID_C60424978_verify_carousel_app_tooltips,
            # self.TC_ID_C51570664_verify_global_app_focus_after_hp_relaunch,
            # self.TC_ID_C53033386_verify_aapplication_Select_Unselect,
            # self.TC_ID_C51570661_Delete_Custom_OOB_App,
            # self.TC_ID_C53045345_Delete_app_without_delete_profile_page,
            # self.TC_ID_C51570647_netflix_uninstal_Apperror_Icon_validation,
            # self.TC_ID_C51570648_netflix_uninstalled_Apperror_message_validation,
            # self.TC_ID_C51570649_netflix_app_error_resolve,
            # self.TC_ID_C51570662_launch_multiple_apps,
            # self.TC_ID_C51570663_Application_Setting_Close_launch,
            # self.TC_ID_C51570664_application_close_and_launch_with_different_app,
            # self.TC_ID_C51570665_Delete_App_and_verify_after_relunch,
            # self.TC_ID_C51570666_Application_Setting_Uninstall_Application,
            # self.TC_ID_C52928452_delete_application_TAB,
            # self.TC_ID_C52928009_Add_application_TAB,
            
            self.device_page_backbutton
            
        ]

        
        overall_status = True

        print("\n" + "=" * 60)
        print(" STARTING TEST EXECUTION")
        print("=" * 60)

        for step in steps:
            step_name = step.__name__

            print(f"\n STEP: {step_name}")
            print("-" * 50)

            try:
                result = step()

                if not result:
                    print(f"STEP FAILED: {step_name}")
                    overall_status = False
                    continue  #  put break to stop execution on failure (recommended)
                else:
                    print(f"STEP PASSED: {step_name}")

            except Exception as e:
                print(f"STEP ERROR: {step_name} | {str(e)}")
                overall_status = False
                break

        # -------------------------------------------------
        # FINAL RESULT
        # -------------------------------------------------
        print("\n" + "=" * 60)

        if overall_status:
            print("OVERALL TEST RESULT: PASS")
        else:
            print("OVERALL TEST RESULT: FAIL")

        print("=" * 60)

        return overall_status



    # ---------------- Main ----------------
   
if __name__ == "__main__":
    hp_app = MyHP()

    if hp_app.run_steps():
        print("All tests completed.")
    else:
        print("OVERALL TEST RESULT : FAIL")





