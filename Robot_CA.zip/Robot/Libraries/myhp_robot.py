# myhp_robot.py
from PS import MyHP       # Main HP app functions
from robot.api import logger

# Instantiate general HP app object
hp_app = MyHP()  

# ---------------- Robot Framework Keywords ----------------

def open_hp_application():
    """Open the HP application."""
    result = hp_app.open_hp_application()
    logger.info(f"Open HP Application result: {result}")
    return result

def connect_to_application():
    """Connect to the HP application."""
    result = hp_app.connect_to_application()
    logger.info(f"Connect to Application result: {result}")
    return result

def navigate_to_audio():
    """Navigate to Audio section."""
    result = hp_app.navigate_to_Audio()
    logger.info(f"Navigate to Audio result: {result}")
    return result

def verify_imax_apps_in_carousel():
    """Verify IMAX apps in carousel."""
    result = hp_app.verify_imax_apps_in_carousel()
    if result:
        logger.info("IMAX apps are present in the carousel")
    else:
        logger.error("IMAX apps are missing in the carousel")
    return result

def navigate_to_CA():
    """Navigate to Context Aware section."""
    result = hp_app.navigate_to_CA()
    logger.info(f"Navigate to Context Aware result: {result}")
    return result

def add_multiple_apps2():
    """Add multiple applications."""
    result = hp_app.add_multiple_apps2()
    logger.info(f"Add Multiple Apps result: {result}")
    return result

def search_and_add_application():
    """Search and add an application."""
    result = hp_app.search_and_add_application()
    logger.info(f"Search and Add Application result: {result}")
    return result   

def click_carousel_next():
    """Click the next button on the carousel."""
    result = hp_app.click_carousel_next()
    logger.info(f"Click Carousel Next result: {result}")
    return result

def verify_carousel_apps():
    """Verify applications in the carousel."""
    result = hp_app.verify_carousel_apps()
    logger.info(f"Verify Carousel Apps result: {result}")
    return result

def verify_carousel_app_tooltips():
    """Verify tooltips for applications in the carousel."""
    result = hp_app.verify_carousel_app_tooltips()
    logger.info(f"Verify Carousel App Tooltips result: {result}")
    return result

def device_page_backbutton():
    """Verify Back button navigation from PC Device page."""
    result = hp_app.device_page_backbutton()
    logger.info(f"Device Page Back Button result: {result}")
    return result