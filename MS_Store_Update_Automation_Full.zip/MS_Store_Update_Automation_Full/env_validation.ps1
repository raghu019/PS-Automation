Write-Host "=== OTA Automation Environment Validation ==="

# -------------------------------------------------
# Admin Check
# -------------------------------------------------
$admin = ([Security.Principal.WindowsPrincipal] `
    [Security.Principal.WindowsIdentity]::GetCurrent()
).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")

if (-not $admin) {
    Write-Host "[FAIL] Script must be run as Administrator"
    exit 1
}
Write-Host "[OK] Admin privileges confirmed"

# -------------------------------------------------
# OS Check
# -------------------------------------------------
$os = (Get-CimInstance Win32_OperatingSystem).Caption
Write-Host "[OK] OS Detected: $os"

# -------------------------------------------------
# PowerShell Version Check
# -------------------------------------------------
if ($PSVersionTable.PSVersion.Major -lt 5) {
    Write-Host "[FAIL] PowerShell 5.1 or higher is required"
    exit 1
}
Write-Host "[OK] PowerShell version OK: $($PSVersionTable.PSVersion)"

# -------------------------------------------------
# Python Check
# -------------------------------------------------
$pythonCmd = Get-Command python -ErrorAction SilentlyContinue
if (-not $pythonCmd) {
    Write-Host "[FAIL] Python not found in PATH"
    exit 1
}
Write-Host "[OK] Python found"
python --version

# -------------------------------------------------
# Python Package Check
# -------------------------------------------------
$packages = @("pywinauto", "win32api", "comtypes")
foreach ($pkg in $packages) {
    # Run Python to check package
    python -c "import importlib.util, sys; sys.exit(0 if importlib.util.find_spec(sys.argv[1]) else 1)" $pkg
    if ($LASTEXITCODE -eq 0) {
        Write-Host "[OK] Python package installed: $pkg"
    }
    else {
        Write-Host "[FAIL] Missing Python package: $pkg"
        exit 1
    }
}

# -------------------------------------------------
# Microsoft Store Check
# -------------------------------------------------
$store = Get-AppxPackage Microsoft.WindowsStore -ErrorAction SilentlyContinue
if ($store) {
    Write-Host "[OK] Microsoft Store installed"
} else {
    Write-Host "[FAIL] Microsoft Store is not installed"
    exit 1
}

# -------------------------------------------------
# MSIX Support Check
# -------------------------------------------------
$addAppx = Get-Command Add-AppxPackage -ErrorAction SilentlyContinue
if ($addAppx) {
    Write-Host "[OK] MSIX installation supported"
} else {
    Write-Host "[FAIL] MSIX installation support not available"
    exit 1
}
# -------------------------------------------------
# Visual Studio Code Check (without launching)
# -------------------------------------------------
$vsCodeExePath = "$env:LOCALAPPDATA\Programs\Microsoft VS Code\Code.exe"
$productJsonPath = "$env:LOCALAPPDATA\Programs\Microsoft VS Code\resources\app\product.json"

if ((Test-Path $vsCodeExePath) -and (Test-Path $productJsonPath)) {
    $json = Get-Content $productJsonPath | Out-String | ConvertFrom-Json
    $vsCodeVersion = $json.version
    Write-Host "[OK] Visual Studio Code detected: Version $vsCodeVersion"
} else {
    Write-Host "[FAIL] Visual Studio Code not detected"
    Write-Host "Please install Visual Studio Code (recommended version 1.107.1 user setup)"
    exit 1
}
# -------------------------------------------------
Write-Host "[SUCCESS] Environment validation PASSED"
