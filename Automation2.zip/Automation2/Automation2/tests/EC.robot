*** Settings ***
Library    ../libraries/ec1_keyboard.py
Library    ../libraries/ec2_keyboard.py

*** Test Cases ***
TC1 - Energy Page Navigation
    Run Keyword And Continue On Failure    Open HP Application
    Run Keyword And Continue On Failure    Connect HP Application
    Run Keyword And Continue On Failure    Navigate To PC Device
    Run Keyword And Continue On Failure    TC1 Energy Page

TC2 - Hyperlinks
    Run Keyword And Continue On Failure    TC2 Hyperlinks

TC3 - Button Links
    Run Keyword And Continue On Failure    TC3 Button Links

TC4 - More Helpful Links
    Run Keyword And Continue On Failure    TC4 More Helpful Links

TC5 - Dropdown Stability
    Run Keyword And Continue On Failure    TC5 Dropdown Stability

TC6 - Last 12 Hours
    Run Keyword And Continue On Failure    TC6 Last 12 Hours

TC7 - Last 6 Days
    Run Keyword And Continue On Failure    TC7 Last 6 Days

TC8 - Last 6 Months
    Run Keyword And Continue On Failure    TC8 Last 6 Months

Teardown
    Run Keyword And Continue On Failure    ec1_keyboard.Close HP Application

TC9 - TC9: Open HP Application via run dialog
    Run Keyword And Continue On Failure    ec2_keyboard. TC9: Open HP Application via run dialog


Tearup
   Run Keyword And Continue On Failure    ec2_keyboard.Close HP Application

TC10 - TC10: verify_go_beyound_sustainable_impact_report
     Run Keyword And Continue On Failure      ec2_keyboard.TC10: Go Beyound-Sustainable Impact Report pdf verification

TC11 - TC11: Navigate to Energy Consumption page with out any crash
    Run Keyword And Continue On Failure     ec2_keyboard.TC11: Navigate to Energy Consumption page with out any crash

#**********Testcase#12 is related to OLDER BIOS with supported platform --Displaying warning message (ec6_1.py)*********

TC13 - TC13:Verifying BIOS warning message on supported platform with latest BIOS
    Run Keyword And Continue On Failure  ec2_keyboard.TC13: Verifying BIOS warning message on supported platform with latest BIOS

#*****TC14: Verify Energy Consumption card is NOT displayed for unsupported BIOS/unsupported platform (ec6.py) ******
#*****TC15: Verify Energy Consumption card is NOT displayed for supported BIOS/unsupported platform (ec7.py) ******

TC16 - TC16:Verifying Total Energy Consumption Dropdown Stability with out any crash
    Run Keyword And Continue On Failure  ec2_keyboard.TC16:Verifying Total Energy Consumption Dropdown Stability with out any crash
