*** Settings ***
#Library    ../libraries/ec1_keyboard.py
Library    ../libraries/ec2_keyboard.py

*** Test Cases ***
TC1 - TC id:C51250961 Energy Page Navigation
    Run Keyword And Continue On Failure  ec2_keyboard.Open HP Application
    Run Keyword And Continue On Failure  ec2_keyboard.Connect HP Application
    Run Keyword And Continue On Failure  ec2_keyboard.Navigate To PC Device
    Run Keyword And Continue On Failure  ec2_keyboard.TC1 Energy Page

TC2 - TC id:C51250972 Hyperlinks
    Run Keyword And Continue On Failure   ec2_keyboard.TC2 Hyperlinks

TC3 - TC id:C51250972 Button Links
    Run Keyword And Continue On Failure    ec2_keyboard.TC3 Button Links

TC4 - TC id:C51250973 More Helpful Links
    Run Keyword And Continue On Failure    ec2_keyboard.TC4 More Helpful Links

Close HP Application
  Run Keyword And Continue On Failure  ec2_keyboard.Close HP Application

TC5 - TC id:C51250969 Dropdown Stability
    Run Keyword And Continue On Failure    ec2_keyboard.TC5 Dropdown Stability

TC6 - TC id:C51250964 Last 12 Hours
    Run Keyword And Continue On Failure    ec2_keyboard.TC6 Last 12 Hours

TC7 - TC id:C51250965 Last 6 Days
    Run Keyword And Continue On Failure    ec2_keyboard.TC7 Last 6 Days

TC8 - TC id:C51250966 Last 6 Months
    Run Keyword And Continue On Failure    ec2_keyboard.TC8 Last 6 Months

TC9 - TC9:TC id: C52992699 Open HP Application via run dialog
    Run Keyword And Continue On Failure    ec2_keyboard. TC9: Open HP Application via run dialog
 Shut HP Application
   Run Keyword And Continue On Failure     ec2_keyboard.Close Hp Application

TC10 - TC10:TC id:C51250967 verify_go_beyound_sustainable_impact_report
     Run Keyword And Continue On Failure      ec2_keyboard.TC10: Go Beyound-Sustainable Impact Report pdf verification

TC11 - TC11:TC id:C51250975 Navigate to Energy Consumption page with out any crash
    Run Keyword And Continue On Failure     ec2_keyboard.TC11: Navigate to Energy Consumption page with out any crash

#**********Testcase#12: TC id: C51250991 is related to OLDER BIOS with supported platform --Displaying warning message (ec6_1.py)*********

TC13 - TC13:TC id:C51250990 Verifying BIOS warning message on supported platform with latest BIOS
    Run Keyword And Continue On Failure  ec2_keyboard.TC13: Verifying BIOS warning message on supported platform with latest BIOS

#*****TC14: TC id: C51250992 Verify Energy Consumption card is NOT displayed for unsupported BIOS/unsupported platform (ec6.py) ******
#*****TC15: TC id: C51250992 Verify Energy Consumption card is NOT displayed for supported BIOS/unsupported platform (ec7.py) ******

TC16 - TC16:TC id:C51250969 Verifying Total Energy Consumption Dropdown Stability with out any crash
    Run Keyword And Continue On Failure  ec2_keyboard.TC16:Verifying Total Energy Consumption Dropdown Stability with out any crash

TC17 - TC17:TC id:C51250970 Verifying Total Energy consumption consumed by apps with in a month
    Run Keyword And Continue On Failure  ec2_keyboard.tc17_total_energy_last_Month

TC18 - TC18:TC id:C51250971 Verifying Total Energy consumption consumed by apps with in a week
    Run Keyword And Continue On Failure  ec2_keyboard.tc18_total_energy_last_week
     
TC19 - TC19:TC id:C51250968 Verifying Total Energy consumption UI validation
    Run Keyword And Continue On Failure  ec2_keyboard.tc19_total_energy_consumption_UI_val
   
TC20 - TC20:TC id:C51250977 Verifying Energy consumption application in Dark mode
    Run Keyword And Continue On Failure   ec2_keyboard.tc20_dark_mode

TC21 - TC21:TC id:C51250983 Verifying Energy consumption application by toggle switch of color filters
    Run Keyword And Continue On Failure   ec2_keyboard.tc21_colorfilter