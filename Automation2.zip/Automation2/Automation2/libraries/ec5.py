import time
import pyautogui
import pygetwindow as gw
from pywinauto import Application
import os


class MyHP:
    TIMEOUT = 10

    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"
        self.baseline_folder = r"C:\Testing\Automation2\Automation2\baseline"
        os.makedirs(self.baseline_folder, exist_ok=True)

    # ---------------- Logger ----------------
    def _log_result(self, test_name, status, message=""):
        result = "PASS" if status else "FAIL"
        print(f"[{result}] {test_name}: {message}")

    # ---------------- Open HP Application ----------------
    def open_hp_application(self):
        try:
            pyautogui.press('winleft')
            time.sleep(1)
            pyautogui.write(self.app_title)
            time.sleep(1)
            pyautogui.press('enter')
            time.sleep(12)

            active_window = gw.getActiveWindow()
            if active_window and self.app_title in active_window.title:
                active_window.maximize()
                time.sleep(3)
                self._log_result("Open Application", True, active_window.title)
                return True

            self._log_result("Open Application", False, "Wrong window focused")
            return False

        except Exception as e:
            self._log_result("Open Application", False, str(e))
            return False

    # ---------------- Connect to HP Application ----------------
    def connect_to_application(self):
        try:
            self.application = Application(backend="uia").connect(title_re=self.app_title)
            self.main_window = self.application.window(title_re=self.app_title)
            self.main_window.wait("ready", timeout=self.TIMEOUT)
            self.main_window.set_focus()
            self._log_result("Connect to Application", True)
            return True
        except Exception as e:
            self._log_result("Connect to Application", False, str(e))
            return False

      
          # ---------------- Navigate to PC Device (Optional) ----------------
    def navigate_to_pc_device(self):
        try:
            self.main_window.set_focus()
            time.sleep(5)

            pc_device = self.main_window.child_window(
                auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname",
                control_type="Text"
            )

            if pc_device.exists(timeout=8):
                pc_device.click_input()
                time.sleep(6)
                self._log_result("Navigate to PC Device", True)
                return True

            self._log_result("Navigate to PC Device", True, "Device page not present — continuing test")
            return True  # <-- IMPORTANT: return True even if not found

        except Exception as e:
            self._log_result("Navigate to PC Device", True, f"Skipped: {str(e)}")
            return True  # <-- Never fail test here



    # ---------------- Navigate to Energy Consumption ----------------
    def navigate_to_energy_consumption(self):
        try:
            self.main_window.set_focus()
            time.sleep(3)

            energy_btn = self.main_window.child_window(
                auto_id="PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard",
                control_type="Button"
            )

            # Scroll a bit to ensure element is visible
            self.main_window.type_keys("{PGDN}")
            time.sleep(1)
            self.main_window.type_keys("{UP}{UP}")
            time.sleep(2)

            if energy_btn.exists(timeout=10):
                energy_btn.click_input()
                time.sleep(10)
                self._log_result("Navigate to Energy Consumption", True)
                return True

            self._log_result("Navigate to Energy Consumption", False, "Energy card not found")
            return False

        except Exception as e:
            self._log_result("Navigate to Energy Consumption", False, str(e))
            return False

    # ---------------- Verify BIOS Warning NOT Displayed ----------------
    def verify_no_bios_warning_message(self):
        try:
            self.main_window.set_focus()
            time.sleep(5)

            warning_text = self.main_window.child_window(
                title_re=".*update.*BIOS.*",
                control_type="Text"
            )

            learn_more = self.main_window.child_window(
                title="Learn more",
                control_type="Hyperlink"
            )

            # If warning exists → FAIL
            if warning_text.exists(timeout=5) or learn_more.exists(timeout=5):
                message = "BIOS warning message is displayed (should NOT be present)"
                self._log_result("Verify BIOS Warning NOT Displayed", False, message)
                return False

            # If not shown → PASS
            self._log_result("Verify BIOS Warning NOT Displayed", True, "No BIOS warning message shown")
            return True

        except Exception as e:
            self._log_result("Verify BIOS Warning NOT Displayed", False, str(e))
            return False


 # ---------------- Close HP Application ----------------
    def close_hp_application(self):
        try:
            self.main_window.set_focus()
            time.sleep(2)

            # Try graceful close
            self.main_window.close()
            time.sleep(5)

            # Verify it's closed
            windows = gw.getWindowsWithTitle(self.app_title)
            if not windows:
                self._log_result("Close HP Application", True, "HP app closed successfully")
                return True

            # Fallback: ALT+F4
            pyautogui.hotkey("alt", "f4")
            time.sleep(5)

            windows = gw.getWindowsWithTitle(self.app_title)
            if not windows:
                self._log_result("Close HP Application", True, "HP app closed using ALT+F4")
                return True

            self._log_result("Close HP Application", False, "HP app still running")
            return False

        except Exception as e:
            self._log_result("Close HP Application", False, str(e))
            return False


        # ---------------- TC13: Verify BIOS Warning Message ----------------
    def tc13_verify_no_bios_warning_message(self):
        print("-" * 80)
        print("TC13: Verifying BIOS warning message on Supported platform with latest BIOS")
        print("-" * 80)

        if not self.open_hp_application():
            return False

        if not self.connect_to_application():
            return False

        # Optional step – never fails
        self.navigate_to_pc_device()

        if not self.navigate_to_energy_consumption():
            return False

        result = self.verify_no_bios_warning_message()

        self.close_hp_application()
        return result
        
        
# ---------------- Run Test ----------------
if __name__ == "__main__":
    hp = MyHP()
    hp.tc13_verify_no_bios_warning_message()
    print("-" * 110)
    print("TC13: Supported platform with latest BIOS should not display BIOS warning message - sucessfully executed")
    print("-" * 110)
