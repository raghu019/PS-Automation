import time
import pygetwindow as gw
from pywinauto import Application
import pyautogui
import re


class MyHP:
    TIMEOUT = 15

    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"

    # ---------------- Logger ----------------
    def _log_result(self, name, status, msg=""):
        print(f"[{'PASS' if status else 'FAIL'}] {name}: {msg}")

    # ---------------- Open App ----------------
    def open_hp_application(self):
        pyautogui.press("winleft")
        time.sleep(2)
        pyautogui.write(self.app_title)
        time.sleep(2)
        pyautogui.press("enter")
        time.sleep(8)

        win = gw.getActiveWindow()
        if win and self.app_title in win.title:
            win.maximize()
            time.sleep(6)
            self._log_result("Open Application", True)
            return True

        self._log_result("Open Application", False)
        return False

    # ---------------- Connect ----------------
    def connect_to_application(self):
        self.application = Application(backend="uia").connect(
            title_re=self.app_title
        )
        self.main_window = self.application.window(
            title_re=self.app_title
        )
        self.main_window.wait("visible", timeout=self.TIMEOUT)
        self._log_result("Connect to Application", True)
        return True

    # ---------------- Navigate ----------------
    def navigate_to_pc_device(self):
        pc = self.main_window.child_window(
            auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname",
            control_type="Text"
        )
        pc.wait("visible", timeout=10)
        pc.click_input()
        time.sleep(5)
        self._log_result("Navigate to PC Device", True)
        return True

    def navigate_to_energy_consumption(self):
        self.main_window.type_keys("{PGDN}")
        time.sleep(8)

        energy = self.main_window.child_window(
            auto_id="PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard",
            control_type="Button"
        )
        energy.wait("visible", timeout=20)
        energy.click_input()
        time.sleep(8)

        self._log_result("Navigate to Energy Consumption", True)
        print("-" * 60)
        return True

    # ---------------- Scroll ----------------
    def scroll_to_total_energy_section(self):
        self.main_window.type_keys("{PGDN}")
        time.sleep(1)
        self.main_window.type_keys("{PGDN}")
        time.sleep(1)
        self.main_window.type_keys("{UP 12}")
        time.sleep(6)

    # ---------------- Dropdown ----------------
    def select_total_energy_value(self, option_text):
        try:
            dropdown = self.main_window.child_window(
                control_type="ComboBox"
            )
            dropdown.wait("visible", timeout=10)
            dropdown.expand()
            time.sleep(2)

            option = self.main_window.child_window(
                title=option_text,
                control_type="ListItem"
            )
            option.wait("visible", timeout=10)
            option.click_input()
            time.sleep(5)

            self._log_result(
                "Select Total Energy Dropdown",
                True,
                option_text
            )
            return True

        except Exception as e:
            self._log_result(
                "Select Total Energy Dropdown",
                False,
                str(e)
            )
            return False

    # ---------------- Show More ----------------
    def click_show_more(self):
        try:
            time.sleep(3)

            for ctrl in self.main_window.descendants():
                info = ctrl.element_info

                if info.control_type in ("Button", "Hyperlink"):
                    if "show" in (info.name or "").lower():
                        ctrl.click_input()
                        time.sleep(5)

                        self._log_result(
                            "Show more",
                            True,
                            "Link is working"
                        )
                        return True

            self._log_result("Show more", False, "Not found")
            return False

        except Exception as e:
            self._log_result("Show more", False, str(e))
            return False

    # ---------------- FINAL UI EXTRACTION + VALIDATION ----------------
    def get_total_energy_applications_ui(self):

        percent_pattern = re.compile(r"^\d+%$")

        raw_text = [
            t.window_text().strip()
            for t in self.main_window.descendants(control_type="Text")
            if t.window_text().strip()
        ]

        apps = []
        seen = set()

        i = 0
        while i < len(raw_text) - 1:

            current = raw_text[i]
            next_text = raw_text[i + 1]

            if percent_pattern.match(next_text):

                key = (current, next_text)

                if key not in seen:
                    seen.add(key)
                    apps.append({
                        "app": current,
                        "energy": next_text
                    })

                i += 2
            else:
                i += 1

        print("\nTC 17: Total Energy consumed by the apps in the last Month")
        print("-" * 60)

        for idx, app in enumerate(apps, 1):
            print(f"{idx}. {app['app']}  -->  {app['energy']}")

        print("-" * 60)

        total_count = len(apps)

        # ✅ Validation: Applications should not exceed 20
        if total_count <= 20:
            self._log_result(
                "Application Count Validation",
                True,
                f"{total_count} applications (within limit ≤ 20)"
            )
        else:
            self._log_result(
                "Application Count Validation",
                False,
                f"{total_count} applications (exceeds limit > 20)"
            )

        print(f"Total Applications: {total_count}\n")

        return total_count <= 20

    # ---------------- Test Case ----------------
    def tc_display_total_energy_consumption_last_Month(self):
        print("\nTEST CASE 17: Display Total Energy Consumption for the Last Month")
        print("-" * 60)

        self.scroll_to_total_energy_section()

        if not self.select_total_energy_value("Last Month"):
            return False

        if not self.click_show_more():
            return False

        if not self.get_total_energy_applications_ui():
            return False

        return True

    # ---------------- Close ----------------
    def close_hp_application(self):
        try:
            self.main_window.close()
            time.sleep(3)
        except Exception:
            pyautogui.hotkey("alt", "f4")

        self._log_result("Close Application", True)
        return True

    # ---------------- Runner ----------------
    def tc17_total_energy_last_Month(self):

        if not self.open_hp_application():
            return False

        if not self.connect_to_application():
            return False

        if not self.navigate_to_pc_device():
            return False

        if not self.navigate_to_energy_consumption():
            return False

        if not self.tc_display_total_energy_consumption_last_Month():
            self.close_hp_application()
            return False

        self.close_hp_application()
        return True


# ===================== MAIN =====================
if __name__ == "__main__":
    hp = MyHP()
    hp.tc17_total_energy_last_Month()
