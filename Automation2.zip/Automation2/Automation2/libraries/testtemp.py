import time
import pyautogui
import pygetwindow as gw
from pywinauto import Application
from pywinauto import keyboard
import pytesseract
import cv2
import numpy as np


# Update path if needed
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"



class MyHP:

    TIMEOUT = 20


    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"
        self.baseline_folder = r"C:\Testing\Automation2\Automation2\baseline"

    # ---------------- Logger ----------------
    def log(self, step, status, msg=""):
        result = "PASS" if status else "FAIL"
        print(f"[{result}] {step}: {msg}")
   
     # ---------------- Logger ----------------
    def _log_result(self, test_name, status, message=""):
        result = "PASS" if status else "FAIL"
        print(f"[{result}] {test_name}: {message}")

    def _log_debug(self, message):
        print(f"[DEBUG] {message}")
    # ---------------- Reset HP Application ----------------
    def reset_hp_application(self):

        print("\nTEST CASE: Reset HP Application")
        print("-" * 60)

        try:

            pyautogui.press("win")
            time.sleep(2)

            pyautogui.write("HP")
            time.sleep(3)

            pyautogui.press("right")
            time.sleep(2)

            for _ in range(3):
                pyautogui.press("down")
                time.sleep(1)

            pyautogui.press("enter")
            time.sleep(10)

            pyautogui.press("pagedown")
            time.sleep(2)

            pyautogui.press("pagedown")
            time.sleep(2)

            for _ in range(11):
                pyautogui.press("tab")
                time.sleep(1)

            pyautogui.press("enter")
            time.sleep(2)

            pyautogui.press("enter")
            time.sleep(20)

            self.log("Reset HP Application", True)
            return True

        except Exception as e:
            self.log("Reset HP Application", False, str(e))
            return False

    # ---------------- Open HP Application ----------------
    def open_hp_application(self):
        try:
            pyautogui.press('winleft')
            time.sleep(1)
            pyautogui.write(self.app_title)
            time.sleep(1)
            pyautogui.press('enter')
            time.sleep(5)

            active_window = gw.getActiveWindow()
            if active_window and self.app_title in active_window.title:
                active_window.maximize()
                time.sleep(15)
                self._log_result("Open Application", True)
                return True
            else:
                self._log_result("Open Application", False, "Wrong window focused")
                return False
        except Exception as e:
            self._log_result("Open Application", False, str(e))
            return False

    # ---------------- Connect to HP Application ----------------
    def connect_to_application(self):
        try:
            self.application = Application(backend="uia").connect(title_re=self.app_title)
            self.main_window = self.application.window(title_re=self.app_title)
            self.main_window.wait("ready", timeout=self.TIMEOUT)
            self._log_result("Connect to Application", True)
            return True
        except Exception as e:
            self._log_result("Connect to Application", False, str(e))
            return False

     # ---------------- Navigate to PC Device ----------------
    def navigate_to_pc_device(self):
        try:
            pc_device = self.main_window.child_window(
                auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname",
                control_type="Text"
            )
            if pc_device.exists(timeout=5):
                pc_device.click_input()
                time.sleep(5)
                self._log_result("Navigate to PC Device", True)
                return True
            self._log_result("Navigate to PC Device", False, "PC device not found")
            return True
        except Exception as e:
            self._log_result("Navigate to PC Device", False, str(e))
            return False

     # ---------------- Navigate to Energy Consumption ----------------
    def navigate_to_Energy_consumption(self):
        print("\nTEST CASE 1: Navigate to Energy Consumption module")
        print("-" * 60)

        if not self.main_window:
            self._log_result("Navigate to Energy consumption", False, "Application not connected")
            print("Test case 'Navigate to Energy consumption' completed : FAIL")
            print("-" * 60)
            return False

        try:
            self.main_window.set_focus()
            time.sleep(5)

            energy_btn = self.main_window.child_window(
                auto_id="PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard",
                control_type="Button"
            )

            self.main_window.type_keys("{PGDN}")
            time.sleep(1)
            self.main_window.type_keys("{UP}")
            time.sleep(0.5)
            self.main_window.type_keys("{UP}")
            time.sleep(4)

            if energy_btn.exists(timeout=8):
                energy_btn.click_input()
                time.sleep(10)
                self._log_result("Navigate to Energy consumption", True)
                print("-" * 60)
                return True

            self._log_result(
                "Navigate to Energy consumption page",
                False,
                "Energy consumption card not visible after PGDN + UP UP"
            )
            print("-" * 60)
            return False
        except Exception as e:
            self._log_result("Navigate to Energy consumption page", False, str(e))
            print("-" * 60)
            return False

    # ---------------- Close HP Application ----------------
    def close_hp_application(self):
        try:
            if self.main_window:
                self.main_window.set_focus()
                time.sleep(1)
                self.main_window.close()
                time.sleep(3)
                if not self.main_window.exists(timeout=3):
                    self._log_result("Close Application", True, "Closed using pywinauto")
                    return True

            hp_windows = gw.getWindowsWithTitle(self.app_title)
            if hp_windows:
                hp_windows[0].activate()
                time.sleep(1)
                pyautogui.hotkey('alt', 'f4')
                time.sleep(2)
                self._log_result("Close Application", True, "Closed using Alt+F4")
                return True

            self._log_result("Close Application", False, "HP window not found")
            return False
        except Exception as e:
            self._log_result("Close Application", False, str(e))
            return False

   
    # ---------------- OCR Chart Text ----------------
    def detect_collecting_data(self):

        try:

            screenshot = pyautogui.screenshot()

            img = np.array(screenshot)
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

            text = pytesseract.image_to_string(gray)

            if "collecting data" in text.lower():

                return True

            return False

        except Exception:
            return False

    # ---------------- Dropdown Verification ----------------
    def verify_collecting_data(self):

        print("\nTEST CASE: Verify Collecting Data")
        print("-" * 60)

        dropdowns = [
            ("Last 12 hours", 0),
            ("Last 6 days", 1),
            ("Last 6 months", 2)
        ]

        try:

            for name, index in dropdowns:

                print(f"\nChecking dropdown → {name}")

                self.main_window.set_focus()
                time.sleep(2)

                # open dropdown
                self.main_window.type_keys("{TAB}")
                time.sleep(1)

                self.main_window.type_keys("{ENTER}")
                time.sleep(2)

                # select value
                for _ in range(index):
                    pyautogui.press("down")
                    time.sleep(1)

                pyautogui.press("enter")
                time.sleep(8)

                result = self.detect_collecting_data()

                self.log(f"{name} Collecting Data", result)

        except Exception as e:
            self.log("Dropdown Verification", False, str(e))

    # ---------------- Main Flow ----------------
    def run_test(self):

        print("\nSTARTING HP AUTOMATION")
        print("=" * 60)

        if not self.reset_hp_application():
            return

        if not self.open_hp_application():
            return

        if not self.connect_to_application():
            return

        if not self.navigate_to_pc_device():
            return

        if not self.navigate_to_Energy_consumption():
            return

        self.verify_collecting_data()

        print("\nTEST EXECUTION COMPLETED")
        print("=" * 60)


if __name__ == "__main__":

    hp = MyHP()

    hp.run_test()