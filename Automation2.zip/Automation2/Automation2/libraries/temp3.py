import time
import pyautogui
import pygetwindow as gw
from pywinauto import Application
import os
pyautogui.FAILSAFE = True   # keep safety
pyautogui.PAUSE = 1         # slow down actions


class MyHP:
    TIMEOUT = 10

    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"
        self.baseline_folder = r"C:\Testing\Automation2\Automation2\baseline"
        os.makedirs(self.baseline_folder, exist_ok=True)

    # ---------------- Logger ----------------
    def _log_result(self, test_name, status, message=""):
        result = "PASS" if status else "FAIL"
        print(f"[{result}] {test_name}: {message}")

    # ---------------- Open HP Application ----------------
    def open_hp_application(self):
        try:
            self.close_hp_application(force=True)
            time.sleep(2)
            pyautogui.press("winleft")
            time.sleep(1)
            pyautogui.write(self.app_title)
            time.sleep(1)
            pyautogui.press("enter")
            time.sleep(12)

            active_window = gw.getActiveWindow()
            if active_window and self.app_title in active_window.title:
                active_window.maximize()
                time.sleep(3)
                self._log_result("Open Application", True, active_window.title)
                return True

            self._log_result("Open Application", False, "Wrong window focused")
            return False

        except Exception as e:
            self._log_result("Open Application", False, str(e))
            return False

    # ---------------- Connect to HP Application ----------------
    def connect_to_application(self):
        try:
            self.application = Application(backend="uia").connect(title_re=self.app_title)
            self.main_window = self.application.window(title_re=self.app_title)
            self.main_window.wait("ready", timeout=self.TIMEOUT)
            self.main_window.set_focus()
            self._log_result("Connect to Application", True)
            return True
        except Exception as e:
            self._log_result("Connect to Application", False, str(e))
            return False

    # ---------------- Navigate to PC Device (Optional) ----------------
    def navigate_to_pc_device(self):
        try:
            self.main_window.set_focus()
            time.sleep(5)

            pc_device = self.main_window.child_window(
                auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname",
                control_type="Text"
            )

            if pc_device.exists(timeout=8):
                pc_device.click_input()
                time.sleep(6)
                self._log_result("Navigate to PC Device", True)
                return True

            self._log_result(
                "Navigate to PC Device",
                True,
                "PC Device page not present — continuing test"
            )
            return True

        except Exception as e:
            self._log_result("Navigate to PC Device", True, f"Skipped: {str(e)}")
            return True

    # ---------------- Verify Energy Consumption Card NOT Displayed ----------------
    def verify_energy_consumption_card_not_displayed(self):
        try:
            self.main_window.set_focus()
            time.sleep(3)

            energy_card = self.main_window.child_window(
                auto_id="PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard",
                control_type="Button"
            )

            # Scroll to make sure card is not hidden
            self.main_window.type_keys("{PGDN}")
            time.sleep(1)
            self.main_window.type_keys("{PGUP}")
            time.sleep(1)

            # If Energy Consumption card exists → FAIL
            if energy_card.exists(timeout=5):
                self._log_result(
                    "Verify Energy Consumption Card NOT Displayed",
                    False,
                    "Energy Consumption card is displayed (should NOT be shown)"
                )
                return False

            # If not found → PASS
            self._log_result(
                "Verify Energy Consumption Card NOT Displayed",
                True,
                "Energy Consumption card is not displayed as expected"
            )
            return True

        except Exception as e:
            self._log_result(
                "Verify Energy Consumption Card NOT Displayed",
                False,
                str(e)
            )
            return False

    # ---------------- Close HP Application ----------------
    def close_hp_application(self, force=False):
     try:
                self.main_window.set_focus()
                time.sleep(2)

                self.main_window.close()
                time.sleep(5)

                windows = gw.getWindowsWithTitle(self.app_title)
                if not windows:
                    self._log_result("Close HP Application", True, "HP app closed successfully")
                    return True

                pyautogui.hotkey("alt", "f4")
                time.sleep(5)

                windows = gw.getWindowsWithTitle(self.app_title)

                if not windows:
                 return True  # already closed

                for win in windows:
                 try:
                    win.activate()
                    time.sleep(1)
                    win.close()
                 except:
                    pass

                time.sleep(3)

                # If still open → force kill
                if force:
                 windows = gw.getWindowsWithTitle(self.app_title)
                if windows:
                    os.system("taskkill /f /im HP*.exe")

                time.sleep(3)

                windows = gw.getWindowsWithTitle(self.app_title)
                if not windows:
                    self._log_result("Close HP Application", True, "HP app closed using ALT+F4")
                    return True

                self._log_result("Close HP Application", False, "HP app still running")
                return False

     except Exception as e:
                self._log_result("Close HP Application", False, str(e))
                return False

    #------------------------capture full page screenshot---------------
    def capture_full_page_screenshot(self, save_file):
     try:
        print("[INFO] Capturing full page screenshot...")

        screenshots = []
        scroll_count = 5  # adjust based on page length
        pyautogui.moveTo(500, 500)  # keep mouse away from corner
        for i in range(scroll_count):
            img = pyautogui.screenshot()
            screenshots.append(img)

            pyautogui.scroll(-800)
            
            time.sleep(1)

        # Stitch images vertically
        widths, heights = zip(*(i.size for i in screenshots))
        total_height = sum(heights)
        max_width = max(widths)

        from PIL import Image

        final_img = Image.new('RGB', (max_width, total_height))

        y_offset = 0
        for img in screenshots:
            final_img.paste(img, (0, y_offset))
            y_offset += img.size[1]

        final_img.save(save_file)

        print(f"[INFO] Screenshot saved: {save_file}")
        self._log_result("Screenshot", True, save_file)

        # Scroll back to top
        pyautogui.scroll(5000)
        time.sleep(1)

     except Exception as e:
        self._log_result("Screenshot", False, str(e))    
        
     #---------------Select the color filters option in the settings-------------

    def apply_all_color_filters(self):
     try:
        print("\n[INFO] Opening Color Filters Settings...")

        os.system("start ms-settings:easeofaccess-colorfilter")
        time.sleep(5)

        settings_app = Application(backend="uia").connect(title_re="Settings")
        settings_window = settings_app.window(title_re="Settings")
        settings_window.wait("ready", timeout=10)
        settings_window.set_focus()
        time.sleep(2)
        pyautogui.press('Space')
        time.sleep(10)
        # Enable toggle
        print("[INFO] Enabling Color Filters...")
        toggle = settings_window.child_window(control_type="CheckBox", found_index=0)
        if toggle.exists():
            toggle.click_input()
            time.sleep(2)

        # Filter list
        filter_names = [
            "Red-green (green weak, deuteranopia)",
            "Red-green (red weak, protanopia)",
            "Blue-yellow (tritanopia)",
            "Grayscale",
            "Grayscale inverted",
            "Inverted"
        ]

        save_path = r"C:\Testing\Automation2\Automation2\baseline\color"
        os.makedirs(save_path, exist_ok=True)

        for index, name in enumerate(filter_names, start=1):
            try:
                print(f"\n[INFO] Selecting Filter {index}: {name}")

                option = settings_window.child_window(title=name, control_type="RadioButton")

                if not option.exists():
                    print(f"[WARN] Filter not found: {name}")
                    continue

                option.click_input()
                time.sleep(3)

                self._log_result("Color Filter Selection", True, name)

                # ---------------- RUN HP FLOW ----------------
                self.close_hp_application(force=True)
                if not self.open_hp_application():
                    continue

                if not self.connect_to_application():
                    continue

                if not self.navigate_to_pc_device():
                    continue
                if not self.verify_energy_consumption_card_not_displayed():
                    continue

                time.sleep(5)

                    # Capture full page screenshot
                filename = os.path.join(
                        save_path,
                        f"{name.replace(' ', '_').replace(',', '').replace('(', '').replace(')', '')}_{index}.png"
                    )

                self.capture_full_page_screenshot(filename)
                                       
                self.close_hp_application()

            except Exception as inner_e:
                print(f"[ERROR] Failed for filter {name}: {str(inner_e)}")

        settings_window.close()
        self._log_result("Apply Color Filters", True, "All filters tested with HP flow")
        return True

     except Exception as e:
        self._log_result("Apply Color Filters", False, str(e))
        return False  
    
    
    
    # ---------------- TC14: Energy Card Not Displayed ----------------
    def tc19_verify_energy_consumption_card_not_displayed(self):
        print("-" * 90)
        print("TC19:C51250983_Color_Filters_applied_Verify Energy Consumption page is displayed")
        print("-" * 90)


        if not self.apply_all_color_filters():
            return False

       # if not self.open_hp_application():
            return False

        #if not self.connect_to_application():
            return False

        # Optional step – never fails test
        #self.navigate_to_pc_device()

        #result = self.verify_energy_consumption_card_not_displayed()

        #self.close_hp_application()
        #return result

    
# ---------------- Run Test ----------------
if __name__ == "__main__":
    hp = MyHP()
    hp.tc19_verify_energy_consumption_card_not_displayed()
    print("-" * 110)
    print("TC19: Energy Consumption card is displayed usinng color filters")
    print("-" * 110)