import time
import pygetwindow as gw
from pywinauto import Application
import pyautogui
import re


class MyHP:
    TIMEOUT = 15

    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"

    # ---------------- Logger ----------------
    def _log_result(self, name, status, msg=""):
        print(f"[{'PASS' if status else 'FAIL'}] {name}: {msg}")

    # ---------------- Open App ----------------
    def open_hp_application(self):
        pyautogui.press("winleft")
        time.sleep(2)
        pyautogui.write(self.app_title)
        time.sleep(2)
        pyautogui.press("enter")
        time.sleep(8)

        win = gw.getActiveWindow()
        if win and self.app_title in win.title:
            win.maximize()
            time.sleep(5)
            self._log_result("Open Application", True)
            return True

        self._log_result("Open Application", False)
        return False

    # ---------------- Connect ----------------
    def connect_to_application(self):
        try:
            self.application = Application(backend="uia").connect(
                title_re=self.app_title
            )
            self.main_window = self.application.window(
                title_re=self.app_title
            )
            self.main_window.wait("visible", timeout=self.TIMEOUT)
            self._log_result("Connect to Application", True)
            return True
        except Exception as e:
            self._log_result("Connect to Application", False, str(e))
            return False

    # ---------------- Navigate ----------------
    def navigate_to_pc_device(self):
        try:
            pc = self.main_window.child_window(
                auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname",
                control_type="Text"
            )
            pc.wait("visible", timeout=10)
            pc.click_input()
            time.sleep(5)
            self._log_result("Navigate to PC Device", True)
            return True
        except Exception as e:
            self._log_result("Navigate to PC Device", False, str(e))
            return False

    def navigate_to_energy_consumption(self):
        try:
            self.main_window.type_keys("{PGDN}")
            time.sleep(3)

            energy = self.main_window.child_window(
                auto_id="PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard",
                control_type="Button"
            )
            energy.wait("visible", timeout=15)
            energy.click_input()
            time.sleep(8)

            self._log_result("Navigate to Energy Consumption", True)
            print("-" * 60)
            return True
        except Exception as e:
            self._log_result("Navigate to Energy Consumption", False, str(e))
            return False

    # ---------------- Scroll ----------------
    def scroll_to_total_energy_section(self):
        self.main_window.type_keys("{PGDN}")
        time.sleep(1)
        self.main_window.type_keys("{PGDN}")
        time.sleep(1)
        self.main_window.type_keys("{UP 12}")
        time.sleep(5)

    # ---------------- Title Validation ----------------
    def validate_total_energy_title(self):
        try:
            title = self.main_window.child_window(
                title="Total Energy Consumption",
                control_type="Text"
            )
            title.wait("visible", timeout=10)
            self._log_result("Validate Title - Total Energy Consumption", True)
            return True
        except Exception as e:
            self._log_result("Validate Title - Total Energy Consumption", False, str(e))
            return False

    # ---------------- Dropdown Validation ----------------
    def validate_dropdown(self):
        try:
            dropdown = self.main_window.child_window(control_type="ComboBox")
            dropdown.wait("visible", timeout=10)

            selected = dropdown.window_text().strip()

            dropdown.expand()
            time.sleep(2)

            options = [
                item.window_text().strip()
                for item in self.main_window.descendants(control_type="ListItem")
                if item.window_text().strip()
            ]

            dropdown.collapse()

            if "Last Month" in options and "Last Week" in options:
                self._log_result(
                    "Dropdown Options Validation",
                    True,
                    "Last Month & Last Week present"
                )
            else:
                self._log_result("Dropdown Options Validation", False)
                return False

            if selected == "Last Week":
                self._log_result(
                    "Default Dropdown Validation",
                    True,
                    "Default is Last Week"
                )
            else:
                self._log_result(
                    "Default Dropdown Validation",
                    False,
                    f"Default is {selected}"
                )
                return False

            return True

        except Exception as e:
            self._log_result("Dropdown Validation", False, str(e))
            return False

    # ---------------- Click Link ----------------
    def click_link_by_keyword(self, keyword, display_name):
        for ctrl in self.main_window.descendants():
            info = ctrl.element_info
            if info.control_type in ("Button", "Hyperlink"):
                if keyword.lower() in (info.name or "").lower():
                    ctrl.click_input()
                    time.sleep(5)
                    self._log_result(display_name, True)
                    return True
        self._log_result(display_name, False)
        return False

    # ---------------- Extract Applications ----------------
    def extract_applications(self):
        percent_pattern = re.compile(r"^\d+%$")
        raw_text = [
            t.window_text().strip()
            for t in self.main_window.descendants(control_type="Text")
            if t.window_text().strip()
        ]

        apps = []
        seen = set()

        i = 0
        while i < len(raw_text) - 1:
            current = raw_text[i]
            next_text = raw_text[i + 1]

            if percent_pattern.match(next_text):
                key = (current, next_text)
                if key not in seen:
                    seen.add(key)
                    apps.append({"app": current, "energy": next_text})
                i += 2
            else:
                i += 1

        return apps

    # ---------------- Show More Validation ----------------
    def validate_after_show_more(self):
        apps = self.extract_applications()

        print("\nTop Energy Consuming Applications")
        print("-" * 60)

        for idx, app in enumerate(apps, 1):
            print(f"{idx}. {app['app']}  -->  {app['energy']}")

        print("-" * 60)

        total = len(apps)

        self._log_result(
            "Applications displayed after clicking show more link:",
            True,
            f"{total} applications displayed"
        )

        if total <= 20:
            self._log_result(
                "Application Count Validation",
                True,
                f"{total} within limit ≤ 20"
            )
            return True
        else:
            self._log_result(
                "Application Count Validation",
                False,
                f"{total} exceeds limit"
            )
            return False

    # ---------------- Show Less Validation ----------------
    def validate_after_show_less(self):
        apps = self.extract_applications()
        total = len(apps)

        print("\nTop 5 Energy Consuming Applications (After Show Less)")
        print("-" * 60)

        for idx, app in enumerate(apps, 1):
            print(f"{idx}. {app['app']}  -->  {app['energy']}")

        print("-" * 60)

        if total <= 5:
            self._log_result(
                "Show Less Validation",
                True,
                f"{total} applications displayed (≤ 5)"
            )
            return True
        else:
            self._log_result(
                "Show Less Validation",
                False,
                f"{total} applications displayed (> 5)"
            )
            return False

    # ---------------- Main Test Case ----------------
    def tc19_total_energy_consumption_UI_val(self):

        print("\nTC# 19: Total Energy Consumption - UI validation")
        print("-" * 60)

        if not self.open_hp_application():
            return False
        if not self.connect_to_application():
            return False
        if not self.navigate_to_pc_device():
            return False
        if not self.navigate_to_energy_consumption():
            return False

        self.scroll_to_total_energy_section()

        print("-" * 60)

        if not self.validate_total_energy_title():
            return False
        if not self.validate_dropdown():
            return False

        self._log_result("Show More Button Display Validation", True)

        if not self.click_link_by_keyword("Show more", "Show More Click"):
            return False

        if not self.validate_after_show_more():
            return False

        self.main_window.type_keys("{PGDN}")
        time.sleep(1)
        self.main_window.type_keys("{PGDN}")
        time.sleep(2)

        if not self.click_link_by_keyword("Show less", "Show Less Click"):
            return False

        self.main_window.type_keys("{PGUP}")
        time.sleep(3)

        if not self.validate_after_show_less():
            return False

        self.close_hp_application()
        return True

    # ---------------- Close ----------------
    def close_hp_application(self):
        try:
            self.main_window.close()
            time.sleep(3)
        except Exception:
            pyautogui.hotkey("alt", "f4")

        self._log_result("Close Application", True)
        return True


# ===================== MAIN =====================
if __name__ == "__main__":
    hp = MyHP()
    hp.tc19_total_energy_consumption_UI_val()