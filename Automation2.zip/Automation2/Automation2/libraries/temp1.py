import time
import pyautogui
import pygetwindow as gw
from pywinauto import Application
import os
import cv2
from skimage.metrics import structural_similarity as ssim


class MyHP:
    TIMEOUT = 10

    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"

    # ---------------- Logger ----------------
    def log(self, name, status, msg=""):
        print(f"[{'PASS' if status else 'FAIL'}] {name}: {msg}")

    def _log_result(self, name, status, msg=""):
        print(f"[{'PASS' if status else 'FAIL'}] {name}: {msg}")

    def _log_debug(self, msg):
        print(f"[DEBUG] {msg}")

    # ---------------- COLOR FILTER SETTINGS ----------------
    def open_color_filters_settings(self):
        try:
            self._log_debug("Opening Settings")

            pyautogui.press('win')
            time.sleep(1)
            pyautogui.write('Settings')
            pyautogui.press('enter')
            time.sleep(5)

            # Accessibility
            for _ in range(10):
                pyautogui.press('tab')
            for _ in range(8):
                pyautogui.press('down')
            pyautogui.press('enter')
            time.sleep(3)

            # Color Filters
            for _ in range(10):
                pyautogui.press('tab')
            for _ in range(6):
                pyautogui.press('down')
            pyautogui.press('enter')
            time.sleep(3)

            self._log_result("Open Color Filters", True)
            return True

        except Exception as e:
            self._log_result("Open Color Filters", False, str(e))
            return False

    def enable_color_filters(self):
        try:
            self._log_debug("Enable Color Filters")

            for _ in range(5):
                pyautogui.press('tab')

            pyautogui.press('space')
            time.sleep(2)

            self._log_result("Enable Color Filters", True)
            return True

        except Exception as e:
            self._log_result("Enable Color Filters", False, str(e))
            return False

    def apply_color_filters(self):
        try:
            self._log_debug("Apply Filters")

            for _ in range(3):
                pyautogui.press('tab')

            filters = [
                "Deuteranopia",
                "Protanopia",
                "Tritanopia",
                "Grayscale",
                "Grayscale Inverted",
                "Inverted"
            ]

            for f in filters:
                pyautogui.press('down')
                time.sleep(2)
                self._log_result("Filter Applied", True, f)

            return True

        except Exception as e:
            self._log_result("Apply Filters", False, str(e))
            return False

    def return_to_search(self):
        pyautogui.press('win')
        time.sleep(1)
        pyautogui.write("HP")
        time.sleep(1)

    # ---------------- APP FLOW ----------------
    def open_app(self):
        try:
            pyautogui.press('win')
            time.sleep(1)
            pyautogui.write(self.app_title)
            pyautogui.press('enter')
            time.sleep(10)

            win = gw.getActiveWindow()
            if win:
                win.maximize()

            self.log("Launch HP App", True)
            return True

        except Exception as e:
            self.log("Launch HP App", False, str(e))
            return False

    def connect(self):
        try:
            self.application = Application(backend="uia").connect(title_re=self.app_title)
            self.main_window = self.application.window(title_re=self.app_title)
            self.main_window.wait("ready", timeout=self.TIMEOUT)
            self.log("Connect App", True)
            return True
        except Exception as e:
            self.log("Connect App", False, str(e))
            return False

    def go_to_pc(self):
        try:
            pc = self.main_window.child_window(
                auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname",
                control_type="Text"
            )
            pc.click_input()
            time.sleep(5)
            self.log("Navigate PC", True)
            return True

        except Exception as e:
            self.log("Navigate PC", False, str(e))
            return False

    def open_energy(self):
        try:
            self.main_window.set_focus()
            self.main_window.type_keys("{PGDN}")
            time.sleep(2)

            btn = self.main_window.child_window(
                auto_id="PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard",
                control_type="Button"
            )

            btn.click_input()
            time.sleep(8)

            self.log("Open Energy Page", True)
            return True

        except Exception as e:
            self.log("Open Energy Page", False, str(e))
            return False

    # ---------------- SCREENSHOT ----------------
    def capture_energy_screenshot(self, name):
        try:
            folder = r"C:\Testing\Automation2\Screens"
            os.makedirs(folder, exist_ok=True)

            path = os.path.join(folder, f"{name}.png")
            pyautogui.screenshot().save(path)

            self._log_result("Screenshot", True, path)
            return True

        except Exception as e:
            self._log_result("Screenshot", False, str(e))
            return False

    # ---------------- TEST FLOW ----------------
    def run_full_test(self):
        try:
            print("\n===== COLOR FILTER TEST START =====\n")

            if not self.open_color_filters_settings(): return False
            if not self.enable_color_filters(): return False
            if not self.apply_color_filters(): return False
            self.return_to_search()

            if not self.open_app(): return False
            if not self.connect(): return False
            if not self.go_to_pc(): return False
            if not self.open_energy(): return False

            if not self.capture_energy_screenshot("CF_1"): return False
            self.main_window.type_keys("{PGDN}")
            if not self.capture_energy_screenshot("CF_2"): return False

            self.main_window.close()

            print("\n===== TEST COMPLETED SUCCESSFULLY =====\n")
            return True

        except Exception as e:
            self._log_result("Execution", False, str(e))
            return False


# ---------------- RUN ----------------
if __name__ == "__main__":
    result = MyHP().run_full_test()
    print("\nFINAL RESULT:", "PASS" if result else "FAIL")