import time
import pyautogui
import pygetwindow as gw
from pywinauto import Application
import winreg
import pyperclip


class MyHP:
    TIMEOUT = 10

    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"

    # ---------------- Logger ----------------
    def log(self, name, status, msg=""):
        print(f"[{'PASS' if status else 'FAIL'}] {name}: {msg}")

    def _log_result(self, name, status, msg=""):
        print(f"[{'PASS' if status else 'FAIL'}] {name}: {msg}")

    # ---------------- Theme (Dark/Light) ----------------
    def set_theme(self, dark=True):
        try:
            path = r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize"
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, path, 0, winreg.KEY_SET_VALUE)

            value = 0 if dark else 1
            winreg.SetValueEx(key, "AppsUseLightTheme", 0, winreg.REG_DWORD, value)
            winreg.SetValueEx(key, "SystemUsesLightTheme", 0, winreg.REG_DWORD, value)

            winreg.CloseKey(key)
            time.sleep(5)

     
            mode = "Dark" if dark else "Light"
            self.log(f"{mode} Mode Applied", True)
            return True

        except Exception as e:
            self.log("Theme Change", False, str(e))
            return False

    # ---------------- Contrast Theme ----------------
    def apply_contrast_theme(self, theme_name):
     try:
        theme_index = {
                     
            "Aquatic": 1,
            "Desert": 2,
            "Dusk": 3,
            "Night sky": 4,
            "None" :5 
                    }

        # Open contrast theme page
        pyautogui.hotkey('win', 'r')
        time.sleep(1)
        pyautogui.write("ms-settings:easeofaccess-highcontrast")
        pyautogui.press('enter')
        time.sleep(6)

        # Focus dropdown (TAB navigation)
        for _ in range(4):
            pyautogui.press('tab')
            time.sleep(1)

        # Open dropdown
        pyautogui.press('enter')
        time.sleep(2)

        # Move to correct theme
        for _ in range(theme_index[theme_name]):
            pyautogui.press('down')
            time.sleep(0.5)
           # if(theme_index[4]): pyautogui.press('Home')
        pyautogui.press('enter')
        time.sleep(2)

        # Apply button
        pyautogui.press('tab')
        time.sleep(1)
        pyautogui.press('enter')

        time.sleep(10)

        self.log("Contrast Theme Applied", True, theme_name)

        # Close settings
        pyautogui.hotkey('alt', 'f4')

        return True

     except Exception as e:
        self.log("Contrast Theme", False, str(e))
        return False
    # ---------------- Open App ----------------
    def open_app(self):
        try:
            pyautogui.press('win')
            time.sleep(1)
            pyautogui.write(self.app_title)
            time.sleep(1)
            pyautogui.press('enter')
            time.sleep(10)

            win = gw.getActiveWindow()
            if win and self.app_title in win.title:
                win.maximize()
                time.sleep(5)
                self.log("Launch HP App", True)
                return True

            self.log("Launch HP App", False)
            return False

        except Exception as e:
            self.log("Launch HP App", False, str(e))
            return False

    # ---------------- Connect ----------------
    def connect(self):
        try:
            self.application = Application(backend="uia").connect(title_re=self.app_title)
            self.main_window = self.application.window(title_re=self.app_title)
            self.main_window.wait("ready", timeout=self.TIMEOUT)
            self.log("Connect App", True)
            return True
        except Exception as e:
            self.log("Connect App", False, str(e))
            return False

    # ---------------- Navigate PC ----------------
    def go_to_pc(self):
        try:
            pc = self.main_window.child_window(
                auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname",
                control_type="Text"
            )

            if pc.exists(timeout=5):
                pc.click_input()
                time.sleep(5)
                self.log("Navigate PC", True)
                return True

            self.log("Navigate PC", False)
            return False

        except Exception as e:
            self.log("Navigate PC", False, str(e))
            return False

    # ---------------- Energy Page ----------------
    def open_energy(self):
        try:
            self.main_window.set_focus()

            self.main_window.type_keys("{PGDN}")
            time.sleep(1)
            self.main_window.type_keys("{UP}")
            time.sleep(1)

            btn = self.main_window.child_window(
                auto_id="PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard",
                control_type="Button"
            )

            if btn.exists(timeout=8):
                btn.click_input()
                time.sleep(8)
                self.log("Open Energy Page", True)
                return True

            self.log("Open Energy Page", False)
            return False

        except Exception as e:
            self.log("Open Energy Page", False, str(e))
            return False

    # ---------------- Dropdown ----------------
    def select_dropdown(self, text):
        try:
            dropdown = self.main_window.child_window(control_type="ComboBox")
            dropdown.click_input()
            time.sleep(1)

            item = self.main_window.child_window(title=text, control_type="ListItem")

            if item.exists(timeout=5):
                item.click_input()
                time.sleep(2)
                self.log("Dropdown", True, text)
                return True

            self.log("Dropdown", False, text)
            return False

        except Exception as e:
            self.log("Dropdown", False, str(e))
            return False

    # ---------------- Dropdown Stability ----------------
    def dropdown_test(self):
        options = ["Last 12 hours", "Last 6 days", "Last 6 months"]

        for i in range(2):
            print(f"\nIteration {i+1}")
            for j in range(len(options)):
                curr = options[j]
                nxt = options[(j + 1) % len(options)]

                if not self.select_dropdown(curr): return False
                if not self.select_dropdown(nxt): return False

                if not self.main_window.exists(timeout=3):
                    self.log("App Crash", False)
                    return False

                self.log("Switch OK", True, f"{curr} → {nxt}")

        return True

    # ---------------- Total Energy ----------------
    def scroll_to_total_energy_section(self):
        self._log_result("Scroll Total Energy", True)
        self.main_window.type_keys("{PGDN}")
        time.sleep(5)

    def select_total_energy_value(self, option_text):
        try:
            dropdown = self.main_window.child_window(control_type="ComboBox")
            dropdown.click_input()
            time.sleep(2)

            item = self.main_window.child_window(title=option_text, control_type="ListItem")
            item.click_input()
            time.sleep(3)

            self._log_result("Total Energy Dropdown", True, option_text)
            return True

        except Exception as e:
            self._log_result("Total Energy Dropdown", False, str(e))
            return False

    def verify_energy_page_not_crashed(self):
        try:
            if self.main_window.exists(timeout=2):
                self._log_result("Crash Check", True)
                return True
            return False
        except:
            return False

    def total_energy_test(self):
        self.scroll_to_total_energy_section()

        for i in range(2):
            if not self.select_total_energy_value("Last Week"): return False
            if not self.verify_energy_page_not_crashed(): return False

            if not self.select_total_energy_value("Last Month"): return False
            if not self.verify_energy_page_not_crashed(): return False

        return True

    # ---------------- Close ----------------
    def close(self):
        try:
            self.main_window.close()
            time.sleep(3)
            self.log("Close App", True)
        except:
            pyautogui.hotkey('alt', 'f4')
            self.log("Close App", True)

    # ---------------- HP FLOW ----------------
    def run_hp_flow(self):
        if not self.open_app(): return False
        if not self.connect(): return False
        if not self.go_to_pc(): return False
        if not self.open_energy(): return False
        if not self.dropdown_test(): return False
        if not self.total_energy_test(): return False
        self.close()
        return True

    # ---------------- MAIN TEST ----------------
    def run_test(self):
        print("\n========= FULL AUTOMATION STARTED =========\n")

        # DARK MODE
       # if not self.set_theme(True): return
        #if not self.run_hp_flow(): return

        # LIGHT MODE
        #if not self.set_theme(False): return
        #if not self.run_hp_flow(): return

        # CONTRAST THEMES
        themes = ["Aquatic", "Desert", "Dusk", "Night sky"]

        for theme in themes:
            print(f"\n🎨 Applying Theme: {theme}")
            if not self.apply_contrast_theme(theme): return
            if not self.run_hp_flow(): return

        print("\n✅ ALL TESTS COMPLETED SUCCESSFULLY")


# ---------------- RUN ----------------
if __name__ == "__main__":
    MyHP().run_test()