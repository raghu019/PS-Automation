import time
import pyautogui
import pygetwindow as gw
from pywinauto import Application
import os
import subprocess
import json
from datetime import datetime, timedelta
from collections import defaultdict
import shutil
import re
import numpy as np


class MyHP:
    TIMEOUT = 10

    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"

        self.pcm_folder = r"C:\ProgramData\HP\TelemetryDataCollector\PCMCollector"
        self.baseline_folder = r"C:\Testing\Automation2\Automation2\baseline"

    # ---------------------------------------------------
    # Logger
    # ---------------------------------------------------
    def _log(self, msg):
        print(msg)

    def _log_result(self, name, status, msg=""):
        print(f"[{'PASS' if status else 'FAIL'}] {name}: {msg}")

    # ---------------------------------------------------
    # STEP 1 – Decrypt PCM using exe
    # ---------------------------------------------------
    def decrypt_pcm(self):
        try:
            today = datetime.now().strftime("%Y-%m-%d")
            encrypted = f"PcmSampleData_{today}.json"
            exe_path = os.path.join(self.pcm_folder, "TouchpointCrypter_v2.0.exe")

            if not os.path.exists(os.path.join(self.pcm_folder, encrypted)):
                self._log_result("Decrypt PCM", False, "Encrypted file not found")
                return False

            self._log("[INFO] Running TouchpointCrypter...")
            result = subprocess.run(
                [exe_path, encrypted],
                cwd=self.pcm_folder,
                capture_output=True,
                text=True
            )

            if result.returncode != 0:
                self._log_result("Decrypt PCM", False, result.stderr)
                return False

            time.sleep(3)

            # Detect decrypted file
            decrypted_name = f"unencrypt-PcmSampleData_{today}.json"
            decrypted_path = os.path.join(self.pcm_folder, decrypted_name)

            if not os.path.exists(decrypted_path):
                self._log_result("Decrypt PCM", False, "Decrypted file not generated")
                return False

            self._log_result("Decrypt PCM", True, "Decrypted successfully")
            return decrypted_path

        except Exception as e:
            self._log_result("Decrypt PCM", False, str(e))
            return False

    # ---------------------------------------------------
    # STEP 2 – Copy decrypted file to baseline
    # ---------------------------------------------------
    def copy_to_baseline(self, decrypted_path):
        try:
            if not os.path.exists(self.baseline_folder):
                os.makedirs(self.baseline_folder)

            destination = os.path.join(
                self.baseline_folder,
                os.path.basename(decrypted_path)
            )

            shutil.copy2(decrypted_path, destination)

            if os.path.exists(destination):
                self._log_result("Copy JSON", True, "Copied to baseline")
                return destination

            self._log_result("Copy JSON", False, "Copy failed")
            return False

        except Exception as e:
            self._log_result("Copy JSON", False, str(e))
            return False

    # ---------------------------------------------------
    # STEP 3 – Load JSON
    # ---------------------------------------------------
    def load_json(self, path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)

            self._log_result("Load JSON", True, "Loaded from baseline")
            return data
        except Exception as e:
            self._log_result("Load JSON", False, str(e))
            return None

    # ---------------------------------------------------
    # STEP 4 – Calculate Last 12 Hours Average
    # ---------------------------------------------------
    def calculate_last_12_hours(self, data):
        try:
            extracted = []

            def flatten(obj):
                if isinstance(obj, dict):
                    for v in obj.values():
                        flatten(v)
                elif isinstance(obj, list):
                    for i in obj:
                        flatten(i)
                else:
                    extracted.append(obj)

            flatten(data)

            datetime_pattern = re.compile(r"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}")

            timestamps = []
            numbers = []

            for item in extracted:
                if isinstance(item, str) and datetime_pattern.search(item):
                    timestamps.append(item)
                try:
                    numbers.append(float(item))
                except:
                    pass

            records = []
            for ts, val in zip(timestamps, numbers):
                try:
                    dt = datetime.fromisoformat(ts.replace("Z", "").replace("T", " "))
                    records.append((dt, val))
                except:
                    continue

            if len(records) < 2:
                self._log_result("Compare 12H", False, "Not enough data")
                return False

            records.sort()

            hourly_values = defaultdict(list)

            prev_time, prev_val = records[0]

            for curr_time, curr_val in records[1:]:
                diff = max(curr_val - prev_val, 0)
                hour_key = curr_time.replace(minute=0, second=0, microsecond=0)
                hourly_values[hour_key].append(diff)
                prev_time, prev_val = curr_time, curr_val

            hourly_avg = {}
            for h, diffs in hourly_values.items():
                hourly_avg[h] = sum(diffs) / len(diffs) if diffs else 0

            now = datetime.now()
            end_hour = now.replace(minute=0, second=0, microsecond=0) - timedelta(hours=1)
            start_hour = end_hour - timedelta(hours=11)

            print("\n========================================")
            print("LAST 12 COMPLETED HOURS ENERGY DATA")
            print("========================================")

            current = start_hour
            while current <= end_hour:
                value = round(hourly_avg.get(current, 0.0), 2)
                print(f"{current.strftime('%I %p').lstrip('0')} : {value} Wh")
                current += timedelta(hours=1)

            print("========================================\n")

            self._log_result("Compare 12H", True, "Data calculated successfully")
            return [round(hourly_avg.get(start_hour + timedelta(hours=i), 2), 2) for i in range(12)]

        except Exception as e:
            self._log_result("Compare 12H", False, str(e))
            return False

# ---------------- Open HP ----------------
    def open_hp_application(self):
        try:
            pyautogui.press('winleft')
            time.sleep(1)
            pyautogui.write(self.app_title)
            time.sleep(1)
            pyautogui.press('enter')
            time.sleep(8)

            active_window = gw.getActiveWindow()
            if active_window and self.app_title in active_window.title:
                active_window.maximize()
                time.sleep(10)
                self._log_result("Open Application", True)
                return True

            self._log_result("Open Application", False, "HP not opened")
            return False

        except Exception as e:
            self._log_result("Open Application", False, str(e))
            return False

    # ---------------- Connect ----------------
    def connect_to_application(self):
        try:
            active_window = gw.getActiveWindow()
            pid = active_window._hWnd
            self.application = Application(backend="uia").connect(handle=pid)
            self.main_window = self.application.window(handle=pid)
            self.main_window.wait("ready", timeout=self.TIMEOUT)
            self._log_result("Connect", True)
            return True
        except Exception as e:
            self._log_result("Connect", False, str(e))
            return False

    # ---------------- Navigate to PC Device ----------------
    def navigate_to_pc_device(self):
        try:
            pc_device = self.main_window.child_window(
                auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname",
                control_type="Text"
            )
            if pc_device.exists(timeout=5):
                pc_device.click_input()
                time.sleep(5)
                self._log_result("Navigate to PC Device", True)
                return True
            self._log_result("Navigate to PC Device", False, "PC device not found")
            return True
        except Exception as e:
            self._log_result("Navigate to PC Device", False, str(e))
            return False

    
    # ---------------- Navigate to Energy Consumption ----------------
    def navigate_to_Energy_consumption(self):
        print("\nTEST CASE 1: Navigate to Energy Consumption module")
        print("-" * 60)

        if not self.main_window:
            self._log_result("Navigate to Energy consumption", False, "Application not connected")
            print("Test case 'Navigate to Energy consumption' completed : FAIL")
            print("-" * 60)
            return False

        try:
            self.main_window.set_focus()
            time.sleep(5)

            energy_btn = self.main_window.child_window(
                auto_id="PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard",
                control_type="Button"
            )

            self.main_window.type_keys("{PGDN}")
            time.sleep(1)
            self.main_window.type_keys("{UP}")
            time.sleep(0.5)
            self.main_window.type_keys("{UP}")
            time.sleep(4)

            if energy_btn.exists(timeout=8):
                energy_btn.click_input()
                time.sleep(10)
                self._log_result("Navigate to Energy consumption", True)
                print("-" * 60)
                return True

            self._log_result(
                "Navigate to Energy consumption page",
                False,
                "Energy consumption card not visible after PGDN + UP UP"
            )
            print("-" * 60)
            return False
        except Exception as e:
            self._log_result("Navigate to Energy consumption page", False, str(e))
            print("-" * 60)
            return False

    # ---------------- Select Dropdown ----------------
    def select_last_12_hours(self):
        try:
            dropdown = self.main_window.child_window(control_type="ComboBox")
            dropdown.click_input()
            time.sleep(1)

            option = self.main_window.child_window(
                title="Last 12 hours",
                control_type="ListItem"
            )

            option.click_input()
            time.sleep(5)

            self._log_result("Select Dropdown", True, "Last 12 hours")
            return True

        except Exception as e:
            self._log_result("Select Dropdown", False, str(e))
            return False

# ---------------- Capture Chart Data From UI ----------------

    def capture_chart_data(self):
     try:
        self._log("[INFO] Capturing chart data...")

        # Capture full window
        rect = self.main_window.rectangle()

        screenshot = pyautogui.screenshot(region=(
            rect.left,
            rect.top,
            rect.width(),
            rect.height()
        ))

        width, height = screenshot.size
        pixels = screenshot.load()

        # ---- Crop only middle chart region ----
        top_crop = int(height * 0.45)
        bottom_crop = int(height * 0.80)
        left_crop = int(width * 0.10)
        right_crop = int(width * 0.95)

        chart_width = right_crop - left_crop
        chart_height = bottom_crop - top_crop

        values = []

        step = int(chart_width / 12)

        for i in range(12):

            x = left_crop + (i * step) + int(step / 2)

            detected_y = None

            for y in range(top_crop, bottom_crop):

                r, g, b = pixels[x, y]

                # Detect strong HP blue
                if b > 150 and r < 100 and g < 150:
                    detected_y = y
                    break

            if detected_y is None:
                values.append(0.0)
                continue

            # Convert pixel height to Wh (0–32 scale)
            normalized = 1 - ((detected_y - top_crop) / chart_height)
            wh_value = round(normalized * 32, 2)

            if wh_value < 0.5:
                wh_value = 0.0

            values.append(wh_value)

        self._log_result("Capture Chart", True, "Chart data extracted")
        return values

     except Exception as e:
        self._log_result("Capture Chart", False, str(e))
        return None


      # ---------------- Close HP Application ----------------
    def close_hp_application(self):
     try:
        if self.main_window:
            try:
                self.main_window.set_focus()
                time.sleep(1)
                self.main_window.type_keys("%{F4}")  # ALT+F4 using pywinauto
                time.sleep(3)
                self._log_result("Close Application", True, "Closed")
                return True
            except:
                pass

        # Fallback using taskkill (most stable)
        subprocess.run("taskkill /f /im HP*.exe", shell=True)
        time.sleep(2)
        self._log_result("Close Application", True, "Closed using taskkill")
        return True

     except Exception as e:
        self._log_result("Close Application", False, str(e))
        return False



    # ---------------------------------------------------
    # MAIN FLOW
    # ---------------------------------------------------
    def run_test(self):
        print("\nTEST CASE: Last 12 Hours Validation")
        print("-" * 60)

        decrypted = self.decrypt_pcm()
        if not decrypted:
            return

        copied = self.copy_to_baseline(decrypted)
        if not copied:
            return

        data = self.load_json(copied)
        if not data:
            return
        
        self.open_hp_application()
        self.connect_to_application()
        self.navigate_to_pc_device()
        self.navigate_to_Energy_consumption()
        self.select_last_12_hours()

        json_values = self.calculate_last_12_hours(data)

        ui_values = self.capture_chart_data()

        if json_values and ui_values:
            print("\nJSON Values:", json_values)
            print("UI Chart Values:", ui_values)

        self.close_hp_application()
        

if __name__ == "__main__":
    MyHP().run_test()