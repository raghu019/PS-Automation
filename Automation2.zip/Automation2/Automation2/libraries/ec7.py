import time
import pyautogui
import pygetwindow as gw
from pywinauto import Application
import os


class MyHP:
    TIMEOUT = 10

    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"
        self.baseline_folder = r"C:\Testing\Automation2\Automation2\baseline"
        os.makedirs(self.baseline_folder, exist_ok=True)

    # ---------------- Logger ----------------
    def _log_result(self, test_name, status, message=""):
        result = "PASS" if status else "FAIL"
        print(f"[{result}] {test_name}: {message}")

    # ---------------- Open HP Application ----------------
    def open_hp_application(self):
        try:
            pyautogui.press("winleft")
            time.sleep(1)
            pyautogui.write(self.app_title)
            time.sleep(1)
            pyautogui.press("enter")
            time.sleep(12)

            active_window = gw.getActiveWindow()
            if active_window and self.app_title in active_window.title:
                active_window.maximize()
                time.sleep(3)
                self._log_result("Open Application", True, active_window.title)
                return True

            self._log_result("Open Application", False, "Wrong window focused")
            return False

        except Exception as e:
            self._log_result("Open Application", False, str(e))
            return False

    # ---------------- Connect to HP Application ----------------
    def connect_to_application(self):
        try:
            self.application = Application(backend="uia").connect(title_re=self.app_title)
            self.main_window = self.application.window(title_re=self.app_title)
            self.main_window.wait("ready", timeout=self.TIMEOUT)
            self.main_window.set_focus()
            self._log_result("Connect to Application", True)
            return True
        except Exception as e:
            self._log_result("Connect to Application", False, str(e))
            return False

    # ---------------- Navigate to PC Device (Optional) ----------------
    def navigate_to_pc_device(self):
        try:
            self.main_window.set_focus()
            time.sleep(5)

            pc_device = self.main_window.child_window(
                auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname",
                control_type="Text"
            )

            if pc_device.exists(timeout=8):
                pc_device.click_input()
                time.sleep(6)
                self._log_result("Navigate to PC Device", True)
                return True

            self._log_result(
                "Navigate to PC Device",
                True,
                "PC Device page not present — continuing test"
            )
            return True

        except Exception as e:
            self._log_result("Navigate to PC Device", True, f"Skipped: {str(e)}")
            return True

    # ---------------- Verify Energy Consumption Card NOT Displayed ----------------
    def verify_energy_consumption_card_not_displayed(self):
        try:
            self.main_window.set_focus()
            time.sleep(3)

            energy_card = self.main_window.child_window(
                auto_id="PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard",
                control_type="Button"
            )

            # Scroll to make sure card is not hidden
            self.main_window.type_keys("{PGDN}")
            time.sleep(1)
            self.main_window.type_keys("{PGUP}")
            time.sleep(1)

            # If Energy Consumption card exists → FAIL
            if energy_card.exists(timeout=5):
                self._log_result(
                    "Verify Energy Consumption Card NOT Displayed",
                    False,
                    "Energy Consumption card is displayed (should NOT be shown)"
                )
                return False

            # If not found → PASS
            self._log_result(
                "Verify Energy Consumption Card NOT Displayed",
                True,
                "Energy Consumption card is not displayed as expected"
            )
            return True

        except Exception as e:
            self._log_result(
                "Verify Energy Consumption Card NOT Displayed",
                False,
                str(e)
            )
            return False

    # ---------------- Close HP Application ----------------
    def close_hp_application(self):
        try:
            self.main_window.set_focus()
            time.sleep(2)

            self.main_window.close()
            time.sleep(5)

            windows = gw.getWindowsWithTitle(self.app_title)
            if not windows:
                self._log_result("Close HP Application", True, "HP app closed successfully")
                return True

            pyautogui.hotkey("alt", "f4")
            time.sleep(5)

            windows = gw.getWindowsWithTitle(self.app_title)
            if not windows:
                self._log_result("Close HP Application", True, "HP app closed using ALT+F4")
                return True

            self._log_result("Close HP Application", False, "HP app still running")
            return False

        except Exception as e:
            self._log_result("Close HP Application", False, str(e))
            return False

    # ---------------- TC15: Energy Card Not Displayed ----------------
    def tc15_verify_energy_consumption_card_not_displayed(self):
        print("-" * 90)
        print("TC15: Verify Energy Consumption card is NOT displayed for supported BIOS/unsupported platform")
        print("-" * 90)

        if not self.open_hp_application():
            return False

        if not self.connect_to_application():
            return False

        # Optional step – never fails test
        self.navigate_to_pc_device()

        result = self.verify_energy_consumption_card_not_displayed()

        self.close_hp_application()
        return result


# ---------------- Run Test ----------------
if __name__ == "__main__":
    hp = MyHP()
    hp.tc15_verify_energy_consumption_card_not_displayed()
    print("-" * 110)
    print("TC15: Energy Consumption card should NOT be displayed for supported BIOS/unsupported platform - successfully executed")
    print("-" * 110)

