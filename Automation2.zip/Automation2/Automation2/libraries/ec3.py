import time
import pyautogui
import pygetwindow as gw
from pywinauto import Application
import pyperclip


class MyHP:
    TIMEOUT = 10

    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"

    # ---------------- Logger ----------------
    def _log_result(self, test_name, status, message=""):
        result = "PASS" if status else "FAIL"
        print(f"[{result}] {test_name}: {message}")

    # ---------------- Focus Browser Window ----------------
    def focus_browser_window(self):
        try:
            for w in gw.getAllWindows():
                title = w.title.lower()
                if any(k in title for k in [
                "hp",
                "sustainable",
                "pdf",
                "impact report",
                "chrome",
                "edge"
            ]):
                    w.activate()
                    time.sleep(2)
                    return True
            self._log_result("Focus Browser Window", False, "Browser window not found")
            return False
        except Exception as e:
            self._log_result("Focus Browser Window", False, str(e))
            return False

    # ---------------- Open HP Application ----------------
    def open_hp_application(self):
        try:
            pyautogui.press("winleft")
            time.sleep(1)
            pyautogui.write(self.app_title)
            pyautogui.press("enter")
            time.sleep(6)

            active_window = gw.getActiveWindow()
            if active_window and self.app_title in active_window.title:
                active_window.maximize()
                time.sleep(6)
                self._log_result("Open Application", True)
                return True

            self._log_result("Open Application", False, "Application window not active")
            return False
        except Exception as e:
            self._log_result("Open Application", False, str(e))
            return False

    # ---------------- Connect to HP Application ----------------
    def connect_to_application(self):
        try:
            self.application = Application(backend="uia").connect(title_re=self.app_title)
            self.main_window = self.application.window(title_re=self.app_title)
            self.main_window.wait("ready", timeout=self.TIMEOUT)
            self._log_result("Connect to Application", True)
            return True
        except Exception as e:
            self._log_result("Connect to Application", False, str(e))
            return False

    # ---------------- Navigate to PC Device ----------------
    def navigate_to_pc_device(self):
        try:
            pc_device = self.main_window.child_window(
                auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname",
                control_type="Text"
            )
            if pc_device.exists(timeout=5):
                pc_device.click_input()
                time.sleep(5)
                self._log_result("Navigate to PC Device", True)
                return True
            self._log_result("Navigate to PC Device", False, "PC device not found")
            return True
        except Exception as e:
            self._log_result("Navigate to PC Device", False, str(e))
            return False

    # ---------------- Navigate to Energy Consumption ----------------
    def navigate_to_Energy_consumption(self):
        try:
            print("\nTEST CASE 1: Navigate to Energy Consumption")
            print("-" * 60)

            self.main_window.set_focus()
            time.sleep(3)
            self.main_window.type_keys("{PGDN}")
            time.sleep(1)
            self.main_window.type_keys("{UP}{UP}")
            time.sleep(2)

            energy_btn = self.main_window.child_window(
                auto_id="PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard",
                control_type="Button"
            )

            if energy_btn.exists(timeout=8):
                energy_btn.click_input()
                time.sleep(8)
                self._log_result("Navigate to Energy Consumption", True)
                print("-" * 60)
                return True

            self._log_result("Navigate to Energy Consumption", False, "Energy button not found")
            print("-" * 60)
            return False
        except Exception as e:
            self._log_result("Navigate to Energy Consumption", False, str(e))
            return False

    # ---------------- Click Learn More Link ----------------
    def click_energy_links(self):
        try:
            print("\nTEST CASE 10: Click Learn more about Go Beyond")
            print("-" * 60)

            pyautogui.scroll(-600)
            time.sleep(2)

            link = self.main_window.child_window(
                title="Learn more about Go Beyond",
                control_type="Hyperlink"
            )

            if link.exists(timeout=self.TIMEOUT):
                link.click_input()
                time.sleep(10)
                self._log_result("Click Go Beyond Link", True)
                print("-" * 60)
                return True

            self._log_result("Click Go Beyond Link", False, "Link not found")
            print("-" * 60)
            return False
        except Exception as e:
            self._log_result("Click Go Beyond Link", False, str(e))
            return False

    # ---------------- Capture Browser URL ----------------
    def capture_browser_url(self, label):
        try:
            if not self.focus_browser_window():
                return None

            pyautogui.hotkey("ctrl", "l")
            time.sleep(1)
            pyautogui.hotkey("ctrl", "c")
            time.sleep(1)

            url = pyperclip.paste()
            if url.startswith("http"):
                print(f"[PASS] {label} URL:")
                print(f"       {url}")
                return url

            print(f"[FAIL] Unable to capture {label} URL")
            return None
        except Exception as e:
            print(f"[FAIL] {label} URL capture error: {e}")
            return None

    # ---------------- Click Download Report (TEXT BASED) ----------------
    def click_download_report_in_browser(self):
        try:
            print("\nTEST CASE 10: Click Download Report (TEXT BASED)")
            print("-" * 60)

            if not self.focus_browser_window():
                return False

            pyautogui.hotkey("ctrl", "f")
            time.sleep(1)
            pyautogui.write("Download Report", interval=0.05)
            time.sleep(1)
            pyautogui.press("enter")
            time.sleep(1)
            pyautogui.press("esc")  # Close Find bar
            time.sleep(1)
            pyautogui.press("enter")  # Click the focused button
            time.sleep(8)

            self._log_result("Click Download Report", True)
            print("-" * 60)
            return True
        except Exception as e:
            self._log_result("Click Download Report", False, str(e))
            return False

    # ---------------- Verify PDF Content (Using Ctrl+F) ----------------
    def verify_pdf_report_content(self):
        try:
            print("\nTEST CASE 10: Verify PDF Content")
            print("-" * 60)

            self.focus_browser_window()
            time.sleep(5)
            

            pyautogui.press("esc")
            time.sleep(1)
            pyautogui.hotkey("ctrl", "f")
            time.sleep(1)
            pyautogui.write("Sustainable Impact Report", interval=0.05)
            time.sleep(1)
            pyautogui.press("enter")
            time.sleep(2)
            pyautogui.press("esc")
            time.sleep(1)

            self._log_result("Verify PDF Content", True, "Text search executed in PDF")
            print("-" * 60)
            self._log_result("Verify PDF content", True, "PDF content verified")
            print("_" * 60)
            return True
        except Exception as e:
            self._log_result("Verify PDF Content", False, str(e))
            return False

    # ---------------- Close HP Application ----------------
    def close_hp_application(self):
        try:
            if self.main_window:
                self.main_window.close()
                time.sleep(2)
            self._log_result("Close Application", True)
            return True
        except Exception as e:
            self._log_result("Close Application", False, str(e))
            return False

    # ---------------- Run Test Suite ----------------
    def verify_go_beyound_sustainable_impact_report(self):
        try:
            if not self.open_hp_application():
                return False
            if not self.connect_to_application():
                return False
            if not self.navigate_to_pc_device():
                return False
            if not self.navigate_to_Energy_consumption():
                return False
            if not self.click_energy_links():
                return False
            self.capture_browser_url("HP Sustainable Impact Page")
            if not self.click_download_report_in_browser():
                return False
            self.capture_browser_url("PDF Document")
            if not self.verify_pdf_report_content():
                return False
            if not self.close_hp_application():
                return False
            return True
        except Exception as e:
            print(f"[ERROR] Test Suite failed: {e}")
            return False


if __name__ == "__main__":
    result = MyHP().verify_go_beyound_sustainable_impact_report()
    print("\nFINAL RESULT:", "PASS ✅" if result else "FAIL ❌")

