import time
import pygetwindow as gw
from pywinauto import Application
import pyautogui


class MyHP:
    TIMEOUT = 15

    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"

    # ---------------- Logger ----------------
    def _log_result(self, name, status, msg=""):
        print(f"[{'PASS' if status else 'FAIL'}] {name}: {msg}")

    # ---------------- Open App ----------------
    def open_hp_application(self):
        pyautogui.press("winleft")
        time.sleep(2)
        pyautogui.write(self.app_title)
        time.sleep(2)
        pyautogui.press("enter")
        time.sleep(8)

        win = gw.getActiveWindow()
        if win and self.app_title in win.title:
            win.maximize()
            time.sleep(6)
            self._log_result("Open Application", True)
            return True

        self._log_result("Open Application", False)
        return False

    # ---------------- Connect ----------------
    def connect_to_application(self):
        self.application = Application(backend="uia").connect(title_re=self.app_title)
        self.main_window = self.application.window(title_re=self.app_title)
        self.main_window.wait("visible", timeout=self.TIMEOUT)
        self._log_result("Connect to Application", True)
        return True

    # ---------------- Navigate to PC ----------------
    def navigate_to_pc_device(self):
        pc = self.main_window.child_window(
            auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname",
            control_type="Text"
        )
        pc.wait("visible", timeout=10)
        pc.click_input()
        time.sleep(5)
        self._log_result("Navigate to PC Device", True)
        return True

    # ---------------- Energy Page ----------------
    def navigate_to_energy_consumption(self):
        self.main_window.type_keys("{PGDN}")
        time.sleep(4)

        energy = self.main_window.child_window(
            auto_id="PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard",
            control_type="Button"
        )
        energy.wait("visible", timeout=15)
        energy.click_input()
        time.sleep(8)

        self._log_result("Navigate to Energy Consumption", True)
        print("-" * 60)
        return True

    # ---------------- Scroll ----------------
    def scroll_to_total_energy_section(self):
        self.main_window.type_keys("{PGDN}")
        time.sleep(1)
        self.main_window.type_keys("{PGDN}")
        time.sleep(1)
        self.main_window.type_keys("{UP 12}")
        time.sleep(6)

    # ---------------- Dropdown (LAST WEEK) ----------------
    def select_total_energy_value(self, option_text):
        try:
            dropdown = self.main_window.child_window(control_type="ComboBox")
            dropdown.wait("visible", timeout=10)
            dropdown.expand()
            time.sleep(2)

            option = self.main_window.child_window(
                title=option_text,
                control_type="ListItem"
            )
            option.wait("visible", timeout=10)
            option.click_input()
            time.sleep(5)

            self._log_result("Select Total Energy Dropdown", True, option_text)
            return True

        except Exception as e:
            self._log_result("Select Total Energy Dropdown", False, str(e))
            return False

    # ---------------- Show More ----------------
    def click_show_more(self):
        try:
            time.sleep(3)
            for ctrl in self.main_window.descendants():
                info = ctrl.element_info
                if info.control_type in ("Button", "Hyperlink"):
                    if "show" in (info.name or "").lower() or "show" in (info.automation_id or "").lower():
                        ctrl.click_input()
                        time.sleep(5)
                        self._log_result(
                            "Click Show more",
                            True,
                            f"auto_id={info.automation_id}"
                        )
                        return True

            self._log_result("Click Show more", False, "Not found")
            return False

        except Exception as e:
            self._log_result("Click Show more", False, str(e))
            return False

    # ---------------- UI DATA EXTRACTION ----------------
    def get_total_energy_applications_ui(self):
        apps = []

        text_controls = [
            t.window_text().strip()
            for t in self.main_window.descendants(control_type="Text")
            if t.window_text()
        ]

        names = [t for t in text_controls if "%" not in t]
        energies = [t for t in text_controls if "%" in t]

        for i in range(min(len(names), len(energies))):
            apps.append({
                "app": names[i],
                "energy": energies[i]
            })

        print("\nTOTAL ENERGY CONSUMPTION (UI DATA)")
        print("-" * 60)
        print(f"Total Applications Displayed: {len(apps)}\n")

        for idx, app in enumerate(apps, start=1):
            print(f"{idx}. {app['app']}  -->  {app['energy']}")

        print("-" * 60)

        self._log_result(
            "Application Count Displayed",
            True,
            f"{len(apps)} applications"
        )

        return apps

    # ---------------- Test Case ----------------
    def tc_display_total_energy_consumption_last_week(self):
        print("\nTEST CASE: Display Total Energy Consumption - Last Week")
        print("-" * 60)

        self.scroll_to_total_energy_section()

        if not self.select_total_energy_value("Last Week"):
            return False

        if not self.click_show_more():
            return False

        self.get_total_energy_applications_ui()

        self._log_result(
            "Total Energy Consumption Display",
            True,
            "UI data displayed successfully"
        )
        print("-" * 60)
        return True

    # ---------------- Close App ----------------
    def close_hp_application(self):
        try:
            self.main_window.close()
            time.sleep(3)
        except:
            pyautogui.hotkey("alt", "f4")

        self._log_result("Close Application", True)
        return True

    # ---------------- Runner ----------------
    def run_tc_total_energy_last_week(self):
        if not self.open_hp_application():
            return False
        if not self.connect_to_application():
            return False
        if not self.navigate_to_pc_device():
            return False
        if not self.navigate_to_energy_consumption():
            return False
        if not self.tc_display_total_energy_consumption_last_week():
            return False
        self.close_hp_application()
        return True


# ===================== MAIN =====================
if __name__ == "__main__":
    hp = MyHP()
    hp.run_tc_total_energy_last_week()

