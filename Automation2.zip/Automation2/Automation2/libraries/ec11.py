import time
import pyautogui
import pygetwindow as gw
from pywinauto import Application
import os
import sys
import io
from pywinauto.keyboard import send_keys
import pyperclip
import json
from datetime import datetime, timedelta
from collections import defaultdict
import ctypes
import ctypes.wintypes as wintypes

class MyHP:
    TIMEOUT = 5

    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"
        self.baseline_folder = r"C:\Testing\Automation2\Automation2\baseline"

    # ---------------- Logger ----------------
    def _log_result(self, test_name, status, message=""):
        result = "PASS" if status else "FAIL"
        print(f"[{result}] {test_name}: {message}")

    def _log_debug(self, message):
        print(f"[DEBUG] {message}")

    # ---------------- Open HP Application ----------------
    def open_hp_application(self):
        try:
            pyautogui.press('winleft')
            time.sleep(1)
            pyautogui.write(self.app_title)
            time.sleep(1)
            pyautogui.press('enter')
            time.sleep(5)

            active_window = gw.getActiveWindow()
            if active_window and self.app_title in active_window.title:
                active_window.maximize()
                time.sleep(15)
                self._log_result("Open Application", True)
                return True
            else:
                self._log_result("Open Application", False, "Wrong window focused")
                return False
        except Exception as e:
            self._log_result("Open Application", False, str(e))
            return False

    # ---------------- Connect to HP Application ----------------
    def connect_to_application(self):
        try:
            self.application = Application(backend="uia").connect(title_re=self.app_title)
            self.main_window = self.application.window(title_re=self.app_title)
            self.main_window.wait("ready", timeout=self.TIMEOUT)
            self._log_result("Connect to Application", True)
            return True
        except Exception as e:
            self._log_result("Connect to Application", False, str(e))
            return False

     # ---------------- Navigate to PC Device ----------------
    def navigate_to_pc_device(self):
        try:
            pc_device = self.main_window.child_window(
                auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname",
                control_type="Text"
            )
            if pc_device.exists(timeout=5):
                pc_device.click_input()
                time.sleep(5)
                self._log_result("Navigate to PC Device", True)
                return True
            self._log_result("Navigate to PC Device", False, "PC device not found")
            return True
        except Exception as e:
            self._log_result("Navigate to PC Device", False, str(e))
            return False

    # ---------------- Dump UI Tree ----------------
    def dump_ui_tree_to_file(self):
        if not self.main_window:
            self._log_result("Dump UI Tree", False, "Application not connected")
            return False
        try:
            dump_path = os.path.join(self.baseline_folder, "ui_dump.txt")
            with open(dump_path, "w", encoding="utf-8") as f:
                buffer = io.StringIO()
                sys.stdout = buffer
                self.main_window.print_control_identifiers()
                sys.stdout = sys.__stdout__
                f.write(buffer.getvalue())
                buffer.close()
            self._log_result("Dump UI Tree", True, f"Saved to {dump_path}")
            return True
        except Exception as e:
            sys.stdout = sys.__stdout__
            self._log_result("Dump UI Tree", False, str(e))
            return False

    # ---------------- Navigate to Energy Consumption ----------------
    def navigate_to_Energy_consumption(self):
        print("\nTEST CASE 1: Navigate to Energy Consumption module")
        print("-" * 60)

        if not self.main_window:
            self._log_result("Navigate to Energy consumption", False, "Application not connected")
            print("Test case 'Navigate to Energy consumption' completed : FAIL")
            print("-" * 60)
            return False

        try:
            self.main_window.set_focus()
            time.sleep(5)

            energy_btn = self.main_window.child_window(
                auto_id="PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard",
                control_type="Button"
            )

            self.main_window.type_keys("{PGDN}")
            time.sleep(1)
            self.main_window.type_keys("{UP}")
            time.sleep(0.5)
            self.main_window.type_keys("{UP}")
            time.sleep(4)

            if energy_btn.exists(timeout=8):
                energy_btn.click_input()
                time.sleep(10)
                self._log_result("Navigate to Energy consumption", True)
                print("-" * 60)
                return True

            self._log_result(
                "Navigate to Energy consumption page",
                False,
                "Energy consumption card not visible after PGDN + UP UP"
            )
            print("-" * 60)
            return False
        except Exception as e:
            self._log_result("Navigate to Energy consumption page", False, str(e))
            print("-" * 60)
            return False

    # ---------------- Close HP Application ----------------
    def close_hp_application(self):
        try:
            if self.main_window:
                self.main_window.set_focus()
                time.sleep(1)
                self.main_window.close()
                time.sleep(3)
                if not self.main_window.exists(timeout=3):
                    self._log_result("Close Application", True, "Closed using pywinauto")
                    return True

            hp_windows = gw.getWindowsWithTitle(self.app_title)
            if hp_windows:
                hp_windows[0].activate()
                time.sleep(1)
                pyautogui.hotkey('alt', 'f4')
                time.sleep(2)
                self._log_result("Close Application", True, "Closed using Alt+F4")
                return True

            self._log_result("Close Application", False, "HP window not found")
            return False
        except Exception as e:
            self._log_result("Close Application", False, str(e))
            return False

    # ---------------- Dropdown ----------------
    def select_consumption_dropdown(self, option_text):
        try:
            time.sleep(2)
            dropdown = self.main_window.child_window(
                title_re="Last.*hours|Last.*days|Last.*months",
                control_type="ComboBox"
            )
            dropdown.wait("ready", timeout=5)
            dropdown.click_input()
            time.sleep(1)

            list_item = self.main_window.child_window(
                title=option_text,
                control_type="ListItem"
            )
            if list_item.exists(timeout=5):
                list_item.click_input()
                time.sleep(3)
                self._log_result("Select Dropdown", True, option_text)
                return True

            self._log_result("Select Dropdown", False, f"{option_text} not found")
            return False
        except Exception as e:
            self._log_result("Select Dropdown", False, str(e))
            return False

    # ---------------- Verify Chart ----------------
    def verify_chart_displayed(self, option_text):
        try:
            chart_title = self.main_window.child_window(
                title="Daily average",
                control_type="Text"
            )
            if chart_title.exists(timeout=5):
                self._log_result("Verify Chart", True, option_text)
                return True
            self._log_result("Verify Chart", False, "Chart title missing")
            return False
        except Exception as e:
            self._log_result("Verify Chart", False, str(e))
            return False

    # ---------------- DPAPI Decrypt ----------------
    def decrypt_dpapi(self, blob: bytes):
        class DATA_BLOB(ctypes.Structure):
            _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.c_void_p)]

        CryptUnprotectData = ctypes.windll.crypt32.CryptUnprotectData
        in_buf = ctypes.create_string_buffer(blob)
        in_blob = DATA_BLOB(len(blob), ctypes.cast(in_buf, ctypes.c_void_p))
        out_blob = DATA_BLOB()

        if CryptUnprotectData(ctypes.byref(in_blob), None, None, None, None, 0,
                              ctypes.byref(out_blob)):
            result = ctypes.string_at(out_blob.pbData, out_blob.cbData)
            ctypes.windll.kernel32.LocalFree(out_blob.pbData)
            return result
        return None

    # ---------------- Load PCM Hourly ----------------
    def load_pcm_hourly_data(self):
        try:
            folder = r"C:\ProgramData\HP\TelemetryDataCollector\PCMCollector"
            files = [f for f in os.listdir(folder) if f.startswith("PcmSampleData_")]
            if not files:
                return {"Samples": []}
            files.sort(reverse=True)
            with open(os.path.join(folder, files[0]), "rb") as f:
                decrypted = self.decrypt_dpapi(f.read())
            return json.loads(decrypted.decode()) if decrypted else None
        except Exception as e:
            self._log_result("Load PCM Sample", False, str(e))
            return None

    # ---------------- Load PowerConsumption ----------------
    def load_power_consumption_data(self):
        try:
            path = r"C:\ProgramData\HP\TelemetryDataCollector\PCMCollector\PowerConsumption.json"
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            self._log_result("Load JSON", True, path)
            return data
        except Exception as e:
            self._log_result("Load JSON", False, str(e))
            return None
        
    # ---------------- Last 12 Hour Window (UI aligned) ----------------
    def _get_last_completed_12_hour_window(self):
        now = datetime.now()

        # Round down to current hour
        current_hour = now.replace(minute=0, second=0, microsecond=0)

        # Exclude current partial hour
        end_hour = current_hour - timedelta(hours=1)

        # Go back 11 more hours (total 12)
        start_hour = end_hour - timedelta(hours=11)

        

        return start_hour, end_hour


    # ---------------- Compare Chart ----------------
    def compare_chart_with_json(self, option_text, json_data):
     try:
        now = datetime.now()
        if option_text == "Last 12 hours":  # keeping same option name if UI uses it
            data = self.load_pcm_hourly_data()
            samples = data.get("Samples", []) if data else []

            # sample_dict = {}

            # for s in samples:
            #     try:
            #         sample_time = datetime.strptime(
            #             s["key"], "%Y-%m-%d %H:%M:%S"
            #         ).replace(minute=0, second=0, microsecond=0)

            #         sample_dict[sample_time] = s["value"]

            #     except Exception:
            #         continue
            
            hourly_data = defaultdict(float)

            for s in samples:
                try:
                    dt = datetime.strptime(s["key"], "%Y-%m-%d %H:%M:%S")
                    hour_key = dt.replace(minute=0, second=0, microsecond=0)

                    # accumulate samples per hour
                    hourly_data[hour_key] += float(s["value"])

                except Exception:
                    continue


            # # Last completed hour (exclude current hour)
            # end_hour = now.replace(
            #     minute=0, second=0, microsecond=0
            # ) - timedelta(hours=1)

            
            # start_hour = end_hour - timedelta(hours=12)
            # Get UI-aligned 12 hour window
            start_hour, end_hour = self._get_last_completed_12_hour_window()


            labels = []
            values = []

            current = start_hour
            while current <= end_hour:
                labels.append(current.strftime("%I %p"))
                values.append(round(hourly_data.get(current, 0.0), 2))
                current += timedelta(hours=1)

            self._log_result(
                "Compare Chart (12h)",
                True,
                f"Labels={labels} Values={values}"
            )

            return True

        # -------- Parse daily JSON --------
        parsed = {
            datetime.strptime(e["Key"], "%Y-%m-%d").date(): e["Value"]
            for e in json_data
        }

        

        # -------- Last 6 Days (exclude today) --------
        if option_text == "Last 6 days":
            end = (now - timedelta(days=1)).date()
            start = end - timedelta(days=5)

            labels = []
            values = []

            d = start
            while d <= end:
                labels.append(d.strftime("%a"))
                values.append(parsed.get(d, 0.0))
                d += timedelta(days=1)

            self._log_result(
                "Compare Chart (6d)",
                True,
                f"Labels={labels} Values={values}"
            )

            return True

        # -------- Last 6 Months --------
        if option_text == "Last 6 months":
            months = []
            year = now.year
            month = now.month

            for _ in range(6):
                months.append((year, month))
                month -= 1
                if month == 0:
                    month = 12
                    year -= 1

            months.reverse()

            monthly = defaultdict(float)

            for d, v in parsed.items():
                key = (d.year, d.month)
                if key in months:
                    monthly[key] += v

            labels = []
            values = []

            for y, m in months:
                labels.append(f"{y}-{m:02d}")
                values.append(round(monthly.get((y, m), 0.0), 2))

            self._log_result(
                "Compare Chart (6m)",
                True,
                f"Labels={labels} Values={values}"
            )
            return True

        return False

     except Exception as e:
        self._log_result("Compare Chart", False, str(e))
        return False




    # ---------------- Test Cases ----------------
    
    def verify_last_12_hours_chart(self):
        print("\nTEST CASE 6: Last 12 Hours – Verify & Compare Chart")
        print("-" * 60)
        if not self.select_consumption_dropdown("Last 12 hours"):
            return False
        if not self.verify_chart_displayed("Last 12 hours"):
            return False
        json_data = self.load_power_consumption_data()
        return self.compare_chart_with_json("Last 12 hours", json_data)

    def tc6_verify_last_6_days_chart(self):
        print("\nTEST CASE 7: Last 6 Days – Verify & Compare Chart")
        print("-" * 60)
        if not self.select_consumption_dropdown("Last 6 days"):
            return False
        if not self.verify_chart_displayed("Last 6 days"):
            return False
        json_data = self.load_power_consumption_data()
        return self.compare_chart_with_json("Last 6 days", json_data)

    def tc7_verify_last_6_months_chart(self):
        print("\nTEST CASE 8: Last 6 Months – Verify & Compare Chart")
        print("-" * 60)
        if not self.select_consumption_dropdown("Last 6 months"):
            return False
        if not self.verify_chart_displayed("Last 6 months"):
            return False
        json_data = self.load_power_consumption_data()
        return self.compare_chart_with_json("Last 6 months", json_data)

    # ---------------- Run Test Suite ----------------
    def tc5_verify_last_12_hours_chart(self):
        if not self.open_hp_application():
            return False
        if not self.connect_to_application():
            return False
        if not self.navigate_to_pc_device():
            return False
        if not self.navigate_to_Energy_consumption():
            return False
        if not self.verify_last_12_hours_chart():
            return False
        if not self.close_hp_application():
            return False
        return True


if __name__ == "__main__":
    hp_test = MyHP()
    hp_test.tc5_verify_last_12_hours_chart()
