from robot.api.deco import keyword
from ec1 import MyHP


# Initialize the HP automation class
hp = MyHP()

@keyword("Open HP Application")
def open_hp():
    """Open the HP desktop application."""
    if not hp.open_hp_application():
        raise AssertionError("Open HP failed")

@keyword("Connect HP Application")
def connect_hp():
    """Connect to the already opened HP application."""
    if not hp.connect_to_application():
        raise AssertionError("Connect HP failed")

@keyword("Navigate To PC Device")
def navigate_pc():
    """Navigate to the PC device card in HP app."""
    if not hp.navigate_to_pc_device():
        raise AssertionError("Navigate PC failed")

@keyword("TC1 Energy Page")
def tc1():
    """Navigate to the Energy Consumption page."""
    if not hp.navigate_to_Energy_consumption():
        raise AssertionError("TC1 failed")

@keyword("TC2 Hyperlinks")
def tc2():
    """Click all energy-related hyperlinks."""
    if not hp.click_energy_links():
        raise AssertionError("TC2 failed")

@keyword("TC3 Button Links")
def tc3():
    """Click all energy-related buttons."""
    if not hp.click_energy_buttonlinks():
        raise AssertionError("TC3 failed")

@keyword("TC4 More Helpful Links")
def tc4():
    """Click more helpful links on the Energy page."""
    if not hp.click_energy_buttonlinks_morehelpful():
        raise AssertionError("TC4 failed")

@keyword("TC5 Dropdown Stability")
def tc5():
    """Verify app stability while switching dropdown options."""
    if not hp.tc4_verify_no_crash_while_switching_dropdown():
        raise AssertionError("TC5 failed")

@keyword("TC6 Last 12 Hours")
def tc6():
    """Verify the chart for last 12 hours."""
    if not hp.tc5_verify_last_12_hours_chart():
        raise AssertionError("TC6 failed")

@keyword("TC7 Last 6 Days")
def tc7():
    """Verify the chart for last 6 days."""
    if not hp.tc6_verify_last_6_days_chart():
        raise AssertionError("TC7 failed")

@keyword("TC8 Last 6 Months")
def tc8():
    """Verify the chart for last 6 months."""
    if not hp.tc7_verify_last_6_months_chart():
        raise AssertionError("TC8 failed")

@keyword("Close HP Application")
def close_hp():
    """Close the HP application."""
    if not hp.close_hp_application():
        raise AssertionError("Close HP failed")
