import time
import pyautogui
import pygetwindow as gw
from pywinauto import Application
import os
import subprocess
import json
from datetime import datetime, timedelta
from collections import defaultdict
import shutil
import re


class MyHP:

    TIMEOUT = 10

    def __init__(self):

        self.application = None
        self.main_window = None
        self.app_title = "HP"

        self.pcm_folder = r"C:\ProgramData\HP\TelemetryDataCollector\PCMCollector"
        self.baseline_folder = r"C:\Testing\Automation2\Automation2\baseline"

    # ---------------------------------------------------
    # Logger
    # ---------------------------------------------------

    def _log(self, msg):
        print(msg)

    def _log_result(self, name, status, msg=""):
        print(f"[{'PASS' if status else 'FAIL'}] {name}: {msg}")

    # ---------------------------------------------------
    # STEP 1 – Decrypt PCM
    # ---------------------------------------------------

    def decrypt_pcm(self):

        try:

            today = datetime.now().strftime("%Y-%m-%d")
            encrypted = f"PcmSampleData_{today}.json"
            exe_path = os.path.join(self.pcm_folder, "TouchpointCrypter_v2.0.exe")

            if not os.path.exists(os.path.join(self.pcm_folder, encrypted)):
                self._log_result("Decrypt PCM", False, "Encrypted file not found")
                return False

            self._log("[INFO] Running TouchpointCrypter...")

            result = subprocess.run(
                [exe_path, encrypted],
                cwd=self.pcm_folder,
                capture_output=True,
                text=True
            )

            if result.returncode != 0:
                self._log_result("Decrypt PCM", False, result.stderr)
                return False

            time.sleep(3)

            decrypted = f"unencrypt-PcmSampleData_{today}.json"
            decrypted_path = os.path.join(self.pcm_folder, decrypted)

            if not os.path.exists(decrypted_path):
                self._log_result("Decrypt PCM", False, "Decrypted file not found")
                return False

            self._log_result("Decrypt PCM", True, "Decrypted successfully")
            return decrypted_path

        except Exception as e:
            self._log_result("Decrypt PCM", False, str(e))
            return False

    # ---------------------------------------------------
    # Copy JSON
    # ---------------------------------------------------

    def copy_to_baseline(self, decrypted_path):

        try:

            if not os.path.exists(self.baseline_folder):
                os.makedirs(self.baseline_folder)

            dest = os.path.join(
                self.baseline_folder,
                os.path.basename(decrypted_path)
            )

            shutil.copy2(decrypted_path, dest)

            self._log_result("Copy JSON", True, "Copied to baseline")

            return dest

        except Exception as e:
            self._log_result("Copy JSON", False, str(e))
            return False

    # ---------------------------------------------------
    # Load JSON
    # ---------------------------------------------------

    def load_json(self, path):

        try:

            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)

            self._log_result("Load JSON", True, "Loaded")

            return data

        except Exception as e:
            self._log_result("Load JSON", False, str(e))
            return None

    # ---------------------------------------------------
    # Calculate last 12 hours
    # ---------------------------------------------------

    def calculate_last_12_hours(self, data):

        try:

            extracted = []

            def flatten(obj):
                if isinstance(obj, dict):
                    for v in obj.values():
                        flatten(v)
                elif isinstance(obj, list):
                    for i in obj:
                        flatten(i)
                else:
                    extracted.append(obj)

            flatten(data)

            datetime_pattern = re.compile(r"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}")

            timestamps = []
            numbers = []

            for item in extracted:

                if isinstance(item, str) and datetime_pattern.search(item):
                    timestamps.append(item)

                try:
                    numbers.append(float(item))
                except:
                    pass

            records = []

            for ts, val in zip(timestamps, numbers):

                try:

                    dt = datetime.fromisoformat(ts.replace("Z", "").replace("T", " "))
                    records.append((dt, val))

                except:
                    continue

            records.sort()

            hourly = defaultdict(list)

            prev_time, prev_val = records[0]

            for curr_time, curr_val in records[1:]:

                diff = max(curr_val - prev_val, 0)

                hour_key = curr_time.replace(minute=0, second=0, microsecond=0)

                hourly[hour_key].append(diff)

                prev_time, prev_val = curr_time, curr_val

            hourly_avg = {}

            for h, diffs in hourly.items():
                hourly_avg[h] = sum(diffs) / len(diffs)

            now = datetime.now()

            end_hour = now.replace(minute=0, second=0, microsecond=0) - timedelta(hours=1)
            start_hour = end_hour - timedelta(hours=11)

            values = []

            current = start_hour

            print("\n========================================")
            print("JSON HOURLY ENERGY DATA")
            print("========================================")

            while current <= end_hour:

                v = round(hourly_avg.get(current, 0.0), 2)

                print(f"{current.strftime('%I %p').lstrip('0')} : {v} Wh")

                values.append(v)

                current += timedelta(hours=1)

            print("========================================")

            return values

        except Exception as e:
            self._log_result("Compare 12H", False, str(e))
            return None

    # ---------------------------------------------------
    # Open HP
    # ---------------------------------------------------

    def open_hp_application(self):

        pyautogui.press("win")
        time.sleep(1)

        pyautogui.write(self.app_title)
        time.sleep(1)

        pyautogui.press("enter")

        time.sleep(8)

        active = gw.getActiveWindow()

        if active and self.app_title in active.title:

            active.maximize()
            time.sleep(5)

            self._log_result("Open Application", True)

            return True

        return False

    # ---------------------------------------------------

    def connect_to_application(self):

        active = gw.getActiveWindow()

        pid = active._hWnd

        self.application = Application(backend="uia").connect(handle=pid)

        self.main_window = self.application.window(handle=pid)

        self.main_window.wait("ready", timeout=self.TIMEOUT)

        self._log_result("Connect", True)

        return True

    # ---------------------------------------------------

    def navigate_to_pc_device(self):

        pc = self.main_window.child_window(
            auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname",
            control_type="Text"
        )

        if pc.exists(timeout=5):

            pc.click_input()
            time.sleep(5)

            self._log_result("Navigate to PC Device", True)

            return True

        return False

    # ---------------------------------------------------

    def navigate_to_energy(self):

        print("\nTEST CASE: Navigate to Energy Consumption")

        self.main_window.set_focus()

        time.sleep(4)

        btn = self.main_window.child_window(
            auto_id="PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard",
            control_type="Button"
        )

        self.main_window.type_keys("{PGDN}")
        time.sleep(2)

        if btn.exists(timeout=10):

            btn.click_input()
            time.sleep(8)

            self._log_result("Navigate Energy", True)

            return True

        return False

    # ---------------------------------------------------

    def select_last_12_hours(self):

        dropdown = self.main_window.child_window(control_type="ComboBox")

        dropdown.click_input()

        time.sleep(1)

        option = self.main_window.child_window(
            title="Last 12 hours",
            control_type="ListItem"
        )

        option.click_input()

        time.sleep(5)

        self._log_result("Select Dropdown", True)

        return True

    # ---------------------------------------------------
    # Capture Chart Data
    # ---------------------------------------------------

    def capture_chart_data(self):

     try:
        self._log("[INFO] Capturing chart data...")

        rect = self.main_window.rectangle()

        screenshot = pyautogui.screenshot(region=(
            rect.left,
            rect.top,
            rect.width(),
            rect.height()
        ))

        screenshot.save("chart_capture.png")

        width, height = screenshot.size
        pixels = screenshot.load()

        # Chart crop (tuned for this UI layout)
        top = int(height * 0.43)
        bottom = int(height * 0.80)
        left = int(width * 0.12)
        right = int(width * 0.95)

        chart_height = bottom - top
        chart_width = right - left

        MAX_Y_VALUE = 60  # from chart scale

        values = []

        step = chart_width / 12

        for i in range(12):

            x_center = int(left + (i + 0.5) * step)

            detected_y = None

            # Search small horizontal region to capture dot
            for offset in range(-5, 6):

                x = x_center + offset

                for y in range(top, bottom):

                    r, g, b = pixels[x, y]

                    # Detect blue dot color
                    if (
                        b > 150 and
                        g < 140 and
                        r < 120
                    ):

                        detected_y = y
                        break

                if detected_y:
                    break

            if detected_y is None:
                values.append(0.0)
                continue

            # Convert pixel position → Wh value
            normalized = 1 - ((detected_y - top) / chart_height)

            wh = round(normalized * MAX_Y_VALUE, 2)

            if wh < 0.5:
                wh = 0.0

            values.append(wh)

        self._log_result("Capture Chart", True, "Chart data extracted")

        return values

     except Exception as e:
        self._log_result("Capture Chart", False, str(e))
        return None
    # ---------------------------------------------------
    # Validate JSON vs UI
    # ---------------------------------------------------

    def validate_energy(self, json_values, ui_values):

        print("\n==============================================")
        print("ENERGY VALIDATION (LAST 12 HOURS)")
        print("==============================================")

        tolerance = 2.5

        now = datetime.now()

        end_hour = now.replace(minute=0, second=0, microsecond=0) - timedelta(hours=1)

        start_hour = end_hour - timedelta(hours=11)

        current = start_hour

        print(f"{'Hour':<8}{'JSON(Wh)':<12}{'UI(Wh)':<10}Status")

        print("-" * 46)

        overall_pass = True

        for i in range(12):

            j = json_values[i]
            u = ui_values[i]

            diff = abs(j - u)

            status = "PASS" if diff <= tolerance else "FAIL"

            if status == "FAIL":
                overall_pass = False

            hour_label = current.strftime("%I %p").lstrip("0")

            print(f"{hour_label:<8}{j:<12}{u:<10}{status}")

            current += timedelta(hours=1)

        print("-" * 46)

        if overall_pass:
            print("RESULT : PASS")
        else:
            print("RESULT : FAIL")

        print("==============================================\n")

    # ---------------------------------------------------
    # Close App
    # ---------------------------------------------------

    def close_hp_application(self):

        try:

            self.main_window.type_keys("%{F4}")

            time.sleep(3)

            self._log_result("Close Application", True)

        except:

            subprocess.run("taskkill /f /im HP*.exe", shell=True)

    # ---------------------------------------------------
    # MAIN FLOW
    # ---------------------------------------------------

    def run_test(self):

        print("\nTEST CASE: Last 12 Hours Validation")
        print("-" * 60)

        decrypted = self.decrypt_pcm()

        if not decrypted:
            return

        copied = self.copy_to_baseline(decrypted)

        if not copied:
            return

        data = self.load_json(copied)

        if not data:
            return

        self.open_hp_application()

        self.connect_to_application()

        self.navigate_to_pc_device()

        self.navigate_to_energy()

        self.select_last_12_hours()

        json_values = self.calculate_last_12_hours(data)

        ui_values = self.capture_chart_data()

        print("\nJSON Values:", json_values)
        print("UI Values:", ui_values)

        if json_values and ui_values:

            self.validate_energy(json_values, ui_values)

        self.close_hp_application()


if __name__ == "__main__":

    MyHP().run_test()