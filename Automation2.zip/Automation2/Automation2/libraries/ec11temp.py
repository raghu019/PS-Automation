import time
import pyautogui
import pygetwindow as gw
from pywinauto import Application
import os
import sys
import io
from pywinauto.keyboard import send_keys
import pyperclip
import json
from datetime import datetime, timedelta
from collections import defaultdict
import ctypes
import ctypes.wintypes as wintypes

class MyHP:
    TIMEOUT = 5

    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"
        self.baseline_folder = r"C:\Testing\Automation2\Automation2\baseline"

    # ---------------- Logger ----------------
    def _log_result(self, test_name, status, message=""):
        result = "PASS" if status else "FAIL"
        print(f"[{result}] {test_name}: {message}")

    def _log_debug(self, message):
        print(f"[DEBUG] {message}")

    # ---------------- Open HP Application ----------------
    def open_hp_application(self):
        try:
            pyautogui.press('winleft')
            time.sleep(1)
            pyautogui.write(self.app_title)
            time.sleep(1)
            pyautogui.press('enter')
            time.sleep(5)

            active_window = gw.getActiveWindow()
            if active_window and self.app_title in active_window.title:
                active_window.maximize()
                time.sleep(15)
                self._log_result("Open Application", True)
                return True
            else:
                self._log_result("Open Application", False, "Wrong window focused")
                return False
        except Exception as e:
            self._log_result("Open Application", False, str(e))
            return False

    # ---------------- Connect to HP Application ----------------
    def connect_to_application(self):
        try:
            self.application = Application(backend="uia").connect(title_re=self.app_title)
            self.main_window = self.application.window(title_re=self.app_title)
            self.main_window.wait("ready", timeout=self.TIMEOUT)
            self._log_result("Connect to Application", True)
            return True
        except Exception as e:
            self._log_result("Connect to Application", False, str(e))
            return False

     # ---------------- Navigate to PC Device ----------------
    def navigate_to_pc_device(self):
        try:
            pc_device = self.main_window.child_window(
                auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname",
                control_type="Text"
            )
            if pc_device.exists(timeout=5):
                pc_device.click_input()
                time.sleep(5)
                self._log_result("Navigate to PC Device", True)
                return True
            self._log_result("Navigate to PC Device", False, "PC device not found")
            return True
        except Exception as e:
            self._log_result("Navigate to PC Device", False, str(e))
            return False

    # ---------------- Dump UI Tree ----------------
    def dump_ui_tree_to_file(self):
        if not self.main_window:
            self._log_result("Dump UI Tree", False, "Application not connected")
            return False
        try:
            dump_path = os.path.join(self.baseline_folder, "ui_dump.txt")
            with open(dump_path, "w", encoding="utf-8") as f:
                buffer = io.StringIO()
                sys.stdout = buffer
                self.main_window.print_control_identifiers()
                sys.stdout = sys.__stdout__
                f.write(buffer.getvalue())
                buffer.close()
            self._log_result("Dump UI Tree", True, f"Saved to {dump_path}")
            return True
        except Exception as e:
            sys.stdout = sys.__stdout__
            self._log_result("Dump UI Tree", False, str(e))
            return False

    # ---------------- Navigate to Energy Consumption ----------------
    def navigate_to_Energy_consumption(self):
        print("\nTEST CASE 1: Navigate to Energy Consumption module")
        print("-" * 60)

        if not self.main_window:
            self._log_result("Navigate to Energy consumption", False, "Application not connected")
            print("Test case 'Navigate to Energy consumption' completed : FAIL")
            print("-" * 60)
            return False

        try:
            self.main_window.set_focus()
            time.sleep(5)

            energy_btn = self.main_window.child_window(
                auto_id="PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard",
                control_type="Button"
            )

            self.main_window.type_keys("{PGDN}")
            time.sleep(1)
            self.main_window.type_keys("{UP}")
            time.sleep(0.5)
            self.main_window.type_keys("{UP}")
            time.sleep(4)

            if energy_btn.exists(timeout=8):
                energy_btn.click_input()
                time.sleep(10)
                self._log_result("Navigate to Energy consumption", True)
                print("-" * 60)
                return True

            self._log_result(
                "Navigate to Energy consumption page",
                False,
                "Energy consumption card not visible after PGDN + UP UP"
            )
            print("-" * 60)
            return False
        except Exception as e:
            self._log_result("Navigate to Energy consumption page", False, str(e))
            print("-" * 60)
            return False

    # ---------------- Click Hyperlinks ----------------
    def click_energy_links(self):
        time.sleep(3)
        print("\nTEST CASE 2: Clicking on Hyperlinks")
        print("-" * 60)
        pyautogui.scroll(-400)
        time.sleep(3)

        guide_titles = [
            "Learn more about Go Beyond",
        ]

        success = False
        for title in guide_titles:
            try:
                link = self.main_window.child_window(title=title, control_type="Hyperlink")
                if link.exists(timeout=self.TIMEOUT):
                    link.click_input()
                    print(f"[PASS] Clicked hyperlink: {title}")
                    success |= self._check_and_close_browser(title, wait_time=20)
                    print("[PASS] Navigate to hyperlinks success")
                    print("-" * 60)
                    return True
                else:
                    print(f"[FAIL] Hyperlink not found: {title}")
                    print("-" * 60)
            except Exception as e:
                print(f"[FAIL] Error clicking hyperlink '{title}': {e}")
                print("-" * 60)
        return success

    # ---------------- Click Button Links ----------------
    def click_energy_buttonlinks(self):
        time.sleep(3)
        print("\nTEST CASE 3: Clicking on HyperButton")
        print("-" * 60)
        pyautogui.scroll(-2600)
        self.main_window.type_keys("{PGDN}")
        time.sleep(1)

        for _ in range(7):
            self.main_window.type_keys("{UP}")
            time.sleep(0.5)
            time.sleep(3)

        guide_titles = [
            "How to adjust power and sleep settings in Windows",
            "Caring for your battery in Windows",
            "Battery saving tips for Windows",
            "Change the power mode for your Windows PC",
            "Manage background activity for apps in Windows",
            "Learn more about energy recommendations - Microsoft Support",
        ]

        success = False
        for title in guide_titles:
            try:
                btn = self.main_window.child_window(title=title, control_type="Button")
                if btn.exists(timeout=self.TIMEOUT):
                    btn.click_input()
                    print(f"[PASS] Clicked button: {title}")
                    success |= self._check_and_close_browser(title, wait_time=20)
                    print("-" * 60)
                else:
                    print(f"[FAIL] Button not found: {title}")
                    print("-" * 60)
            except Exception as e:
                print(f"[FAIL] Error clicking button '{title}': {e}")
                print("-" * 60)
        return success

    # ---------------- Click More Helpful Links ----------------
    def click_energy_buttonlinks_morehelpful(self):
        time.sleep(3)
        print("\nTEST CASE 4: Clicking on more helpful links")
        print("-" * 60)
        pyautogui.scroll(-2600)
        self.main_window.type_keys("{PGDN}")
        time.sleep(1)

        guide_titles = [
            "Product Carbon Footprint",
            "Learn more about Go Beyond",
            "Energy and the Environment - Epa.gov"
        ]

        success = False
        for title in guide_titles:
            try:
                btn = self.main_window.child_window(title=title, control_type="Button")
                if btn.exists(timeout=self.TIMEOUT):
                    btn.click_input()
                    print(f"[PASS] Clicked button: {title}")
                    success |= self._check_and_close_browser(title, wait_time=20)
                    print("-" * 60)
                else:
                    print(f"[FAIL] Button not found: {title}")
                    print("-" * 60)
            except Exception as e:
                print(f"[FAIL] Error clicking button '{title}': {e}")
                print("-" * 60)
        return success

    # ---------------- Browser Handling ----------------
    def _check_and_close_browser(self, title, expected_urls=None, wait_time=15):
        try:
            time.sleep(5)
            browser_windows = [
                w for w in gw.getAllWindows()
                if w.title and any(b in w.title.lower() for b in ["edge", "chrome", "firefox"])
            ]
            if not browser_windows:
                print(f"[FAIL] No browser detected for: {title}")
                return False

            for browser in browser_windows:
                browser.activate()
                time.sleep(2)
                browser.maximize()
                time.sleep(2)

                url = self._get_browser_url()
                print(f"[PASS] Detected URL: {url}")

                if expected_urls:
                    if not any(expected in url for expected in expected_urls):
                        print("❌ URL validation failed")
                        return False
                    print("✅ URL validated")

                time.sleep(wait_time)
                browser.close()
                print(f"[PASS] Closed browser: {browser.title}")

            hp_window = gw.getWindowsWithTitle(self.app_title)
            if hp_window:
                hp_window[0].activate()
                print("[PASS] HP app refocused")

            return True
        except Exception as e:
            print(f"[FAIL] Browser handling failed: {e}")
            return False

    def _get_browser_url(self):
        try:
            time.sleep(1)
            pyautogui.hotkey("ctrl", "l")
            time.sleep(1)
            pyautogui.hotkey("ctrl", "c")
            time.sleep(1)
            return pyperclip.paste()
        except Exception:
            return ""

    # ---------------- Close HP Application ----------------
    def close_hp_application(self):
        try:
            if self.main_window:
                self.main_window.set_focus()
                time.sleep(1)
                self.main_window.close()
                time.sleep(3)
                if not self.main_window.exists(timeout=3):
                    self._log_result("Close Application", True, "Closed using pywinauto")
                    return True

            hp_windows = gw.getWindowsWithTitle(self.app_title)
            if hp_windows:
                hp_windows[0].activate()
                time.sleep(1)
                pyautogui.hotkey('alt', 'f4')
                time.sleep(2)
                self._log_result("Close Application", True, "Closed using Alt+F4")
                return True

            self._log_result("Close Application", False, "HP window not found")
            return False
        except Exception as e:
            self._log_result("Close Application", False, str(e))
            return False

    # ---------------- Dropdown ----------------
    def select_consumption_dropdown(self, option_text):
        try:
            time.sleep(2)
            dropdown = self.main_window.child_window(
                title_re="Last.*hours|Last.*days|Last.*months",
                control_type="ComboBox"
            )
            dropdown.wait("ready", timeout=5)
            dropdown.click_input()
            time.sleep(1)

            list_item = self.main_window.child_window(
                title=option_text,
                control_type="ListItem"
            )
            if list_item.exists(timeout=5):
                list_item.click_input()
                time.sleep(3)
                self._log_result("Select Dropdown", True, option_text)
                return True

            self._log_result("Select Dropdown", False, f"{option_text} not found")
            return False
        except Exception as e:
            self._log_result("Select Dropdown", False, str(e))
            return False

    # ---------------- Verify Chart ----------------
    def verify_chart_displayed(self, option_text):
        try:
            chart_title = self.main_window.child_window(
                title="Daily average",
                control_type="Text"
            )
            if chart_title.exists(timeout=5):
                self._log_result("Verify Chart", True, option_text)
                return True
            self._log_result("Verify Chart", False, "Chart title missing")
            return False
        except Exception as e:
            self._log_result("Verify Chart", False, str(e))
            return False

    # ---------------- DPAPI Decrypt ----------------
    def decrypt_dpapi(self, blob: bytes):
        class DATA_BLOB(ctypes.Structure):
            _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.c_void_p)]

        CryptUnprotectData = ctypes.windll.crypt32.CryptUnprotectData
        in_buf = ctypes.create_string_buffer(blob)
        in_blob = DATA_BLOB(len(blob), ctypes.cast(in_buf, ctypes.c_void_p))
        out_blob = DATA_BLOB()

        if CryptUnprotectData(ctypes.byref(in_blob), None, None, None, None, 0,
                              ctypes.byref(out_blob)):
            result = ctypes.string_at(out_blob.pbData, out_blob.cbData)
            ctypes.windll.kernel32.LocalFree(out_blob.pbData)
            return result
        return None

    # ---------------- Load PCM Hourly ----------------
    def load_pcm_hourly_data(self):
        try:
            folder = r"C:\ProgramData\HP\TelemetryDataCollector\PCMCollector"
            files = [f for f in os.listdir(folder) if f.startswith("PcmSampleData_")]
            if not files:
                return {"Samples": []}
            files.sort(reverse=True)
            with open(os.path.join(folder, files[0]), "rb") as f:
                decrypted = self.decrypt_dpapi(f.read())
            return json.loads(decrypted.decode()) if decrypted else None
        except Exception as e:
            self._log_result("Load PCM Sample", False, str(e))
            return None

    # ---------------- Load PowerConsumption ----------------
    def load_power_consumption_data(self):
        try:
            path = r"C:\ProgramData\HP\TelemetryDataCollector\PCMCollector\PowerConsumption.json"
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            self._log_result("Load JSON", True, path)
            return data
        except Exception as e:
            self._log_result("Load JSON", False, str(e))
            return None

    # ---------------- Compare Chart ----------------
    def compare_chart_with_json(self, option_text, json_data):
     try:
        now = datetime.now()
        if option_text == "Last 12 hours":  # keeping same option name if UI uses it
            data = self.load_pcm_hourly_data()
            samples = data.get("Samples", []) if data else []

            sample_dict = {}

            for s in samples:
                try:
                    sample_time = datetime.strptime(
                        s["key"], "%Y-%m-%d %H:%M:%S"
                    ).replace(minute=0, second=0, microsecond=0)

                    sample_dict[sample_time] = s["value"]

                except Exception:
                    continue

            # Last completed hour (exclude current hour)
            end_hour = now.replace(
                minute=0, second=0, microsecond=0
            ) - timedelta(hours=1)

            
            start_hour = end_hour - timedelta(hours=12)

            labels = []
            values = []

            current = start_hour
            while current <= end_hour:
                labels.append(current.strftime("%I %p"))
                values.append(sample_dict.get(current, 0.0))
                current += timedelta(hours=1)

            self._log_result(
                "Compare Chart (12h)",
                True,
                f"Labels={labels} Values={values}"
            )

            return True

        # -------- Parse daily JSON --------
        parsed = {
            datetime.strptime(e["Key"], "%Y-%m-%d").date(): e["Value"]
            for e in json_data
        }

        

        # -------- Last 6 Days (exclude today) --------
        if option_text == "Last 6 days":
            end = (now - timedelta(days=1)).date()
            start = end - timedelta(days=5)

            labels = []
            values = []

            d = start
            while d <= end:
                labels.append(d.strftime("%a"))
                values.append(parsed.get(d, 0.0))
                d += timedelta(days=1)

            self._log_result(
                "Compare Chart (6d)",
                True,
                f"Labels={labels} Values={values}"
            )

            return True

        # -------- Last 6 Months --------
        if option_text == "Last 6 months":
            monthly = defaultdict(float)

            for d, v in parsed.items():
                monthly[d.strftime("%Y-%m")] += v

            self._log_result(
                "Compare Chart (6m)",
                True,
                dict(monthly)
            )

            return True

        return False

     except Exception as e:
        self._log_result("Compare Chart", False, str(e))
        return False


# ---------------- Is App Alive ----------------
    def is_application_alive(self):
        try:
            if not self.main_window.exists(timeout=3):
                return False

            self.main_window.wait("ready", timeout=3)
            return True

        except Exception:
            return False

    # ---------------- Test Cases ----------------
    def tc4_verify_no_crash_while_switching_dropdown(self):
        self.main_window.type_keys("{PGUP}")
        self.main_window.type_keys("{PGUP}")
        self.main_window.type_keys("{PGUP}")
        time.sleep(3)
        print("\nTEST CASE 5: Verify app does not crash while switching dropdown")
        print("-" * 60)

        options = ["Last 12 hours", "Last 6 days", "Last 6 months"]
        for i in range(len(options)):
            current = options[i]
            next_opt = options[(i + 1) % len(options)]

            if not self.select_consumption_dropdown(current):
                self._log_result("TC5 Dropdown Switch", False, f"Failed to select {current}")
                return False
            if not self.select_consumption_dropdown(next_opt):
                self._log_result("TC5 Dropdown Switch", False, f"Failed to switch to {next_opt}")
                return False
            time.sleep(2)
            if not self.is_application_alive():
                self._log_result("TC5 Application Stability", False, f"Application crashed while switching {current} → {next_opt}")
                return False
            self._log_result("TC5 Application Stability", True, f"Switched {current} → {next_opt} without crash")
        return True

    def tc5_verify_last_12_hours_chart(self):
        print("\nTEST CASE 6: Last 12 Hours – Verify & Compare Chart")
        print("-" * 60)
        if not self.select_consumption_dropdown("Last 12 hours"):
            return False
        if not self.verify_chart_displayed("Last 12 hours"):
            return False
        json_data = self.load_power_consumption_data()
        return self.compare_chart_with_json("Last 12 hours", json_data)

    def tc6_verify_last_6_days_chart(self):
        print("\nTEST CASE 7: Last 6 Days – Verify & Compare Chart")
        print("-" * 60)
        if not self.select_consumption_dropdown("Last 6 days"):
            return False
        if not self.verify_chart_displayed("Last 6 days"):
            return False
        json_data = self.load_power_consumption_data()
        return self.compare_chart_with_json("Last 6 days", json_data)

    def tc7_verify_last_6_months_chart(self):
        print("\nTEST CASE 8: Last 6 Months – Verify & Compare Chart")
        print("-" * 60)
        if not self.select_consumption_dropdown("Last 6 months"):
            return False
        if not self.verify_chart_displayed("Last 6 months"):
            return False
        json_data = self.load_power_consumption_data()
        return self.compare_chart_with_json("Last 6 months", json_data)

    # ---------------- Run Test Suite ----------------
    def run_energy_consumption_test_suite(self):
        self.open_hp_application()
        self.connect_to_application()
        self.navigate_to_pc_device()
        self.navigate_to_Energy_consumption()
       # self.click_energy_links()
        #self.click_energy_buttonlinks()
        #self.click_energy_buttonlinks_morehelpful()
       # self.tc4_verify_no_crash_while_switching_dropdown()
        self.tc5_verify_last_12_hours_chart()
        self.tc6_verify_last_6_days_chart()
        self.tc7_verify_last_6_months_chart()
        self.close_hp_application()


if __name__ == "__main__":
    hp_test = MyHP()
    hp_test.run_energy_consumption_test_suite()
