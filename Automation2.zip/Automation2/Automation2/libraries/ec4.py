import time
import pyautogui
import pygetwindow as gw
from pywinauto import Application
import os
import datetime


class MyHP:
    TIMEOUT = 15
    ITERATIONS = 3

    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"
        self.baseline_folder = r"C:\Testing\Automation2\Automation2\baseline"
        os.makedirs(self.baseline_folder, exist_ok=True)

    # ---------------- Logger ----------------
    def _log_result(self, test_name, status, message=""):
        result = "PASS" if status else "FAIL"
        print(f"[{result}] {test_name}: {message}")

    def _log_debug(self, message):
        print(f"[DEBUG] {message}")

    # ---------------- Screenshot Evidence ----------------
    def _capture_evidence(self, name):
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(self.baseline_folder, f"{name}_{ts}.png")
        pyautogui.screenshot(path)
        print(f"[INFO] Screenshot saved: {path}")

    # ---------------- Open HP Application ----------------
    def open_hp_application(self):
        try:
            for _ in range(3):
                pyautogui.press('winleft')
                time.sleep(1)
                pyautogui.write(self.app_title)
                time.sleep(1)
                pyautogui.press('enter')
                time.sleep(10)

                active_window = gw.getActiveWindow()
                if active_window and self.app_title in active_window.title:
                    active_window.maximize()
                    self._log_result("Open Application", True)
                    return True

                self._log_debug("Retrying HP launch...")

            self._capture_evidence("launch_fail")
            self._log_result("Open Application", False, "HP app did not appear")
            return False

        except Exception as e:
            self._capture_evidence("launch_exception")
            self._log_result("Open Application", False, str(e))
            return False

    # ---------------- Connect to Application ----------------
    def connect_to_application(self):
        try:
            self.application = Application(backend="uia").connect(title_re=self.app_title)
            self.main_window = self.application.window(title_re=self.app_title)
            self.main_window.wait("visible", timeout=self.TIMEOUT)
            self.main_window.wait("enabled", timeout=self.TIMEOUT)
            self.main_window.set_focus()
            self._log_result("Connect to Application", True)
            return True
        except Exception as e:
            self._capture_evidence("connect_fail")
            self._log_result("Connect to Application", False, str(e))
            return False

    # ---------------- Navigate to PC Device ----------------
    def navigate_to_pc_device(self):
        try:
            pc_device = self.main_window.child_window(
                auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname",
                control_type="Text"
            )

            if pc_device.exists(timeout=10):
                pc_device.click_input()
                time.sleep(6)
                self._log_result("Navigate to PC Device", True)
                return True

            self._log_result("Navigate to PC Device", True, "PC device card not found")
            return True

        except Exception as e:
            self._log_result("Navigate to PC Device", False, str(e))
            return False

    # ---------------- Navigate to Energy Consumption ----------------
    def navigate_to_energy_consumption(self):
        print("\nTEST CASE 11: Navigate to Energy Consumption page with out any crash")
        print("-" * 60)

        try:
            self.main_window.set_focus()
            time.sleep(5)

            # Force lazy-load cards
            self.main_window.type_keys("{PGDN}")
            
            self.main_window.type_keys("{UP}")
            time.sleep(0.5)

            energy_btn = self.main_window.child_window(
                auto_id="PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard",
                control_type="Button"
            )

            if energy_btn.exists(timeout=10):
                try:
                    energy_btn.click_input()
                except:
                    energy_btn.click()

                time.sleep(10)
                self._log_result("Navigate to Energy Consumption", True)
                print("-" * 60)
                return True

            self._capture_evidence("energy_button_missing")
            self._log_result(
                "Navigate to Energy Consumption",
                False,
                "Energy card not visible after scroll"
            )
            print("-" * 60)
            return False

        except Exception as e:
            self._capture_evidence("navigation_exception")
            self._log_result("Navigate to Energy Consumption", False, str(e))
            print("-" * 60)
            return False

    # ---------------- Stability Test Loop ----------------
    def energy_consumption_stability_test(self):
        print("\n==== Energy Consumption Stability Test ====\n")
        print("\n====TC11: Navigate to Energy consumption page with out any crash================\n")

        for i in range(1, self.ITERATIONS + 1):
            print(f"\n--- Iteration {i} ---")

            if not self.open_hp_application():
                return
            if not self.connect_to_application():
                return
            if not self.navigate_to_pc_device():
                return
            if not self.navigate_to_energy_consumption():
                return

            self._log_result(
                f"Energy Navigation Iteration {i}",
                True,
                "Navigation successful"
            )
            time.sleep(3)
            if not self.close_hp_application():
             time.sleep(2)

        print("\n✅ Energy Consumption page is displayed with out any Application crash")
        return True

        # ---------------- Close HP Application ----------------
    def close_hp_application(self):
        try:
            if self.main_window:
                self.main_window.set_focus()
                time.sleep(1)
                self.main_window.close()
                time.sleep(3)
                if not self.main_window.exists(timeout=3):
                    self._log_result("Close Application", True, "Closed HP Application")
                    return True

            hp_windows = gw.getWindowsWithTitle(self.app_title)
            if hp_windows:
                hp_windows[0].activate()
                time.sleep(1)
                pyautogui.hotkey('alt', 'f4')
                time.sleep(2)
                self._log_result("Close Application", True, "Closed using Alt+F4")
                return True

            self._log_result("Close Application", False, "HP window not found")
            return False
        except Exception as e:
            self._log_result("Close Application", False, str(e))
            return False




# ===================== MAIN =====================
if __name__ == "__main__":
    hp = MyHP()
    hp.energy_consumption_stability_test()
