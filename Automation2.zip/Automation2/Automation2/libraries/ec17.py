import time
import pyautogui
import pygetwindow as gw
from pywinauto import Application
import os
import datetime
from datetime import datetime
from PIL import Image, ImageChops
import cv2
from skimage.metrics import structural_similarity as ssim
import numpy as np



class MyHP:
    TIMEOUT = 15
    ITERATIONS = 1

    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"
        self.baseline_folder = r"C:\Testing\Automation2\Automation2\baseline"
        os.makedirs(self.baseline_folder, exist_ok=True)

  # ---------------- Logger ----------------
    def log(self, name, status, msg=""):
        print(f"[{'PASS' if status else 'FAIL'}] {name}: {msg}")
    
    def _log_result(self, name, status, msg=""):
        print(f"[{'PASS' if status else 'FAIL'}] {name}: {msg}")

    def _log_debug(self, msg):
        print(f"[DEBUG] {msg}")


    # ---------------- Screenshot Evidence ----------------
    def _capture_evidence(self, name):
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(self.baseline_folder, f"{name}_{ts}.png")
        pyautogui.screenshot(path)
        print(f"[INFO] Screenshot saved: {path}")

    # ---------------- Open HP Application ----------------
    def open_hp_application(self):
        try:
            for _ in range(3):
                pyautogui.press('winleft')
                time.sleep(1)
                pyautogui.write(self.app_title)
                time.sleep(1)
                pyautogui.press('enter')
                time.sleep(10)

                active_window = gw.getActiveWindow()
                if active_window and self.app_title in active_window.title:
                    active_window.maximize()
                    self._log_result("Open Application", True)
                    return True

                self._log_debug("Retrying HP launch...")

            self._capture_evidence("launch_fail")
            self._log_result("Open Application", False, "HP app did not appear")
            return False

        except Exception as e:
            self._capture_evidence("launch_exception")
            self._log_result("Open Application", False, str(e))
            return False

    # ---------------- Connect to Application ----------------
    def connect_to_application(self):
        try:
            self.application = Application(backend="uia").connect(title_re=self.app_title)
            self.main_window = self.application.window(title_re=self.app_title)
            self.main_window.wait("visible", timeout=self.TIMEOUT)
            self.main_window.wait("enabled", timeout=self.TIMEOUT)
            self.main_window.set_focus()
            self._log_result("Connect to Application", True)
            return True
        except Exception as e:
            self._capture_evidence("connect_fail")
            self._log_result("Connect to Application", False, str(e))
            return False

    # ---------------- Navigate to PC Device ----------------
    def navigate_to_pc_device(self):
        try:
            pc_device = self.main_window.child_window(
                auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname",
                control_type="Text"
            )

            if pc_device.exists(timeout=10):
                pc_device.click_input()
                time.sleep(6)
                self._log_result("Navigate to PC Device", True)
                return True

            self._log_result("Navigate to PC Device", True, "PC device card not found")
            return True

        except Exception as e:
            self._log_result("Navigate to PC Device", False, str(e))
            return False

    # ---------------- Navigate to Energy Consumption ----------------
    def navigate_to_energy_consumption(self):
        
        try:
            self.main_window.set_focus()
            time.sleep(8)

            # Force lazy-load cards
            self.main_window.type_keys("{PGDN}")
            
            self.main_window.type_keys("{UP}")
            time.sleep(0.5)

            energy_btn = self.main_window.child_window(
                auto_id="PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard",
                control_type="Button"
            )

            if energy_btn.exists(timeout=10):
                try:
                    energy_btn.click_input()
                except:
                    energy_btn.click()

                time.sleep(10)
                self._log_result("Navigate to Energy Consumption", True)
                print("-" * 60)
                return True

            self._capture_evidence("energy_button_missing")
            self._log_result(
                "Navigate to Energy Consumption",
                False,
                "Energy card not visible after scroll"
            )
            print("-" * 60)
            return False

        except Exception as e:
            self._capture_evidence("navigation_exception")
            self._log_result("Navigate to Energy Consumption", False, str(e))
            print("-" * 60)
            return False

        # ---------------- Close HP Application ----------------
    def close_hp_application(self):
        try:
            if self.main_window:
                self.main_window.set_focus()
                time.sleep(1)
                self.main_window.close()
                time.sleep(3)
                if not self.main_window.exists(timeout=3):
                    self._log_result("Close Application", True, "Closed HP Application")
                    return True

            hp_windows = gw.getWindowsWithTitle(self.app_title)
            if hp_windows:
                hp_windows[0].activate()
                time.sleep(1)
                pyautogui.hotkey('alt', 'f4')
                time.sleep(2)
                self._log_result("Close Application", True, "Closed using Alt+F4")
                return True

            self._log_result("Close Application", False, "HP window not found")
            return False
        except Exception as e:
            self._log_result("Close Application", False, str(e))
            return False

    # ---------------- Navigate to Windows Settings and Toggle Color Filters ----------------
    def toggle_color_filters(self):
        print("\nTEST CASE: Toggle Windows Color Filters\n")
        print("-" * 60)

        try:
            # Open Windows search
            pyautogui.press('winleft')
            time.sleep(1)
            pyautogui.write("Settings")
            time.sleep(1)
            pyautogui.press('enter')
            time.sleep(5)

            # Connect to Settings window
            settings_app = Application(backend="uia").connect(title_re="Settings")
            settings_win = settings_app.window(title_re="Settings")
            settings_win.wait("visible", timeout=self.TIMEOUT)
            settings_win.set_focus()

            # Navigate to Accessibility
            accessibility = settings_win.child_window(title="Accessibility", control_type="ListItem")
            if accessibility.exists(timeout=10):
                accessibility.click_input()
                time.sleep(3)
            else:
                self._capture_evidence("accessibility_missing")
                self._log_result("Navigate to Accessibility", False, "Accessibility option not found")
                return False

            # Navigate to Color filters
            color_filters = settings_win.child_window(title="Color filters", control_type="ListItem")
            if color_filters.exists(timeout=10):
                color_filters.click_input()
                time.sleep(3)
            else:
                self._capture_evidence("color_filters_missing")
                self._log_result("Navigate to Color Filters", False, "Color filters option not found")
                return False

             # Toggle the Color filters switch
            # toggle_btn = settings_win.child_window(auto_id="SystemSettings_ColorFilter_EnableToggleSwitch", control_type="Button")
                 # Toggle via keyboard
            
            toggle_btn1 = settings_win.child_window(title="Color filters", auto_id="SystemSettings_Accessibility_ColorFiltering_IsEnabled_ToggleSwitch", control_type="Button")
             #settings_win.print_control_identifiers()
            if toggle_btn1.exists(timeout=10):
            # Read current state
             state = toggle_btn1.get_toggle_state()  # 0=Off, 1=On, 2=Indeterminate
             current_status = "ON" if state == 1 else "OFF"
             print(f"[INFO] Current Color Filter status: {current_status}")
             pyautogui.press("tab")
             time.sleep(1)
             pyautogui.press("space")
             time.sleep(2)
                # Read new state
             new_state = toggle_btn1.get_toggle_state()
             new_status = "ON" if new_state == 1 else "OFF"
             print(f"[INFO] New Color Filter status: {new_status}")

             self._log_result("Toggle Color Filters", True, f"Toggled from {current_status} to {new_status}")
            else:
             self._capture_evidence("toggle_missing")
             self._log_result("Toggle Color Filters", False, "Toggle button not found")
             return False


            # Close Settings
            settings_win.close()
            time.sleep(2)
            self._log_result("Close Settings", True, "Closed Settings window")
            print("-" * 60)
            return True

        except Exception as e:
            self._capture_evidence("color_filters_exception")
            self._log_result("Toggle Color Filters", False, str(e))
            print("-" * 60)
            return False

     # ---------------- Dropdown ----------------
    def select_dropdown(self, text):
        try:
            dropdown = self.main_window.child_window(control_type="ComboBox")
            dropdown.click_input()
            time.sleep(1)

            item = self.main_window.child_window(title=text, control_type="ListItem")

            if item.exists(timeout=5):
                item.click_input()
                time.sleep(2)
                self.log("Dropdown", True, text)
                return True

            self.log("Dropdown", False, text)
            return False

        except Exception as e:
            self.log("Dropdown", False, str(e))
            return False

    # ---------------- Stability ----------------
    def dropdown_test(self):
        options = ["Last 12 hours", "Last 6 days", "Last 6 months"]

        for i in range(1):
            print(f"\nIteration {i+1}")

            for j in range(len(options)):
                curr = options[j]
                nxt = options[(j + 1) % len(options)]

                if not self.select_dropdown(curr):
                    return False
                if not self.select_dropdown(nxt):
                    return False

                if not self.main_window.exists(timeout=3):
                    self.log("App Crash", False)
                    return False

                self.log("Switch OK", True, f"{curr} → {nxt}")

        return True

     # ---------------- Scroll to Total Energy Section ----------------
    def scroll_to_total_energy_section(self):
        self._log_result("Scrolling to Total Energy Consumption section", True)
        self.main_window.type_keys("{PGDN}")
        time.sleep(1)
        time.sleep(10)  # mandatory stabilization wait

    # ---------------- Dropdown Select ----------------
    def select_total_energy_value(self, option_text):
        try:
            dropdown = self.main_window.child_window(control_type="ComboBox")
            dropdown.wait("visible", timeout=10)

            dropdown.wrapper_object().expand()
            time.sleep(5)

            option = self.main_window.child_window(
                title=option_text,
                control_type="ListItem"
            )
            option.wait("visible", timeout=10)
            option.click_input()
            time.sleep(5)

            self._log_result("Select Total Energy Dropdown", True, option_text)
            return True

        except Exception as e:
            self._log_result("Select Total Energy Dropdown", False, str(e))
            return False

    # ---------------- Crash Verification (FIXED) ----------------
    def verify_energy_page_not_crashed(self):
        try:
            if self.main_window.exists(timeout=2) and self.main_window.is_visible():
                self._log_result(
                    "Energy Consumption Crash Check",
                    True,
                    "Application is responsive"
                )
                return True

            self._log_result(
                "Energy Consumption Crash Check",
                False,
                "Main window not visible"
            )
            return False

        except Exception as e:
            self._log_result(
                "Energy Consumption Crash Check",
                False,
                f"Exception occurred: {e}"
            )
            return False


    #-------------------Total Energy dropdown stability------------------
    def tc_verify_total_energy_dropdown_stability(self):
        
        self.scroll_to_total_energy_section()

        for i in range(1,3):
            print(f"\nIteration {i}")

            if not self.select_total_energy_value("Last Week"):
                return False
            if not self.verify_energy_page_not_crashed():
                return False

            if not self.select_total_energy_value("Last Month"):
                return False
            if not self.verify_energy_page_not_crashed():
                return False

        self._log_result(
            "Energy Consumption Dropdown Stability",
            True,
            f"No crash after {i} iterations"
        )
        print("-" * 60)
        return True

    # ---------------- Screenshot Capture ----------------
    def capture_energy_screenshot(self, mode):
     try:
        # Ensure folder exists
        folder = r"C:\Testing\Automation2\Automation2\baseline\colorfilter\base"
        os.makedirs(folder, exist_ok=True)

        # Scroll actions
        self.main_window.set_focus()
        time.sleep(2)

       # self.main_window.type_keys("{PGDN}")
        #time.sleep(3)

        #self.main_window.type_keys("{PGUP}")
        #time.sleep(3)

        # File name
        file_path = os.path.join(folder, f"energy_{mode}.png")

        # Capture screenshot
        screenshot = pyautogui.screenshot()
        screenshot.save(file_path)

        self._log_result("Screenshot Captured", True, file_path)
        return True

     except Exception as e:
        self._log_result("Screenshot Capture Failed", False, str(e))
        return False
    
    # ---------------- Image Comparison ----------------
    def compare_images(self, img1_path, img2_path, threshold=0.95):
     try:
        if not os.path.exists(img1_path):
            self._log_result("Image Compare", False, f"Missing: {img1_path}")
            return False

        if not os.path.exists(img2_path):
            self._log_result("Image Compare", False, f"Missing: {img2_path}")
            return False

        # Read images using OpenCV
        img1 = cv2.imread(img1_path)
        img2 = cv2.imread(img2_path)

        # Resize if different
        if img1.shape != img2.shape:
            img2 = cv2.resize(img2, (img1.shape[1], img1.shape[0]))

        # Convert to grayscale
        gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
        gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)

        # Compute SSIM
        score, diff = ssim(gray1, gray2, full=True)

        similarity = round(score * 100, 2)

        if score >= threshold:
            self._log_result("Image Compare", True, f"Match: {similarity}%")
            return True
        else:
            self._log_result("Image Compare", False, f"Mismatch: {similarity}%")
            return False

     except Exception as e:
        self._log_result("Image Compare", False, str(e))
        return False
   
   #-------Comparing screenshots-------------------
     
    def compare_all_screenshots(self):
        base_path = r"C:\Testing\Automation2\Automation2\baseline\colorfilter\base"
        output_path = r"C:\Testing\Automation2\Automation2\baseline\colorfilter\output"

        results = []
    
        for file in os.listdir(base_path):
            if file.endswith(".png"):
                base_img = os.path.join(base_path, file)
                output_img = os.path.join(output_path, file)

                print(f"\nComparing: {file}")

                result = self.compare_images(base_img, output_img)
                results.append(result)

        if all(results):
            self._log_result("Final Image Comparison", True, "All images matched")
            return True
        else:
            self._log_result("Final Image Comparison", False, "Some images mismatched")
        return False
    
     # ---------------- FULL FLOW ----------------
    def tc21_colorfilter(self):
        try:
          print("\n========= Color filters Off → ON → Off → Validation of Energy consumption UI======\n")

            # -------- Color filter OFF --> ON  --------
          if not self.toggle_color_filters(): return False
          if not self.open_hp_application(): return False 
          if not self.connect_to_application(): return False
          if not self.navigate_to_pc_device(): return False
          if not self.navigate_to_energy_consumption(): return False
          if not self.capture_energy_screenshot("colorfilter_ON1"): return False
          if not self.dropdown_test(): return False
          if not self.tc_verify_total_energy_dropdown_stability(): return False
          if not self.capture_energy_screenshot("colorfilter_ON2"): return False
          self.main_window.type_keys("{PGDN}")
          if not self.capture_energy_screenshot("colorfilter_ON3"): return False
          self.main_window.type_keys("{PGDN}")
          if not self.capture_energy_screenshot("colorfilter_ON4"): return False
          self.close_hp_application()

          print("\nColor filter toggle switch ON validation completion\n")
          time.sleep(5)
          
          # -------- Color filter ON -> OFF --------
          if not self.toggle_color_filters(): return False
          if not self.open_hp_application(): return False 
          if not self.connect_to_application(): return False
          if not self.navigate_to_pc_device(): return False
          if not self.navigate_to_energy_consumption(): return False
          if not self.capture_energy_screenshot("colorfilter_OFF1"): return False
          if not self.dropdown_test(): return False
          if not self.tc_verify_total_energy_dropdown_stability(): return False
          if not self.capture_energy_screenshot("colorfilter_OFF2"): return False
          self.main_window.type_keys("{PGDN}")
          if not self.capture_energy_screenshot("colorfilter_OFF3"): return False
          self.main_window.type_keys("{PGDN}")
          if not self.capture_energy_screenshot("colorfilter_OFF4"): return False
          self.close_hp_application()

          print("\nColor filter toggle switch OFF validation completion\n")
         
          print("\n🔍 STARTING IMAGE COMPARISON\n")

          if not self.compare_all_screenshots(): 
               print("\n❌ IMAGE VALIDATION FAILED")
               return False
            
          print("\n✅ IMAGE VALIDATION PASSED")
          return True
        
        except Exception as e:
            self._log_result("TC21 Execution", False, str(e))
            return False

# ---------------- RUN ----------------
if __name__ == "__main__":
    result = MyHP().tc21_colorfilter()
    print("\nFINAL RESULT:", "PASS" if result else "FAIL")


