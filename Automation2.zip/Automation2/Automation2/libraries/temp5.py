import time
import os
import pyautogui
import pygetwindow as gw
from pywinauto import Application
from PIL import Image



class WindowsAutomation:
    def __init__(self):
        self.hp_title = "HP"
        self.screenshot_folder = r"C:\Users\cmit\Desktop\screen"
        os.makedirs(self.screenshot_folder, exist_ok=True)

    def _log(self, step, status, msg=""):
        print(f"[{'PASS' if status else 'FAIL'}] {step}: {msg}")

    # --- Open Settings ---
    def open_settings(self):
        pyautogui.moveTo(500, 500)  # keep mouse away from fail-safe corner
        pyautogui.press("winleft")
        time.sleep(1)
        pyautogui.write("Settings")
        pyautogui.press("enter")
        time.sleep(5)
        self._log("Open Settings", True)

    # --- Select Color Filter ---
    def select_color_filter(self, filter_name):
        app = Application(backend="uia").connect(title_re="Settings")
        win = app.window(title_re="Settings")
        win.wait("ready", timeout=10)
        win.set_focus()

        acc = win.child_window(title="Accessibility", control_type="ListItem")
        acc.click_input()
        time.sleep(2)

        cf = win.child_window(title="Color filters", control_type="ListItem")
        cf.click_input()
        time.sleep(2)

        toggle = win.child_window(control_type="CheckBox", found_index=0)
        if toggle.exists():
            toggle.click_input()
            time.sleep(2)

        option = win.child_window(title=filter_name, control_type="RadioButton")
        if option.exists():
            option.click_input()
            time.sleep(2)
            self._log("Select Filter", True, filter_name)

    # --- Open HP App ---
    def open_hp_app(self):
        pyautogui.moveTo(500, 500)
        pyautogui.press("winleft")
        time.sleep(1)
        pyautogui.write(self.hp_title)
        pyautogui.press("enter")
        time.sleep(10)

        active = gw.getActiveWindow()
        if active and self.hp_title in active.title:
            active.maximize()
            self._log("Open HP App", True, active.title)
            return True
        self._log("Open HP App", False, "Wrong window")
        return False

    def connect_hp(self):
        try:
            app = Application(backend="uia").connect(title_re=self.hp_title)
            win = app.window(title_re=self.hp_title)
            win.wait("ready", timeout=10)
            win.set_focus()
            self._log("Connect HP App", True)
            return win
        except Exception as e:
            self._log("Connect HP App", False, str(e))
            return None

    def navigate_energy_consumption(self, win):
        try:
            pc_device = win.child_window(auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname", control_type="Text")
            if pc_device.exists(timeout=5):
                pc_device.click_input()
                time.sleep(5)
                self._log("Navigate PC Device", True)

            energy_page = win.child_window(auto_id="PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard", control_type="Button")
            if energy_page.exists(timeout=5):
                energy_page.click_input()
                time.sleep(5)
                self._log("Open Energy Consumption", True)
                return True
            self._log("Open Energy Consumption", False, "Not found")
            return False
        except Exception as e:
            self._log("Navigate Energy Consumption", False, str(e))
            return False

    def capture_full_page(self, filename):
        screenshots = []
        scroll_count = 6
        pyautogui.moveTo(500, 500)

        for _ in range(scroll_count):
            img = pyautogui.screenshot()
            screenshots.append(img)
            pyautogui.scroll(-800)
            time.sleep(1)

        widths, heights = zip(*(i.size for i in screenshots))
        total_height = sum(heights)
        max_width = max(widths)

        final_img = Image.new('RGB', (max_width, total_height))
        y_offset = 0
        for img in screenshots:
            final_img.paste(img, (0, y_offset))
            y_offset += img.size[1]

        final_img.save(filename)
        self._log("Screenshot", True, filename)

    def close_hp_app(self):
        try:
            windows = gw.getWindowsWithTitle(self.hp_title)
            for win in windows:
                win.close()
            time.sleep(3)
            self._log("Close HP App", True)
        except Exception as e:
            self._log("Close HP App", False, str(e))

    # --- Run Flow for a given filter ---
    def run_for_filter(self, filter_name):
        self.open_settings()
        self.select_color_filter(filter_name)
        if self.open_hp_app():
            win = self.connect_hp()
            if win and self.navigate_energy_consumption(win):
                filename = os.path.join(
                    self.screenshot_folder,
                    f"Energy_{filter_name.replace(' ', '_').replace('(', '').replace(')', '')}.png"
                )
                self.capture_full_page(filename)
            self.close_hp_app()

    # --- Loop through all filters ---
    def run(self):
        filters = [
            "Red-green (green weak, deuteranopia)",
            "Red-green (red weak, protanopia)",
            "Blue-yellow (tritanopia)",
            "Grayscale",
            "Grayscale inverted",
            "Inverted"
        ]
        for f in filters:
            self.run_for_filter(f)

if __name__ == "__main__":
    bot = WindowsAutomation()
    bot.run()
