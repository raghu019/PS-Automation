from robot.api.deco import keyword
from ec1 import MyHP as MyHP_EC1
from ec2 import MyHP as MyHP_EC2
from ec3 import MyHP as MyHP_EC3
from ec4 import MyHP as MyHP_EC4
from ec5 import MyHP as MyHP_EC5
from ec8 import MyHP as MyHP_EC8
from ec9 import MyHP as MyHP_EC9
from ec10 import MyHP as MyHP_EC10
from ec11 import MyHP as MyHP_EC11
from ec12 import MyHP as MyHP_EC12
from ec13 import MyHP as MyHP_EC13
from ec14 import MyHP as MyHP_EC14
from ec15 import MyHP as MyHP_EC15
from ec16 import MyHP as MyHP_EC16
from ec17 import MyHP as MyHP_EC17

hp_ec1 = MyHP_EC1()
hp_ec2 = MyHP_EC2()
hp_ec3 = MyHP_EC3()
hp_ec4 = MyHP_EC4()
hp_ec5 = MyHP_EC5()
hp_ec8 = MyHP_EC8()
hp_ec9 = MyHP_EC9()
hp_ec10 = MyHP_EC10()
hp_ec11 = MyHP_EC11()
hp_ec12 = MyHP_EC12()
hp_ec13 = MyHP_EC13()
hp_ec14 = MyHP_EC14()
hp_ec15 = MyHP_EC15()
hp_ec16 = MyHP_EC16()
hp_ec17 = MyHP_EC17()


# Initialize the HP automation class
hp = hp_ec1

@keyword("Open HP Application")
def open_hp():
    """Open the HP desktop application."""
    if not hp.open_hp_application():
        raise AssertionError("Open HP failed")

@keyword("Connect HP Application")
def connect_hp():
    """Connect to the already opened HP application."""
    if not hp.connect_to_application():
        raise AssertionError("Connect HP failed")

@keyword("Navigate To PC Device")
def navigate_pc():
    """Navigate to the PC device card in HP app."""
    if not hp.navigate_to_pc_device():
        raise AssertionError("Navigate PC failed")

@keyword("TC1 Energy Page")
def tc1():
    """Navigate to the Energy Consumption page."""
    if not hp.navigate_to_Energy_consumption():
        raise AssertionError("TC1 failed")

@keyword("TC2 Hyperlinks")
def tc2():
    """Click all energy-related hyperlinks."""
    if not hp.click_energy_links():
        raise AssertionError("TC2 failed")

@keyword("TC3 Button Links")
def tc3():
    """Click all energy-related buttons."""
    if not hp.click_energy_buttonlinks():
        raise AssertionError("TC3 failed")

@keyword("TC4 More Helpful Links")
def tc4():
    """Click more helpful links on the Energy page."""
    if not hp.click_energy_buttonlinks_morehelpful():
        raise AssertionError("TC4 failed")

@keyword("TC5 Dropdown Stability")
def tc5():
    """Verify app stability while switching dropdown options."""
    if not hp_ec12.tc4_verify_no_crash_while_switching_dropdown():
        raise AssertionError("TC5 failed")

@keyword("TC6 Last 12 Hours")
def tc6():
    """Verify the chart for last 12 hours."""
    if not hp_ec11.tc5_verify_last_12_hours_chart():
        raise AssertionError("TC6 failed")

@keyword("TC7 Last 6 Days")
def tc7():
    """Verify the chart for last 6 days."""
    if not hp_ec13.tc6_verify_last_6_days_chart():
        raise AssertionError("TC7 failed")

@keyword("TC8 Last 6 Months")
def tc8():
    """Verify the chart for last 6 months."""
    if not hp_ec14.tc7_verify_last_6_months_chart():
        raise AssertionError("TC8 failed")

@keyword("Close HP Application")
def close_hp():
    """Close the HP application."""
    if not hp.close_hp_application():
        raise AssertionError("Close HP failed")

@keyword("TC9: Open HP Application via run dialog")
def tc9():
    """Open the HP desktop application."""
    if not hp_ec2.open_energy_consumption_via_run_dialog():
        raise AssertionError("TC9 Failed - Displaying Energy Consumption page failed")
 
@keyword("TC10: Go Beyound-Sustainable Impact Report pdf verification")
def tc10():
    """Open the HP desktop application."""
    if not hp_ec3.verify_go_beyound_sustainable_impact_report():
        raise AssertionError("TC10 Failed - Go Beyound-Sustainable Impact Report pdf verificatio failed")

@keyword("Close HP Application")
def close_hp():
    """Close the HP application."""
    if not hp_ec2.close_hp_application():
        raise AssertionError("Close HP failed")

@keyword("TC11: Navigate to Energy Consumption page with out any crash")
def tc11():
    """Open the Energy consumption page with out any crash."""
    if not hp_ec4.energy_consumption_stability_test():
        raise AssertionError("TC11 Failed - Navigate to Energy Consumption page with out any crash")

#**********Testcase#12 is related to OLDER BIOS with supported platform --Displaying warning message*********

@keyword("TC13: Verifying BIOS warning message on supported platform with latest BIOS")
def tc13():
    if not hp_ec5.tc13_verify_no_bios_warning_message():
        raise AssertionError("TC13 Failed - Not displaying BIOS warning message on supported platform with latest BIOS")
    
#*****TC14: Verify Energy Consumption card is NOT displayed for unsupported BIOS/unsupported platform (ec6.py) ******
#*****TC15: Verify Energy Consumption card is NOT displayed for supported BIOS/unsupported platform (ec7.py) ******    


@keyword("TC16:Verifying Total Energy Consumption Dropdown Stability with out any crash")
def tc16():
    if not hp_ec8.tc16_verify_total_energy_consumption_dropdown_without_any_crash():
        raise AssertionError("TC 16 Failed - Total Energy Consumption Dropdown Stability with out any crash")
    

@keyword("tc17_total_energy_last_Month")
def tc17():
    if not hp_ec9.tc17_total_energy_last_Month(): 
        raise AssertionError("TC 17 Failed - Total Energy consumption with in a Month")
    

@keyword("tc18_total_energy_last_week")
def tc18():
    if not hp_ec10.tc18_total_energy_last_week():
        raise AssertionError("TC 18 Failed - Total Energy consumption with in a week")
    
@keyword("tc19_total_energy_consumption_UI_val")
def tc19():
    if not hp_ec15.tc19_total_energy_consumption_UI_val():
        raise AssertionError("TC 19 Failed - Total Energy consumption UI validation")
    
@keyword("tc20_dark_mode")
def tc20():
    if not hp_ec16.tc20_dark_mode(): 
        raise AssertionError("TC 20 Failed - Dark mode_Energy consumption application failed in darkmode")
    
@keyword("tc21_colorfilter")
def tc21():
    if not hp_ec17.tc21_colorfilter():
        raise AssertionError("TC 21 Failed - Colorfilter-On-Off-Energy consumption application validation failed")    