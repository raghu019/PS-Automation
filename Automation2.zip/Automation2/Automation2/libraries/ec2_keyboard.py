from robot.api.deco import keyword
from ec2 import MyHP as MyHP_EC2
from ec3 import MyHP as MyHP_EC3
from ec4 import MyHP as MyHP_EC4
from ec5 import MyHP as MyHP_EC5
from ec8 import MyHP as MyHP_EC8

hp_ec2 = MyHP_EC2()
hp_ec3 = MyHP_EC3()
hp_ec4 = MyHP_EC4()
hp_ec5 = MyHP_EC5()
hp_ec8 = MyHP_EC8()



@keyword("TC9: Open HP Application via run dialog")
def tc9():
    """Open the HP desktop application."""
    if not hp_ec2.open_energy_consumption_via_run_dialog():
        raise AssertionError("TC9 Failed - Displaying Energy Consumption page failed")
 
@keyword("TC10: Go Beyound-Sustainable Impact Report pdf verification")
def tc10():
    """Open the HP desktop application."""
    if not hp_ec3.verify_go_beyound_sustainable_impact_report():
        raise AssertionError("TC10 Failed - Go Beyound-Sustainable Impact Report pdf verificatio failed")

@keyword("Close HP Application")
def close_hp():
    """Close the HP application."""
    if not hp_ec2.close_hp_application():
        raise AssertionError("Close HP failed")

@keyword("TC11: Navigate to Energy Consumption page with out any crash")
def tc11():
    """Open the Energy consumption page with out any crash."""
    if not hp_ec4.energy_consumption_stability_test():
        raise AssertionError("TC11 Failed - Navigate to Energy Consumption page with out any crash")

#**********Testcase#12 is related to OLDER BIOS with supported platform --Displaying warning message*********

@keyword("TC13: Verifying BIOS warning message on supported platform with latest BIOS")
def tc13():
    if not hp_ec5.tc13_verify_no_bios_warning_message():
        raise AssertionError("TC13 Failed - Not displaying BIOS warning message on supported platform with latest BIOS")
    
#*****TC14: Verify Energy Consumption card is NOT displayed for unsupported BIOS/unsupported platform (ec6.py) ******
#*****TC15: Verify Energy Consumption card is NOT displayed for supported BIOS/unsupported platform (ec7.py) ******    


@keyword("TC16:Verifying Total Energy Consumption Dropdown Stability with out any crash")
def tc16():
    if not hp_ec8.tc16_verify_total_energy_consumption_dropdown_without_any_crash():
        raise AssertionError("TC 16 Failed - Total Energy Consumption Dropdown Stability with out any crash")