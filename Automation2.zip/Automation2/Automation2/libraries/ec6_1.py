import time
import pyautogui
import pygetwindow as gw
from pywinauto import Application
import os
import sys
import io
import pyperclip


class MyHP:
    TIMEOUT = 10

    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"
        self.baseline_folder = r"C:\Testing\Automation2\Automation2\baseline"
        os.makedirs(self.baseline_folder, exist_ok=True)

    # ---------------- Logger ----------------
    def _log_result(self, test_name, status, message=""):
        result = "PASS" if status else "FAIL"
        print(f"[{result}] {test_name}: {message}")

    # ---------------- Open HP Application ----------------
    def open_hp_application(self):
        try:
            pyautogui.press('winleft')
            time.sleep(1)
            pyautogui.write(self.app_title)
            time.sleep(1)
            pyautogui.press('enter')
            time.sleep(12)

            active_window = gw.getActiveWindow()
            if active_window and self.app_title in active_window.title:
                active_window.maximize()
                time.sleep(3)
                self._log_result("Open Application", True, active_window.title)
                return True

            self._log_result("Open Application", False, "Wrong window focused")
            return False

        except Exception as e:
            self._log_result("Open Application", False, str(e))
            return False

    # ---------------- Connect to HP Application ----------------
    def connect_to_application(self):
        try:
            self.application = Application(backend="uia").connect(title_re=self.app_title)
            self.main_window = self.application.window(title_re=self.app_title)
            self.main_window.wait("ready", timeout=self.TIMEOUT)
            self.main_window.set_focus()
            self._log_result("Connect to Application", True)
            return True
        except Exception as e:
            self._log_result("Connect to Application", False, str(e))
            return False

# ---------------- Navigate to PC Device (Optional) ----------------
    def navigate_to_pc_device(self):
        try:
            self.main_window.set_focus()
            time.sleep(5)

            pc_device = self.main_window.child_window(
                auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname",
                control_type="Text"
            )

            if pc_device.exists(timeout=8):
                pc_device.click_input()
                time.sleep(6)
                self._log_result("Navigate to PC Device", True)
                return True

            self._log_result("Navigate to PC Device", True, "Device page not present — continuing test")
            return True  # <-- IMPORTANT: return True even if not found

        except Exception as e:
            self._log_result("Navigate to PC Device", True, f"Skipped: {str(e)}")
            return True  # <-- Never fail test here


    # ---------------- Navigate to Energy Consumption ----------------
    def navigate_to_energy_consumption(self):
        try:
            self.main_window.set_focus()
            time.sleep(3)

            energy_btn = self.main_window.child_window(
                auto_id="PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard",
                control_type="Button"
            )

            self.main_window.type_keys("{PGDN}")
            time.sleep(1)
            self.main_window.type_keys("{UP}{UP}")
            time.sleep(3)

            if energy_btn.exists(timeout=10):
                energy_btn.click_input()
                time.sleep(10)
                self._log_result("Navigate to Energy Consumption", True)
                return True

            self._log_result("Navigate to Energy Consumption", False, "Energy card not found")
            return False

        except Exception as e:
            self._log_result("Navigate to Energy Consumption", False, str(e))
            return False

    # ---------------- Verify BIOS Warning & Click Learn More ----------------
    def verify_warning_and_click_learn_more(self):
        try:
            warning_text = self.main_window.child_window(
                title_re=".*update your BIOS.*",
                control_type="Text"
            )

            learn_more = self.main_window.child_window(
                title="Learn more",
                control_type="Hyperlink"
            )

            if warning_text.exists(timeout=5) and learn_more.exists(timeout=5):
                self._log_result("Verify BIOS Warning Message", True, warning_text.window_text())
                learn_more.click_input()
                time.sleep(10)
                return True

            self._log_result("Verify BIOS Warning Message", False, "Warning or Learn more not found")
            return False

        except Exception as e:
            self._log_result("Verify BIOS Warning Message", False, str(e))
            return False

    # ---------------- Verify Browser URL + Page Text ----------------
    def verify_browser_page_text(self):
        try:
            time.sleep(5)
            browser = gw.getActiveWindow()
            browser.activate()
            time.sleep(2)

            # CTRL+L -> CTRL+C
            pyautogui.hotkey("ctrl", "l")
            time.sleep(1)
            pyautogui.hotkey("ctrl", "c")
            time.sleep(1)

            copied_url = pyperclip.paste()

            if copied_url:
                self._log_result("Verify Browser URL (Copied)", True, copied_url)
            else:
                self._log_result("Verify Browser URL (Copied)", False, "Clipboard empty")
                return False

            # Search page text
            pyautogui.hotkey("ctrl", "f")
            time.sleep(1)
            pyautogui.write("How to Update BIOS Software on Windows PCs")
            time.sleep(2)

            self._log_result("Verify Browser Page Text", True, "Search text entered")
            return True

        except Exception as e:
            self._log_result("Verify Browser Page Text", False, str(e))
            return False

    # ---------------- Close Browser ----------------
    def close_browser(self):
        try:
            pyautogui.hotkey("alt", "f4")
            time.sleep(5)
            self._log_result("Close Browser", True)
            return True
        except Exception as e:
            self._log_result("Close Browser", False, str(e))
            return False

    # ---------------- Refocus HP App ----------------
    def refocus_hp_app(self):
        try:
            windows = gw.getWindowsWithTitle(self.app_title)
            if windows:
                windows[0].activate()
                time.sleep(4)
                self._log_result("Refocus HP App", True, "HP app refocused")
                return True

            self._log_result("Refocus HP App", False, "HP window not found")
            return False

        except Exception as e:
            self._log_result("Refocus HP App", False, str(e))
            return False

    # ---------------- Verify Dropdown & Data Unavailable ----------------
    def verify_consumption_trends(self):
        try:
            self.main_window.set_focus()
            time.sleep(3)

            dropdown = None
            for ctrl_type in ["ComboBox", "Button", "SplitButton"]:
                dropdown = self.main_window.child_window(title_re="Last.*", control_type=ctrl_type)
                if dropdown.exists(timeout=3):
                    break

            if not dropdown or not dropdown.exists():
                self._log_result("Verify Consumption Trends", False, "Trend dropdown not found")
                return False

            dropdown.click_input()
            time.sleep(2)

            popup = self.application.top_window()
            options = ["Last 12 hours", "Last 6 days", "Last 6 months"]

            for option in options:
                item = popup.child_window(title=option, control_type="ListItem")
                if not item.exists(timeout=5):
                    item = self.main_window.child_window(title=option, control_type="ListItem")

                if item.exists(timeout=5):
                    item.click_input()
                    time.sleep(6)

                    data_text = self.main_window.child_window(
                        title_re=".*Data unavailable.*",
                        control_type="Text"
                    )

                    if data_text.exists(timeout=5):
                        self._log_result(f"Verify Chart - {option}", True, "Data unavailable displayed")
                    else:
                        self._log_result(f"Verify Chart - {option}", False, "Data unavailable NOT displayed")

                    dropdown.click_input()
                    time.sleep(2)
                else:
                    self._log_result(f"Verify Chart - {option}", False, "Option not found")

            return True

        except Exception as e:
            self._log_result("Verify Consumption Trends", False, str(e))
            return False

    # ---------------- Verify Total Energy NOT Displayed ----------------
    def verify_total_energy_consumption_not_displayed(self):
        try:
            total_text = self.main_window.child_window(
                title_re=".*Total Energy consumption.*",
                control_type="Text"
            )

            if total_text.exists(timeout=3):
                self._log_result("Verify Total Energy Consumption Section", False,
                                 "Section is DISPLAYED (Expected: NOT displayed)")
                return False
            else:
                self._log_result("Verify Total Energy Consumption Section", True,
                                 "Section is NOT displayed as expected")
                return True

        except Exception as e:
            self._log_result("Verify Total Energy Consumption Section", False, str(e))
            return False

    # ---------------- Dump UI Tree ----------------
    def dump_ui_tree_to_file(self):
        try:
            dump_path = os.path.join(self.baseline_folder, "ui_dump.txt")
            with open(dump_path, "w", encoding="utf-8") as f:
                buffer = io.StringIO()
                sys.stdout = buffer
                self.main_window.print_control_identifiers()
                sys.stdout = sys.__stdout__
                f.write(buffer.getvalue())
                buffer.close()

            self._log_result("Dump UI Tree", True, f"Saved to {dump_path}")
            return True

        except Exception as e:
            sys.stdout = sys.__stdout__
            self._log_result("Dump UI Tree", False, str(e))
            return False

    # ---------------- Close HP Application ----------------
    def close_hp_application(self):
        try:
            self.main_window.set_focus()
            time.sleep(2)

            # Try graceful close
            self.main_window.close()
            time.sleep(5)

            # Verify it's closed
            windows = gw.getWindowsWithTitle(self.app_title)
            if not windows:
                self._log_result("Close HP Application", True, "HP app closed successfully")
                return True

            # Fallback: ALT+F4
            pyautogui.hotkey("alt", "f4")
            time.sleep(5)

            windows = gw.getWindowsWithTitle(self.app_title)
            if not windows:
                self._log_result("Close HP Application", True, "HP app closed using ALT+F4")
                return True

            self._log_result("Close HP Application", False, "HP app still running")
            return False

        except Exception as e:
            self._log_result("Close HP Application", False, str(e))
            return False

#======================Run Test suit========================
    def Tc12_supported_platform_with_olderBIOS(Self):
            print('TC12: Supported platform with older BIOS')
            Self.open_hp_application()
            Self.connect_to_application()
            Self.navigate_to_pc_device()
            Self.navigate_to_energy_consumption()
            Self.verify_warning_and_click_learn_more()
            Self.verify_browser_page_text()
            Self.close_browser()
            Self.refocus_hp_app()
            Self.verify_consumption_trends()
            Self.verify_total_energy_consumption_not_displayed()
            Self.dump_ui_tree_to_file()
            Self.close_hp_application() 
            print("\n====TC12: Supported platform with older BIOS is executed sucessfully ====")
            return True

# ===================== MAIN EXECUTION =====================

if __name__ == "__main__":
    hp = MyHP()

    if hp.Tc12_supported_platform_with_olderBIOS():
            # if hp.connect_to_application():
        #     if hp.navigate_to_energy_consumption():
        #         hp.verify_warning_and_click_learn_more()
        #         hp.verify_browser_page_text()
        #         hp.close_browser()
        #         hp.refocus_hp_app()
        #         hp.verify_consumption_trends()
        #         hp.verify_total_energy_consumption_not_displayed()
        #         hp.dump_ui_tree_to_file()
        #         hp.close_hp_application()
        
        
        print("\n====TC12: Supported platform with older BIOS is executed sucessfully ====")
        

