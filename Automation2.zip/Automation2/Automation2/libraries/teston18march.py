import time
import pyautogui
import pygetwindow as gw
from pywinauto import Application
import pytesseract
import cv2
import numpy as np

# Update this path if needed
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"


class MyHP:

    TIMEOUT = 20

    def __init__(self):
        self.application = None
        self.main_window = None

    # ---------------- Logger ----------------
    def log(self, step, status, msg=""):
        result = "PASS" if status else "FAIL"
        print(f"[{result}] {step}: {msg}")

    # ---------------- Open HP Application ----------------
    def open_hp_application(self):
        try:
            pyautogui.press("win")
            time.sleep(2)

            pyautogui.write("HP")
            time.sleep(2)

            pyautogui.press("enter")
            time.sleep(20)

            window = gw.getActiveWindow()

            if window:
                window.maximize()
                time.sleep(5)
                self.log("Open HP Application", True)
                return True

            return False

        except Exception as e:
            self.log("Open HP Application", False, str(e))
            return False

    # ---------------- Connect to Application ----------------
    def connect_to_application(self):
        try:
            time.sleep(5)

            windows = [w for w in gw.getWindowsWithTitle("HP") if w.title.strip() != ""]

            if not windows:
                self.log("Connect to Application", False, "No HP window found")
                return False

            hp_window = windows[0]

            print(f"Connecting to window: {hp_window.title}")

            self.application = Application(backend="uia").connect(handle=hp_window._hWnd)
            self.main_window = self.application.window(handle=hp_window._hWnd)

            self.main_window.wait("ready", timeout=self.TIMEOUT)

            self.log("Connect to Application", True)
            return True

        except Exception as e:
            self.log("Connect to Application", False, str(e))
            return False

    # ---------------- Navigate to PC Device ----------------
    def navigate_to_pc_device(self):
        try:
            pc_device = self.main_window.child_window(
                auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname",
                control_type="Text"
            )

            if pc_device.exists(timeout=15):
                pc_device.click_input()
                time.sleep(10)
                self.log("Navigate to PC Device", True)
                return True

            return False

        except Exception as e:
            self.log("Navigate to PC Device", False, str(e))
            return False

    # ---------------- Navigate to Energy Consumption ----------------
    def navigate_to_energy_consumption(self):

        print("\nTEST CASE: Navigate to Energy Consumption")
        print("-" * 60)

        try:
            self.main_window.set_focus()
            time.sleep(3)

            self.main_window.type_keys("{PGDN}")
            time.sleep(2)

            self.main_window.type_keys("{PGDN}")
            time.sleep(2)

            energy_btn = self.main_window.child_window(
                auto_id="PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard",
                control_type="Button"
            )

            if energy_btn.exists(timeout=10):
                energy_btn.click_input()
                time.sleep(10)
                self.log("Navigate to Energy Consumption", True)
                return True

            return False

        except Exception as e:
            self.log("Navigate to Energy Consumption", False, str(e))
            return False

    # ---------------- Detect Collecting Data ----------------
    def detect_collecting_data(self):
        try:
            screenshot = pyautogui.screenshot()
            img = np.array(screenshot)
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

            text = pytesseract.image_to_string(gray)

            return "collecting" in text.lower()

        except:
            return False

    # ---------------- Verify Collecting Data ----------------
    def verify_collecting_data(self):

        print("\nTEST CASE: Verify Collecting Data in Chart")
        print("-" * 60)

        dropdowns = [
            ("Last 12 hours", 0),
            ("Last 6 days", 1),
            ("Last 6 months", 2)
        ]

        try:
            dropdown = self.main_window.child_window(control_type="ComboBox", found_index=0)

            if not dropdown.exists(timeout=10):
                self.log("Dropdown Detection", False, "Dropdown not found")
                return

            for name, index in dropdowns:

                print(f"\nChecking → {name}")

                dropdown.click_input()
                time.sleep(2)

                for _ in range(index):
                    pyautogui.press("down")
                    time.sleep(0.5)

                pyautogui.press("enter")

                # Step 1: Detect "Collecting data"
                collecting_found = False
                for _ in range(5):
                    time.sleep(1)
                    if self.detect_collecting_data():
                        collecting_found = True
                        break

                # Step 2: Wait for chart load
                chart_loaded = False
                for _ in range(5):
                    time.sleep(1)
                    if not self.detect_collecting_data():
                        chart_loaded = True
                        break

                if collecting_found and chart_loaded:
                    self.log(name, True, "Collecting data → Chart Loaded")
                else:
                    self.log(name, False, "Flow failed")

        except Exception as e:
            self.log("Dropdown Verification", False, str(e))

    # ---------------- Main Flow ----------------
    def run_test(self):

        print("\nSTARTING HP AUTOMATION")
        print("=" * 60)

        if not self.open_hp_application():
            return

        if not self.connect_to_application():
            return

        if not self.navigate_to_pc_device():
            return

        if not self.navigate_to_energy_consumption():
            return

        self.verify_collecting_data()

        print("\nTEST EXECUTION COMPLETED")
        print("=" * 60)


if __name__ == "__main__":

    hp = MyHP()
    hp.run_test()