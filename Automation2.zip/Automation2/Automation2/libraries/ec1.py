import time
import pyautogui
import pygetwindow as gw
from pywinauto import Application
import os
import sys
import io
from pywinauto.keyboard import send_keys
import pyperclip
import json
from datetime import datetime, timedelta
from collections import defaultdict
import ctypes
import ctypes.wintypes as wintypes

class MyHP:
    TIMEOUT = 5

    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"
        self.baseline_folder = r"C:\Testing\Automation2\Automation2\baseline"

    # ---------------- Logger ----------------
    def _log_result(self, test_name, status, message=""):
        result = "PASS" if status else "FAIL"
        print(f"[{result}] {test_name}: {message}")

    def _log_debug(self, message):
        print(f"[DEBUG] {message}")

    # ---------------- Open HP Application ----------------
    def open_hp_application(self):
        try:
            pyautogui.press('winleft')
            time.sleep(1)
            pyautogui.write(self.app_title)
            time.sleep(1)
            pyautogui.press('enter')
            time.sleep(5)

            active_window = gw.getActiveWindow()
            if active_window and self.app_title in active_window.title:
                active_window.maximize()
                time.sleep(15)
                self._log_result("Open Application", True)
                return True
            else:
                self._log_result("Open Application", False, "Wrong window focused")
                return False
        except Exception as e:
            self._log_result("Open Application", False, str(e))
            return False

    # ---------------- Connect to HP Application ----------------
    def connect_to_application(self):
        try:
            self.application = Application(backend="uia").connect(title_re=self.app_title)
            self.main_window = self.application.window(title_re=self.app_title)
            self.main_window.wait("ready", timeout=self.TIMEOUT)
            self._log_result("Connect to Application", True)
            return True
        except Exception as e:
            self._log_result("Connect to Application", False, str(e))
            return False

     # ---------------- Navigate to PC Device ----------------
    def navigate_to_pc_device(self):
        try:
            pc_device = self.main_window.child_window(
                auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname",
                control_type="Text"
            )
            if pc_device.exists(timeout=5):
                pc_device.click_input()
                time.sleep(5)
                self._log_result("Navigate to PC Device", True)
                return True
            self._log_result("Navigate to PC Device", False, "PC device not found")
            return True
        except Exception as e:
            self._log_result("Navigate to PC Device", False, str(e))
            return False

    # ---------------- Dump UI Tree ----------------
    def dump_ui_tree_to_file(self):
        if not self.main_window:
            self._log_result("Dump UI Tree", False, "Application not connected")
            return False
        try:
            dump_path = os.path.join(self.baseline_folder, "ui_dump.txt")
            with open(dump_path, "w", encoding="utf-8") as f:
                buffer = io.StringIO()
                sys.stdout = buffer
                self.main_window.print_control_identifiers()
                sys.stdout = sys.__stdout__
                f.write(buffer.getvalue())
                buffer.close()
            self._log_result("Dump UI Tree", True, f"Saved to {dump_path}")
            return True
        except Exception as e:
            sys.stdout = sys.__stdout__
            self._log_result("Dump UI Tree", False, str(e))
            return False

    # ---------------- Navigate to Energy Consumption ----------------
    def navigate_to_Energy_consumption(self):
        print("\nTEST CASE 1: Navigate to Energy Consumption module")
        print("-" * 60)

        if not self.main_window:
            self._log_result("Navigate to Energy consumption", False, "Application not connected")
            print("Test case 'Navigate to Energy consumption' completed : FAIL")
            print("-" * 60)
            return False

        try:
            self.main_window.set_focus()
            time.sleep(5)

            energy_btn = self.main_window.child_window(
                auto_id="PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard",
                control_type="Button"
            )

            self.main_window.type_keys("{PGDN}")
            time.sleep(1)
            self.main_window.type_keys("{UP}")
            time.sleep(0.5)
            self.main_window.type_keys("{UP}")
            time.sleep(4)

            if energy_btn.exists(timeout=8):
                energy_btn.click_input()
                time.sleep(10)
                self._log_result("Navigate to Energy consumption", True)
                print("-" * 60)
                return True

            self._log_result(
                "Navigate to Energy consumption page",
                False,
                "Energy consumption card not visible after PGDN + UP UP"
            )
            print("-" * 60)
            return False
        except Exception as e:
            self._log_result("Navigate to Energy consumption page", False, str(e))
            print("-" * 60)
            return False

    # ---------------- Click Hyperlinks ----------------
    def click_energy_links(self):
        time.sleep(3)
        print("\nTEST CASE 2: Clicking on Hyperlinks")
        print("-" * 60)
        pyautogui.scroll(-400)
        time.sleep(3)

        guide_titles = [
            "Learn more about Go Beyond",
        ]

        success = False
        for title in guide_titles:
            try:
                link = self.main_window.child_window(title=title, control_type="Hyperlink")
                if link.exists(timeout=self.TIMEOUT):
                    link.click_input()
                    print(f"[PASS] Clicked hyperlink: {title}")
                    success |= self._check_and_close_browser(title, wait_time=20)
                    print("[PASS] Navigate to hyperlinks success")
                    print("-" * 60)
                    return True
                else:
                    print(f"[FAIL] Hyperlink not found: {title}")
                    print("-" * 60)
            except Exception as e:
                print(f"[FAIL] Error clicking hyperlink '{title}': {e}")
                print("-" * 60)
        return success

    # ---------------- Click Button Links ----------------
    def click_energy_buttonlinks(self):
        time.sleep(3)
        print("\nTEST CASE 3: Clicking on HyperButton")
        print("-" * 60)
        pyautogui.scroll(-2600)
        self.main_window.type_keys("{PGDN}")
        time.sleep(1)

        for _ in range(7):
            self.main_window.type_keys("{UP}")
            time.sleep(0.5)
            time.sleep(3)

        guide_titles = [
            "How to adjust power and sleep settings in Windows",
            "Caring for your battery in Windows",
            "Battery saving tips for Windows",
            "Change the power mode for your Windows PC",
            "Manage background activity for apps in Windows",
            "Learn more about energy recommendations - Microsoft Support",
        ]

        success = False
        for title in guide_titles:
            try:
                btn = self.main_window.child_window(title=title, control_type="Button")
                if btn.exists(timeout=self.TIMEOUT):
                    btn.click_input()
                    print(f"[PASS] Clicked button: {title}")
                    success |= self._check_and_close_browser(title, wait_time=20)
                    print("-" * 60)
                else:
                    print(f"[FAIL] Button not found: {title}")
                    print("-" * 60)
            except Exception as e:
                print(f"[FAIL] Error clicking button '{title}': {e}")
                print("-" * 60)
        return success

    # ---------------- Click More Helpful Links ----------------
    def click_energy_buttonlinks_morehelpful(self):
        time.sleep(3)
        print("\nTEST CASE 4: Clicking on more helpful links")
        print("-" * 60)
        pyautogui.scroll(-2600)
        self.main_window.type_keys("{PGDN}")
        time.sleep(1)

        guide_titles = [
            "Product Carbon Footprint",
            "Learn more about Go Beyond",
            "Energy and the Environment - Epa.gov"
        ]

        success = False
        for title in guide_titles:
            try:
                btn = self.main_window.child_window(title=title, control_type="Button")
                if btn.exists(timeout=self.TIMEOUT):
                    btn.click_input()
                    print(f"[PASS] Clicked button: {title}")
                    success |= self._check_and_close_browser(title, wait_time=20)
                    print("-" * 60)
                else:
                    print(f"[FAIL] Button not found: {title}")
                    print("-" * 60)
            except Exception as e:
                print(f"[FAIL] Error clicking button '{title}': {e}")
                print("-" * 60)
        return success

    # ---------------- Browser Handling ----------------
    def _check_and_close_browser(self, title, expected_urls=None, wait_time=15):
        try:
            time.sleep(5)
            browser_windows = [
                w for w in gw.getAllWindows()
                if w.title and any(b in w.title.lower() for b in ["edge", "chrome", "firefox"])
            ]
            if not browser_windows:
                print(f"[FAIL] No browser detected for: {title}")
                return False

            for browser in browser_windows:
                browser.activate()
                time.sleep(2)
                browser.maximize()
                time.sleep(2)

                url = self._get_browser_url()
                print(f"[PASS] Detected URL: {url}")

                if expected_urls:
                    if not any(expected in url for expected in expected_urls):
                        print("❌ URL validation failed")
                        return False
                    print("✅ URL validated")

                time.sleep(wait_time)
                browser.close()
                print(f"[PASS] Closed browser: {browser.title}")

            hp_window = gw.getWindowsWithTitle(self.app_title)
            if hp_window:
                hp_window[0].activate()
                print("[PASS] HP app refocused")

            return True
        except Exception as e:
            print(f"[FAIL] Browser handling failed: {e}")
            return False

    def _get_browser_url(self):
        try:
            time.sleep(1)
            pyautogui.hotkey("ctrl", "l")
            time.sleep(1)
            pyautogui.hotkey("ctrl", "c")
            time.sleep(1)
            return pyperclip.paste()
        except Exception:
            return ""

    # ---------------- Close HP Application ----------------
    def close_hp_application(self):
        try:
            if self.main_window:
                self.main_window.set_focus()
                time.sleep(1)
                self.main_window.close()
                time.sleep(3)
                if not self.main_window.exists(timeout=3):
                    self._log_result("Close Application", True, "Closed using pywinauto")
                    return True

            hp_windows = gw.getWindowsWithTitle(self.app_title)
            if hp_windows:
                hp_windows[0].activate()
                time.sleep(1)
                pyautogui.hotkey('alt', 'f4')
                time.sleep(2)
                self._log_result("Close Application", True, "Closed using Alt+F4")
                return True

            self._log_result("Close Application", False, "HP window not found")
            return False
        except Exception as e:
            self._log_result("Close Application", False, str(e))
            return False


    # ---------------- Run Test Suite ----------------
    def run_energy_consumption_test_suite(self):
        self.open_hp_application()
        self.connect_to_application()
        self.navigate_to_pc_device()
        self.navigate_to_Energy_consumption()
        self.click_energy_links()
        self.click_energy_buttonlinks()
        self.click_energy_buttonlinks_morehelpful()
        self.close_hp_application()


if __name__ == "__main__":
    hp_test = MyHP()
    hp_test.run_energy_consumption_test_suite()
