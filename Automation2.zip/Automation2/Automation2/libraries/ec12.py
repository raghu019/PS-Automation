import time
import pyautogui
import pygetwindow as gw
from pywinauto import Application
import os
import sys
import io
from pywinauto.keyboard import send_keys
import pyperclip
import json
from datetime import datetime, timedelta
from collections import defaultdict
import ctypes
import ctypes.wintypes as wintypes

class MyHP:
    TIMEOUT = 5

    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"
        self.baseline_folder = r"C:\Testing\Automation2\Automation2\baseline"

    # ---------------- Logger ----------------
    def _log_result(self, test_name, status, message=""):
        result = "PASS" if status else "FAIL"
        print(f"[{result}] {test_name}: {message}")

    def _log_debug(self, message):
        print(f"[DEBUG] {message}")

    # ---------------- Open HP Application ----------------
    def open_hp_application(self):
        try:
            pyautogui.press('winleft')
            time.sleep(1)
            pyautogui.write(self.app_title)
            time.sleep(1)
            pyautogui.press('enter')
            time.sleep(5)

            active_window = gw.getActiveWindow()
            if active_window and self.app_title in active_window.title:
                active_window.maximize()
                time.sleep(15)
                self._log_result("Open Application", True)
                return True
            else:
                self._log_result("Open Application", False, "Wrong window focused")
                return False
        except Exception as e:
            self._log_result("Open Application", False, str(e))
            return False

    # ---------------- Connect to HP Application ----------------
    def connect_to_application(self):
        try:
            self.application = Application(backend="uia").connect(title_re=self.app_title)
            self.main_window = self.application.window(title_re=self.app_title)
            self.main_window.wait("ready", timeout=self.TIMEOUT)
            self._log_result("Connect to Application", True)
            return True
        except Exception as e:
            self._log_result("Connect to Application", False, str(e))
            return False

     # ---------------- Navigate to PC Device ----------------
    def navigate_to_pc_device(self):
        try:
            pc_device = self.main_window.child_window(
                auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname",
                control_type="Text"
            )
            if pc_device.exists(timeout=5):
                pc_device.click_input()
                time.sleep(5)
                self._log_result("Navigate to PC Device", True)
                return True
            self._log_result("Navigate to PC Device", False, "PC device not found")
            return True
        except Exception as e:
            self._log_result("Navigate to PC Device", False, str(e))
            return False

    # ---------------- Dump UI Tree ----------------
    def dump_ui_tree_to_file(self):
        if not self.main_window:
            self._log_result("Dump UI Tree", False, "Application not connected")
            return False
        try:
            dump_path = os.path.join(self.baseline_folder, "ui_dump.txt")
            with open(dump_path, "w", encoding="utf-8") as f:
                buffer = io.StringIO()
                sys.stdout = buffer
                self.main_window.print_control_identifiers()
                sys.stdout = sys.__stdout__
                f.write(buffer.getvalue())
                buffer.close()
            self._log_result("Dump UI Tree", True, f"Saved to {dump_path}")
            return True
        except Exception as e:
            sys.stdout = sys.__stdout__
            self._log_result("Dump UI Tree", False, str(e))
            return False

    # ---------------- Navigate to Energy Consumption ----------------
    def navigate_to_Energy_consumption(self):
        print("\nTEST CASE 1: Navigate to Energy Consumption module")
        print("-" * 60)

        if not self.main_window:
            self._log_result("Navigate to Energy consumption", False, "Application not connected")
            print("Test case 'Navigate to Energy consumption' completed : FAIL")
            print("-" * 60)
            return False

        try:
            self.main_window.set_focus()
            time.sleep(5)

            energy_btn = self.main_window.child_window(
                auto_id="PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard",
                control_type="Button"
            )

            self.main_window.type_keys("{PGDN}")
            time.sleep(1)
            self.main_window.type_keys("{UP}")
            time.sleep(0.5)
            self.main_window.type_keys("{UP}")
            time.sleep(4)

            if energy_btn.exists(timeout=8):
                energy_btn.click_input()
                time.sleep(10)
                self._log_result("Navigate to Energy consumption", True)
                print("-" * 60)
                return True

            self._log_result(
                "Navigate to Energy consumption page",
                False,
                "Energy consumption card not visible after PGDN + UP UP"
            )
            print("-" * 60)
            return False
        except Exception as e:
            self._log_result("Navigate to Energy consumption page", False, str(e))
            print("-" * 60)
            return False


    # ---------------- Close HP Application ----------------
    def close_hp_application(self):
        try:
            if self.main_window:
                self.main_window.set_focus()
                time.sleep(1)
                self.main_window.close()
                time.sleep(3)
                if not self.main_window.exists(timeout=3):
                    self._log_result("Close Application", True, "Closed using pywinauto")
                    return True

            hp_windows = gw.getWindowsWithTitle(self.app_title)
            if hp_windows:
                hp_windows[0].activate()
                time.sleep(1)
                pyautogui.hotkey('alt', 'f4')
                time.sleep(2)
                self._log_result("Close Application", True, "Closed using Alt+F4")
                return True

            self._log_result("Close Application", False, "HP window not found")
            return False
        except Exception as e:
            self._log_result("Close Application", False, str(e))
            return False

    # ---------------- Dropdown ----------------
    def select_consumption_dropdown(self, option_text):
        try:
            time.sleep(2)
            dropdown = self.main_window.child_window(
                title_re="Last.*hours|Last.*days|Last.*months",
                control_type="ComboBox"
            )
            dropdown.wait("ready", timeout=5)
            dropdown.click_input()
            time.sleep(1)

            list_item = self.main_window.child_window(
                title=option_text,
                control_type="ListItem"
            )
            if list_item.exists(timeout=5):
                list_item.click_input()
                time.sleep(3)
                self._log_result("Select Dropdown", True, option_text)
                return True

            self._log_result("Select Dropdown", False, f"{option_text} not found")
            return False
        except Exception as e:
            self._log_result("Select Dropdown", False, str(e))
            return False

    # ---------------- Is App Alive ----------------
    def is_application_alive(self):
        try:
            if not self.main_window.exists(timeout=3):
                return False
            self.main_window.wait("ready", timeout=3)
            return True
        except Exception:
            return False

    # ---------------- Test Cases ----------------
    def verify_no_crash_while_switching_dropdown(self):
        self.main_window.type_keys("{PGUP}")
        self.main_window.type_keys("{PGUP}")
        self.main_window.type_keys("{PGUP}")
        time.sleep(3)
        print("\nTEST CASE 5: Verify app does not crash while switching dropdown")
        print("-" * 60)

        for i in range(5):
         print("--" * 30)   
         print(f"Running test iteration {i + 1}/5")
         print ("--" * 30)
         options = ["Last 12 hours", "Last 6 days", "Last 6 months"]
         for i in range(len(options)):
            current = options[i]
            next_opt = options[(i + 1) % len(options)]

            if not self.select_consumption_dropdown(current):
                self._log_result("TC5 Dropdown Switch", False, f"Failed to select {current}")
                return False
            if not self.select_consumption_dropdown(next_opt):
                self._log_result("TC5 Dropdown Switch", False, f"Failed to switch to {next_opt}")
                return False
            time.sleep(2)
            if not self.is_application_alive():
                self._log_result("TC5 Application Stability", False, f"Application crashed while switching {current} → {next_opt}")
                return False
            self._log_result("TC5 Application Stability", True, f"Switched {current} → {next_opt} without crash")
        return True


    # ---------------- Run Test Suite ----------------
    def tc4_verify_no_crash_while_switching_dropdown(self):
        if not self.open_hp_application():
            return False
        if not self.connect_to_application():
            return False
        if not self.navigate_to_pc_device():
            return False
        if not self.navigate_to_Energy_consumption():
            return False
        if not self.verify_no_crash_while_switching_dropdown():
            return False
        if not self.close_hp_application():
            return False
        return True


if __name__ == "__main__":
    hp_test = MyHP()
    hp_test.tc4_verify_no_crash_while_switching_dropdown()
