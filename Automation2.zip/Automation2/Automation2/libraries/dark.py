import time
import pyautogui
import pygetwindow as gw
from pywinauto import Application
import winreg


class MyHP:
    TIMEOUT = 10

    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"

    # ---------------- Logger ----------------
    def log(self, name, status, msg=""):
        print(f"[{'PASS' if status else 'FAIL'}] {name}: {msg}")

    # ---------------- Step 1: Enable Dark Mode ----------------
    def enable_dark_mode(self):
        try:
            path = r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize"

            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, path, 0, winreg.KEY_SET_VALUE)

            winreg.SetValueEx(key, "AppsUseLightTheme", 0, winreg.REG_DWORD, 0)
            winreg.SetValueEx(key, "SystemUsesLightTheme", 0, winreg.REG_DWORD, 0)

            winreg.CloseKey(key)

            time.sleep(3)
            self.log("Step1 Dark Mode", True)
            return True
        except Exception as e:
            self.log("Step1 Dark Mode", False, str(e))
            return False

    # ---------------- Step 2: Open App ----------------
    def open_app(self):
        try:
            pyautogui.press('win')
            time.sleep(1)
            pyautogui.write(self.app_title)
            time.sleep(1)
            pyautogui.press('enter')
            time.sleep(10)

            win = gw.getActiveWindow()
            if win and self.app_title in win.title:
                win.maximize()
                time.sleep(10)
                self.log("Launch HP App", True)
                return True

            self.log("Launch HP App", False)
            return False
        except Exception as e:
            self.log("Launch HP App", False, str(e))
            return False

    # ---------------- Connect ----------------
    def connect(self):
        try:
            self.application = Application(backend="uia").connect(title_re=self.app_title)
            self.main_window = self.application.window(title_re=self.app_title)
            self.main_window.wait("ready", timeout=self.TIMEOUT)
            self.log("Connect App", True)
            return True
        except Exception as e:
            self.log("Connect App", False, str(e))
            return False

    # ---------------- Navigate PC ----------------
    def go_to_pc(self):
        try:
            pc = self.main_window.child_window(
                auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname",
                control_type="Text"
            )

            if pc.exists(timeout=5):
                pc.click_input()
                time.sleep(5)
                self.log("Navigate PC", True)
                return True

            self.log("Navigate PC", False)
            return False
        except Exception as e:
            self.log("Navigate PC", False, str(e))
            return False

    # ---------------- Dark Mode Validation ----------------
    def verify_dark(self, location=""):
        try:
            self.main_window.set_focus()
            time.sleep(2)

            # Placeholder (can enhance later)
            self.log(f"Dark Mode Check {location}", True)
            return True
        except Exception as e:
            self.log(f"Dark Mode Check {location}", False, str(e))
            return False

    # ---------------- Step 3: Energy Page ----------------
    def open_energy(self):
        try:
            self.main_window.set_focus()

            self.main_window.type_keys("{PGDN}")
            time.sleep(1)
            self.main_window.type_keys("{UP}")
            time.sleep(1)

            btn = self.main_window.child_window(
                auto_id="PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard",
                control_type="Button"
            )

            if btn.exists(timeout=8):
                btn.click_input()
                time.sleep(10)
                self.log("Open Energy Page", True)
                return True

            self.log("Open Energy Page", False)
            return False

        except Exception as e:
            self.log("Open Energy Page", False, str(e))
            return False

    # ---------------- Dropdown ----------------
    def select_dropdown(self, text):
        try:
            dropdown = self.main_window.child_window(control_type="ComboBox")
            dropdown.click_input()
            time.sleep(1)

            item = self.main_window.child_window(title=text, control_type="ListItem")

            if item.exists(timeout=5):
                item.click_input()
                time.sleep(2)
                self.log("Dropdown", True, text)
                return True

            self.log("Dropdown", False, text)
            return False
        except Exception as e:
            self.log("Dropdown", False, str(e))
            return False

    # ---------------- Stability ----------------
    def dropdown_test(self):
        options = ["Last 12 hours", "Last 6 days", "Last 6 months"]

        for i in range(3):
            print(f"\nIteration {i+1}")

            for j in range(len(options)):
                curr = options[j]
                nxt = options[(j + 1) % len(options)]

                if not self.select_dropdown(curr):
                    return False
                if not self.select_dropdown(nxt):
                    return False

                if not self.main_window.exists(timeout=3):
                    self.log("App Crash", False)
                    return False

                self.log("Switch OK", True, f"{curr} → {nxt}")

        return True

    # ---------------- Close ----------------
    def close(self):
        try:
            self.main_window.close()
            time.sleep(3)
            self.log("Close App", True)
            return True
        except Exception:
            pyautogui.hotkey('alt', 'f4')
            self.log("Close App", True)
            return True

    # ---------------- SINGLE TEST CASE ----------------
    def run_test(self):
        print("\n===== SINGLE TEST CASE: DARK MODE + ENERGY + DROPDOWN =====\n")

        if not self.enable_dark_mode(): return
        if not self.open_app(): return
        if not self.connect(): return

        if not self.verify_dark("Home"): return

        if not self.go_to_pc(): return

        if not self.open_energy(): return
        if not self.verify_dark("Energy Page"): return

        if not self.dropdown_test(): return

        self.close()

        print("\n✅ TEST COMPLETED SUCCESSFULLY")


# ---------------- RUN ----------------
if __name__ == "__main__":
    MyHP().run_test()