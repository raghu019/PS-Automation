import time
import pyautogui
import pygetwindow as gw
from pywinauto import Application
import winreg
import os
from datetime import datetime
from PIL import Image, ImageChops
import cv2
from skimage.metrics import structural_similarity as ssim
import numpy as np


class MyHP:
    TIMEOUT = 10

    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"

    # ---------------- Logger ----------------
    def log(self, name, status, msg=""):
        print(f"[{'PASS' if status else 'FAIL'}] {name}: {msg}")
    
    def _log_result(self, name, status, msg=""):
        print(f"[{'PASS' if status else 'FAIL'}] {name}: {msg}")

    def _log_debug(self, msg):
        print(f"[DEBUG] {msg}")

    # ---------------- Theme Handling ----------------
    def set_theme(self, dark=True):
        try:
            path = r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize"
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, path, 0, winreg.KEY_SET_VALUE)

            value = 0 if dark else 1
            winreg.SetValueEx(key, "AppsUseLightTheme", 0, winreg.REG_DWORD, value)
            winreg.SetValueEx(key, "SystemUsesLightTheme", 0, winreg.REG_DWORD, value)

            winreg.CloseKey(key)

            time.sleep(5)
            mode = "Dark" if dark else "Light"
            self.log(f"{mode} Mode Applied", True)
            return True

        except Exception as e:
            self.log("Theme Change", False, str(e))
            return False

    # ---------------- Open App ----------------
    def open_app(self):
        try:
            pyautogui.press('win')
            time.sleep(1)
            pyautogui.write(self.app_title)
            time.sleep(1)
            pyautogui.press('enter')
            time.sleep(10)

            win = gw.getActiveWindow()
            if win and self.app_title in win.title:
                win.maximize()
                time.sleep(8)
                self.log("Launch HP App", True)
                return True

            self.log("Launch HP App", False)
            return False

        except Exception as e:
            self.log("Launch HP App", False, str(e))
            return False

    # ---------------- Connect ----------------
    def connect(self):
        try:
            self.application = Application(backend="uia").connect(title_re=self.app_title)
            self.main_window = self.application.window(title_re=self.app_title)
            self.main_window.wait("ready", timeout=self.TIMEOUT)
            self.log("Connect App", True)
            return True
        except Exception as e:
            self.log("Connect App", False, str(e))
            return False

    # ---------------- Navigate PC ----------------
    def go_to_pc(self):
        try:
            pc = self.main_window.child_window(
                auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname",
                control_type="Text"
            )

            if pc.exists(timeout=5):
                pc.click_input()
                time.sleep(5)
                self.log("Navigate PC", True)
                return True

            self.log("Navigate PC", False)
            return False

        except Exception as e:
            self.log("Navigate PC", False, str(e))
            return False

    # ---------------- Energy Page ----------------
    def open_energy(self):
        try:
            self.main_window.set_focus()

            self.main_window.type_keys("{PGDN}")
            time.sleep(1)
            self.main_window.type_keys("{UP}")
            time.sleep(1)

            btn = self.main_window.child_window(
                auto_id="PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard",
                control_type="Button"
            )

            if btn.exists(timeout=8):
                btn.click_input()
                time.sleep(10)
                self.log("Open Energy Page", True)
                return True

            self.log("Open Energy Page", False)
            return False

        except Exception as e:
            self.log("Open Energy Page", False, str(e))
            return False

    # ---------------- Dropdown ----------------
    def select_dropdown(self, text):
        try:
            dropdown = self.main_window.child_window(control_type="ComboBox")
            dropdown.click_input()
            time.sleep(1)

            item = self.main_window.child_window(title=text, control_type="ListItem")

            if item.exists(timeout=5):
                item.click_input()
                time.sleep(2)
                self.log("Dropdown", True, text)
                return True

            self.log("Dropdown", False, text)
            return False

        except Exception as e:
            self.log("Dropdown", False, str(e))
            return False

    # ---------------- Stability ----------------
    def dropdown_test(self):
        options = ["Last 12 hours", "Last 6 days", "Last 6 months"]

        for i in range(2):
            print(f"\nIteration {i+1}")

            for j in range(len(options)):
                curr = options[j]
                nxt = options[(j + 1) % len(options)]

                if not self.select_dropdown(curr):
                    return False
                if not self.select_dropdown(nxt):
                    return False

                if not self.main_window.exists(timeout=3):
                    self.log("App Crash", False)
                    return False

                self.log("Switch OK", True, f"{curr} → {nxt}")

        return True

     # ---------------- Scroll to Total Energy Section ----------------
    def scroll_to_total_energy_section(self):
        self._log_result("Scrolling to Total Energy Consumption section", True)
        self.main_window.type_keys("{PGDN}")
        time.sleep(1)
        time.sleep(10)  # mandatory stabilization wait

    # ---------------- Dropdown Select ----------------
    def select_total_energy_value(self, option_text):
        try:
            dropdown = self.main_window.child_window(control_type="ComboBox")
            dropdown.wait("visible", timeout=10)

            dropdown.wrapper_object().expand()
            time.sleep(5)

            option = self.main_window.child_window(
                title=option_text,
                control_type="ListItem"
            )
            option.wait("visible", timeout=10)
            option.click_input()
            time.sleep(5)

            self._log_result("Select Total Energy Dropdown", True, option_text)
            return True

        except Exception as e:
            self._log_result("Select Total Energy Dropdown", False, str(e))
            return False

    # ---------------- Crash Verification (FIXED) ----------------
    def verify_energy_page_not_crashed(self):
        try:
            if self.main_window.exists(timeout=2) and self.main_window.is_visible():
                self._log_result(
                    "Energy Consumption Crash Check",
                    True,
                    "Application is responsive"
                )
                return True

            self._log_result(
                "Energy Consumption Crash Check",
                False,
                "Main window not visible"
            )
            return False

        except Exception as e:
            self._log_result(
                "Energy Consumption Crash Check",
                False,
                f"Exception occurred: {e}"
            )
            return False


    #-------------------Total Energy dropdown stability------------------
    def tc_verify_total_energy_dropdown_stability(self):
        print("\n Total Energy Consumption Dropdown Stability with out any crash")
        print("-" * 60)

        self.scroll_to_total_energy_section()

        for i in range(1,3):
            print(f"\nIteration {i}")

            if not self.select_total_energy_value("Last Week"):
                return False
            if not self.verify_energy_page_not_crashed():
                return False

            if not self.select_total_energy_value("Last Month"):
                return False
            if not self.verify_energy_page_not_crashed():
                return False

        self._log_result(
            "Energy Consumption Dropdown Stability",
            True,
            f"No crash after {i} iterations"
        )
        print("-" * 60)
        return True

    # ---------------- Screenshot Capture ----------------
    def capture_energy_screenshot(self, mode):
     try:
        # Ensure folder exists
        folder = r"C:\Testing\Automation2\Automation2\baseline\Base"
        os.makedirs(folder, exist_ok=True)

        # Scroll actions
        self.main_window.set_focus()
        time.sleep(2)

       # self.main_window.type_keys("{PGDN}")
        #time.sleep(3)

        #self.main_window.type_keys("{PGUP}")
        #time.sleep(3)

        # File name
        file_path = os.path.join(folder, f"energy_{mode}.png")

        # Capture screenshot
        screenshot = pyautogui.screenshot()
        screenshot.save(file_path)

        self._log_result("Screenshot Captured", True, file_path)
        return True

     except Exception as e:
        self._log_result("Screenshot Capture Failed", False, str(e))
        return False
    
    # ---------------- Image Comparison ----------------
    def compare_images(self, img1_path, img2_path, threshold=0.95):
     try:
        if not os.path.exists(img1_path):
            self._log_result("Image Compare", False, f"Missing: {img1_path}")
            return False

        if not os.path.exists(img2_path):
            self._log_result("Image Compare", False, f"Missing: {img2_path}")
            return False

        # Read images using OpenCV
        img1 = cv2.imread(img1_path)
        img2 = cv2.imread(img2_path)

        # Resize if different
        if img1.shape != img2.shape:
            img2 = cv2.resize(img2, (img1.shape[1], img1.shape[0]))

        # Convert to grayscale
        gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
        gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)

        # Compute SSIM
        score, diff = ssim(gray1, gray2, full=True)

        similarity = round(score * 100, 2)

        if score >= threshold:
            self._log_result("Image Compare", True, f"Match: {similarity}%")
            return True
        else:
            self._log_result("Image Compare", False, f"Mismatch: {similarity}%")
            return False

     except Exception as e:
        self._log_result("Image Compare", False, str(e))
        return False
   
   #-------Comparing screenshots-------------------
     
    def compare_all_screenshots(self):
        base_path = r"C:\Testing\Automation2\Automation2\baseline\Output"
        output_path = r"C:\Testing\Automation2\Automation2\baseline\Base"

        results = []
    
        for file in os.listdir(base_path):
            if file.endswith(".png"):
                base_img = os.path.join(base_path, file)
                output_img = os.path.join(output_path, file)

                print(f"\nComparing: {file}")

                result = self.compare_images(base_img, output_img)
                results.append(result)

        if all(results):
            self._log_result("Final Image Comparison", True, "All images matched")
            return True
        else:
            self._log_result("Final Image Comparison", False, "Some images mismatched")
        return False
    
    
    # ---------------- Close ----------------
    def close(self):
        try:
            self.main_window.close()
            time.sleep(3)
            self.log("Close App", True)
        except Exception:
            pyautogui.hotkey('alt', 'f4')
            self.log("Close App", True)

    # ---------------- FULL FLOW ----------------
    def tc20_dark_mode(self):
        try:
          print("\n========= FULL TEST: DARK → LIGHT → RE-VALIDATE =========\n")

            # -------- DARK MODE FLOW --------
          if not self.set_theme(dark=True): return False
          if not self.open_app(): return False 
          if not self.connect(): return False
          if not self.go_to_pc(): return False
          if not self.open_energy(): return False
          if not self.capture_energy_screenshot("Dark"): return False
          if not self.dropdown_test(): return False
          if not self.tc_verify_total_energy_dropdown_stability(): return False
          if not self.capture_energy_screenshot("Dark1"): return False
          self.main_window.type_keys("{PGDN}")
          if not self.capture_energy_screenshot("Dark2"): return False
          self.main_window.type_keys("{PGDN}")
          if not self.capture_energy_screenshot("Dark3"): return False
          self.close()

          print("\n🌙 DARK MODE FLOW COMPLETED\n")
          time.sleep(5)

          # -------- LIGHT MODE FLOW --------
          if not self.set_theme(dark=False): return False
          if not self.open_app(): return False
          if not self.connect(): return False
          if not self.go_to_pc(): return False
          if not self.open_energy(): return False
          if not self.capture_energy_screenshot("Light"): return False
          if not self.dropdown_test(): return False
          if not self.tc_verify_total_energy_dropdown_stability(): return False
          if not self.capture_energy_screenshot("Light1"): return False
          self.main_window.type_keys("{PGDN}")
          if not self.capture_energy_screenshot("Light2"): return False
          self.main_window.type_keys("{PGDN}")
          if not self.capture_energy_screenshot("Light3"): return False
          self.close()

          print("\n☀️ LIGHT MODE FLOW COMPLETED\n")
          print("\n🔍 STARTING IMAGE COMPARISON\n")

          if not self.compare_all_screenshots(): 
               print("\n❌ IMAGE VALIDATION FAILED")
               return False
            
          print("\n✅ IMAGE VALIDATION PASSED")
          return True
        
        except Exception as e:
            self._log_result("TC20 Execution", False, str(e))
            return False

# ---------------- RUN ----------------
if __name__ == "__main__":
    result = MyHP().tc20_dark_mode()
    print("\nFINAL RESULT:", "PASS" if result else "FAIL")