import time
import os
import sys
import io
import pyautogui
import pygetwindow as gw
from pywinauto import Application


class MyHP:
    TIMEOUT = 15

    def __init__(self):
        self.application = None
        self.main_window = None
        self.energy_window = None
        self.app_title = "HP"

        # Baseline folder
        self.baseline_folder = os.path.join(os.getcwd(), "baseline")
        os.makedirs(self.baseline_folder, exist_ok=True)

    # ---------------- Logger ----------------
    def _log_result(self, test_name, status, message=""):
        result = "PASS" if status else "FAIL"
        print(f"[{result}] {test_name}: {message}")

    # ---------------- Open HP Application ----------------
    def open_hp_application(self):
        try:
            pyautogui.press('winleft')
            time.sleep(1)
            pyautogui.write(self.app_title)
            time.sleep(1)
            pyautogui.press('enter')
            time.sleep(6)

            active_window = gw.getActiveWindow()
            if active_window and self.app_title in active_window.title:
                active_window.maximize()
                time.sleep(10)
                self._log_result("Open Application", True)
                return True

            self._log_result("Open Application", False, "Wrong window focused")
            return False

        except Exception as e:
            self._log_result("Open Application", False, str(e))
            return False

    # ---------------- Connect to Application ----------------
    def connect_to_application(self):
        try:
            self.application = Application(backend="uia").connect(title_re=self.app_title)
            self.main_window = self.application.window(title_re=self.app_title)
            self.main_window.wait("ready", timeout=self.TIMEOUT)
            self._log_result("Connect to Application", True)
            return True

        except Exception as e:
            self._log_result("Connect to Application", False, str(e))
            return False

    # ---------------- Navigate to PC Device ----------------
    def navigate_to_pc_device(self):
        try:
            pc_device = self.main_window.child_window(
                auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname",
                control_type="Text"
            )

            if pc_device.exists(timeout=10):
                pc_device.click_input()
                time.sleep(6)
                self._log_result("Navigate to PC Device", True)
                return True

            self._log_result("Navigate to PC Device", False, "PC device card not found")
            return False

        except Exception as e:
            self._log_result("Navigate to PC Device", False, str(e))
            return False

    # ---------------- Navigate to Energy Consumption ----------------
    def navigate_to_energy_consumption(self):
        try:
            self.main_window.set_focus()
            time.sleep(3)

            # Lazy load cards
            self.main_window.type_keys("{PGDN}")
            time.sleep(1)
            #self.main_window.type_keys("{PGDN}")
            #time.sleep(1)

            energy_btn = self.main_window.child_window(
                auto_id="PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard",
                control_type="Button"
            )

            if not energy_btn.exists(timeout=10):
                self._log_result("Navigate to Energy Page", False, "Energy card not found")
                return False

            energy_btn.click_input()
            time.sleep(10)

            # Energy page is usually a new pane inside main window
            self.energy_window = self.main_window
            self._log_result("Navigate to Energy Page", True)
            return True

        except Exception as e:
            self._log_result("Navigate to Energy Page", False, str(e))
            return False

    # ---------------- Dump Energy Page UI Tree ----------------
    def dump_energy_page_ui(self):
        if not self.energy_window:
            self._log_result("UI Dump", False, "Energy page not available")
            return False

        dump_path = os.path.join(self.baseline_folder, "ui_dump_energy_page.txt")

        try:
            with open(dump_path, "w", encoding="utf-8") as f:

                def dump_element(elem, indent=0):
                    info = elem.element_info
                    pad = " " * indent

                    f.write(
                        f"{pad}ControlType  : {info.control_type}\n"
                        f"{pad}Name         : {info.name}\n"
                        f"{pad}AutomationId : {info.automation_id}\n"
                        f"{pad}ClassName    : {info.class_name}\n"
                        f"{pad}Rect         : {info.rectangle}\n"
                        f"{pad}Visible      : {info.visible}\n"
                        f"{pad}{'-' * 60}\n"
                    )

                    for child in elem.children():
                        dump_element(child, indent + 4)

                dump_element(self.energy_window)

            self._log_result("UI Dump", True, f"Saved to {dump_path}")
            return True

        except Exception as e:
            self._log_result("UI Dump", False, str(e))
            return False


# ---------------- Main ----------------
if __name__ == "__main__":
    hp = MyHP()
    hp.open_hp_application()
    hp.connect_to_application()
    hp.navigate_to_pc_device()
    hp.navigate_to_energy_consumption()
    hp.dump_energy_page_ui()

    print("\nUI dump completed.")
