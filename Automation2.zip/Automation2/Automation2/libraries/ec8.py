import time
import pygetwindow as gw
from pywinauto import Application
import pyautogui


class MyHP:
    TIMEOUT = 15

    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"

    # ---------------- Logger ----------------
    def _log_result(self, name, status, msg=""):
        print(f"[{'PASS' if status else 'FAIL'}] {name}: {msg}")

    def _log_debug(self, msg):
        print(f"[DEBUG] {msg}")

    # ---------------- Open App ----------------
    def open_hp_application(self):
        pyautogui.press("winleft")
        time.sleep(2)
        pyautogui.write(self.app_title)
        time.sleep(2)
        pyautogui.press("enter")
        time.sleep(6)

        win = gw.getActiveWindow()
        if win and self.app_title in win.title:
            win.maximize()
            time.sleep(8)
            self._log_result("Open Application", True)
            return True

        self._log_result("Open Application", False)
        return False

    # ---------------- Connect ----------------
    def connect_to_application(self):
        self.application = Application(backend="uia").connect(title_re=self.app_title)
        self.main_window = self.application.window(title_re=self.app_title)
        self.main_window.wait("visible", timeout=self.TIMEOUT)
        self._log_result("Connect to Application", True)
        return True

    # ---------------- Navigate to PC ----------------
    def navigate_to_pc_device(self):
        pc = self.main_window.child_window(
            auto_id="DeviceList.DeviceList.PrimaryCard-0__device-nickname",
            control_type="Text"
        )
        if pc.exists(timeout=10):
            pc.click_input()
            time.sleep(5)

        self._log_result("Navigate to PC Device", True)
        return True

    # ---------------- Energy Page ----------------
    def navigate_to_energy_consumption(self):
       # print("\nTEST CASE: Navigate to Energy Consumption")
        #print("-" * 60)
        time.sleep(4)

        self.main_window.type_keys("{PGDN}")
        time.sleep(5)

        energy = self.main_window.child_window(
            auto_id="PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard",
            control_type="Button"
        )

        energy.wait("visible", timeout=15)
        energy.click_input()
        time.sleep(8)

        self._log_result("Navigate to Energy Consumption", True)
        print("-" * 60)
        return True

    # ---------------- Scroll to Total Energy Section ----------------
    def scroll_to_total_energy_section(self):
        self._log_result("Scrolling to Total Energy Consumption section", True)
        self.main_window.type_keys("{PGDN}")
        time.sleep(1)
        time.sleep(10)  # mandatory stabilization wait

    # ---------------- Dropdown Select ----------------
    def select_total_energy_value(self, option_text):
        try:
            dropdown = self.main_window.child_window(control_type="ComboBox")
            dropdown.wait("visible", timeout=10)

            dropdown.wrapper_object().expand()
            time.sleep(5)

            option = self.main_window.child_window(
                title=option_text,
                control_type="ListItem"
            )
            option.wait("visible", timeout=10)
            option.click_input()
            time.sleep(5)

            self._log_result("Select Total Energy Dropdown", True, option_text)
            return True

        except Exception as e:
            self._log_result("Select Total Energy Dropdown", False, str(e))
            return False

    # ---------------- Crash Verification (FIXED) ----------------
    def verify_energy_page_not_crashed(self):
        try:
            if self.main_window.exists(timeout=2) and self.main_window.is_visible():
                self._log_result(
                    "Energy Consumption Crash Check",
                    True,
                    "Application is responsive"
                )
                return True

            self._log_result(
                "Energy Consumption Crash Check",
                False,
                "Main window not visible"
            )
            return False

        except Exception as e:
            self._log_result(
                "Energy Consumption Crash Check",
                False,
                f"Exception occurred: {e}"
            )
            return False

    # ---------------- Test Case ----------------
    def tc_verify_total_energy_dropdown_stability(self):
        print("\nTEST CASE 16: Total Energy Consumption Dropdown Stability with out any crash")
        print("-" * 60)

        self.scroll_to_total_energy_section()

        for i in range(1, 4):
            print(f"\nIteration {i}")

            if not self.select_total_energy_value("Last Week"):
                return False
            if not self.verify_energy_page_not_crashed():
                return False

            if not self.select_total_energy_value("Last Month"):
                return False
            if not self.verify_energy_page_not_crashed():
                return False

        self._log_result(
            "Energy Consumption Dropdown Stability",
            True,
            "No crash after 3 iterations"
        )
        print("-" * 60)
        return True

    # ---------------- Close HP Application ----------------
    def close_hp_application(self):
        try:
            if self.main_window:
                self.main_window.set_focus()
                time.sleep(1)
                self.main_window.close()
                time.sleep(3)

                if not self.main_window.exists(timeout=3):
                    self._log_result("Close Application", True, "Closed HP Application")
                    return True

            hp_windows = gw.getWindowsWithTitle(self.app_title)
            if hp_windows:
                hp_windows[0].activate()
                time.sleep(1)
                pyautogui.hotkey('alt', 'f4')
                time.sleep(2)
                self._log_result("Close Application", True, "Closed using Alt+F4")
                return True

            self._log_result("Close Application", False, "HP window not found")
            return False

        except Exception as e:
            self._log_result("Close Application", False, str(e))
            return False

    # ---------------- Main Runner ----------------
    def tc16_verify_total_energy_consumption_dropdown_without_any_crash(self):
        print("\n====TC16: Energy Consumption Dropdown Stability Test ====\n")

        if not self.open_hp_application():
            return False
        if not self.connect_to_application():
            return False
        if not self.navigate_to_pc_device():
            return False
        if not self.navigate_to_energy_consumption():
            return False
        if not self.tc_verify_total_energy_dropdown_stability():
            return False
        self.close_hp_application()
        return True


# ===================== MAIN =====================
if __name__ == "__main__":
    hp = MyHP()
    hp.tc16_verify_total_energy_consumption_dropdown_without_any_crash()
