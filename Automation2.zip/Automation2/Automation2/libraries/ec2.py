import time
import pyautogui
import pygetwindow as gw
from pywinauto import Application
import os
import sys
import io
from pywinauto.keyboard import send_keys
import pyperclip
import json
from datetime import datetime, timedelta
from collections import defaultdict
import ctypes
import ctypes.wintypes as wintypes


class MyHP:
    TIMEOUT = 5

    def __init__(self):
        self.application = None
        self.main_window = None
        self.app_title = "HP"
        self.baseline_folder = r"C:\Testing\Automation2\Automation2\baseline"

    # ---------------- Logger ----------------
    def _log_result(self, test_name, status, message=""):
        result = "PASS" if status else "FAIL"
        print(f"[{result}] {test_name}: {message}")

    def _log_debug(self, message):
        print(f"[DEBUG] {message}")
    
    #----------Opening the Energy consumption page using the deep links----------------------
    
    def open_energy_consumption_via_run_dialog(self):
        print("\nTEST CASE 10: Open Energy Consumption via Run Dialog")
        print("-" * 60)

        try:
            # Step 1: Open Run dialog
            pyautogui.hotkey("win", "r")
            time.sleep(2)

            # Step 2: Enter protocol command
            pyautogui.write("hpx://pcenergyconsumption", interval=0.05)
            time.sleep(1)
            pyautogui.press("enter")

            # Step 3: Wait for HP app to launch / navigate
            time.sleep(12)

            # Step 4: Connect / reconnect to HP app
            self.application = Application(backend="uia").connect(
                title_re=self.app_title, timeout=15
            )
            self.main_window = self.application.window(title_re=self.app_title)
            self.main_window.wait("ready", timeout=15)
            self.main_window.set_focus()
            time.sleep(3)

            # Step 5: Verify Energy Consumption page
            energy_card = self.main_window.child_window(
                auto_id="PcDeviceCards.PcDeviceActionCards.PcecometerXSettingsCard",
                control_type="Button"
            )

            chart_title = self.main_window.child_window(
                title="Daily average",
                control_type="Text"
            )

            dropdown = self.main_window.child_window(
                title_re="Last.*hours|Last.*days|Last.*months",
                control_type="ComboBox"
            )

            if (energy_card.exists(timeout=8) or
                chart_title.exists(timeout=8) or
                dropdown.exists(timeout=8)):

                self._log_result(
                    "TC10 Open Energy Consumption via Run Dialog",
                    True,
                    "Energy Consumption page opened successfully"
                )
                print("-" * 60)
                return True

            self._log_result(
                "TC10 Open Energy Consumption via Run Dialog",
                False,
                "Energy Consumption page not detected"
            )
            print("-" * 60)
            return False

        except Exception as e:
            self._log_result(
                "TC10 Open Energy Consumption via Run Dialog",
                False,
                str(e)
            )
            print("-" * 60)
            return False
        # ---------------- Close HP Application ----------------
    def close_hp_application(self):
        try:
            if self.main_window:
                self.main_window.set_focus()
                time.sleep(1)
                self.main_window.close()
                time.sleep(3)
                if not self.main_window.exists(timeout=3):
                    self._log_result("Close Application", True, "Closed HP Application")
                    return True

            hp_windows = gw.getWindowsWithTitle(self.app_title)
            if hp_windows:
                hp_windows[0].activate()
                time.sleep(1)
                pyautogui.hotkey('alt', 'f4')
                time.sleep(2)
                self._log_result("Close Application", True, "Closed using Alt+F4")
                return True

            self._log_result("Close Application", False, "HP window not found")
            return False
        except Exception as e:
            self._log_result("Close Application", False, str(e))
            return False

 # ---------------- Run Test Suite ----------------
    def run_energy_consumption_test_suite(self):
       
        self.open_energy_consumption_via_run_dialog()
        self.close_hp_application() 


if __name__ == "__main__":
    hp_test = MyHP()
    hp_test.run_energy_consumption_test_suite()
